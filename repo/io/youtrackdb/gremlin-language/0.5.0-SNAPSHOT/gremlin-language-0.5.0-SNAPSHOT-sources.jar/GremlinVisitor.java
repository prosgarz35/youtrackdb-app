// Generated from Gremlin.g4 by ANTLR 4.13.2
package org.apache.tinkerpop.gremlin.language.grammar;
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link GremlinParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface GremlinVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link GremlinParser#queryList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQueryList(GremlinParser.QueryListContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#query}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery(GremlinParser.QueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#emptyQuery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEmptyQuery(GremlinParser.EmptyQueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSource}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSource(GremlinParser.TraversalSourceContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#transactionPart}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTransactionPart(GremlinParser.TransactionPartContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#rootTraversal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRootTraversal(GremlinParser.RootTraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod(GremlinParser.TraversalSourceSelfMethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withBulk}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_withBulk(GremlinParser.TraversalSourceSelfMethod_withBulkContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withPath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_withPath(GremlinParser.TraversalSourceSelfMethod_withPathContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withSack}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_withSack(GremlinParser.TraversalSourceSelfMethod_withSackContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withSideEffect}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_withSideEffect(GremlinParser.TraversalSourceSelfMethod_withSideEffectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withStrategies}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_withStrategies(GremlinParser.TraversalSourceSelfMethod_withStrategiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withoutStrategies}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_withoutStrategies(GremlinParser.TraversalSourceSelfMethod_withoutStrategiesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_with}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSelfMethod_with(GremlinParser.TraversalSourceSelfMethod_withContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod(GremlinParser.TraversalSourceSpawnMethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_addE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_addE(GremlinParser.TraversalSourceSpawnMethod_addEContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_addV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_addV(GremlinParser.TraversalSourceSpawnMethod_addVContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_E}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_E(GremlinParser.TraversalSourceSpawnMethod_EContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_V}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_V(GremlinParser.TraversalSourceSpawnMethod_VContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_inject}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_inject(GremlinParser.TraversalSourceSpawnMethod_injectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_io}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_io(GremlinParser.TraversalSourceSpawnMethod_ioContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeV_Map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_mergeV_Map(GremlinParser.TraversalSourceSpawnMethod_mergeV_MapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_mergeV_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeV_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeE_Map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_mergeE_Map(GremlinParser.TraversalSourceSpawnMethod_mergeE_MapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_mergeE_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeE_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_call_empty}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_call_empty(GremlinParser.TraversalSourceSpawnMethod_call_emptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_call_string(GremlinParser.TraversalSourceSpawnMethod_call_stringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_call_string_map(GremlinParser.TraversalSourceSpawnMethod_call_string_mapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_call_string_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_traversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_map_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_call_string_map_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_map_traversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_union}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_union(GremlinParser.TraversalSourceSpawnMethod_unionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_empty}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_customService_empty(GremlinParser.TraversalSourceSpawnMethod_customService_emptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_customService_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_traversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_args}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_customService_args(GremlinParser.TraversalSourceSpawnMethod_customService_argsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_args_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSourceSpawnMethod_customService_args_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_args_traversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#chainedTraversal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitChainedTraversal(GremlinParser.ChainedTraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#nestedTraversal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNestedTraversal(GremlinParser.NestedTraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#terminatedTraversal}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTerminatedTraversal(GremlinParser.TerminatedTraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod(GremlinParser.TraversalMethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_V}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_V(GremlinParser.TraversalMethod_VContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_E}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_E(GremlinParser.TraversalMethod_EContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_addE_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_addE_String(GremlinParser.TraversalMethod_addE_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_addE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_addE_Traversal(GremlinParser.TraversalMethod_addE_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_addV_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_addV_Empty(GremlinParser.TraversalMethod_addV_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_addV_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_addV_String(GremlinParser.TraversalMethod_addV_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_addV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_addV_Traversal(GremlinParser.TraversalMethod_addV_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_aggregate_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_aggregate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_aggregate_String(GremlinParser.TraversalMethod_aggregate_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_all_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_all}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_all_P(GremlinParser.TraversalMethod_all_PContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_and}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_and(GremlinParser.TraversalMethod_andContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_any_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_any}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_any_P(GremlinParser.TraversalMethod_any_PContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_as}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_as(GremlinParser.TraversalMethod_asContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_asBool}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_asBool(GremlinParser.TraversalMethod_asBoolContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_asDate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_asDate(GremlinParser.TraversalMethod_asDateContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_asNumber_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asNumber}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_asNumber_Empty(GremlinParser.TraversalMethod_asNumber_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_asNumber_traversalGType}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asNumber}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_asNumber_traversalGType(GremlinParser.TraversalMethod_asNumber_traversalGTypeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_asString_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asString}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_asString_Empty(GremlinParser.TraversalMethod_asString_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_asString_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asString}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_asString_Scope(GremlinParser.TraversalMethod_asString_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_barrier_Consumer}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_barrier_Consumer(GremlinParser.TraversalMethod_barrier_ConsumerContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_barrier_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_barrier_Empty(GremlinParser.TraversalMethod_barrier_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_barrier_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_barrier_int(GremlinParser.TraversalMethod_barrier_intContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_both}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_both(GremlinParser.TraversalMethod_bothContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_bothE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_bothE(GremlinParser.TraversalMethod_bothEContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_bothV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_bothV(GremlinParser.TraversalMethod_bothVContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_branch}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_branch(GremlinParser.TraversalMethod_branchContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Comparator(GremlinParser.TraversalMethod_by_ComparatorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Empty(GremlinParser.TraversalMethod_by_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Function}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Function(GremlinParser.TraversalMethod_by_FunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Function_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Function_Comparator(GremlinParser.TraversalMethod_by_Function_ComparatorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Order}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Order(GremlinParser.TraversalMethod_by_OrderContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_String(GremlinParser.TraversalMethod_by_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_String_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_String_Comparator(GremlinParser.TraversalMethod_by_String_ComparatorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_T}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_T(GremlinParser.TraversalMethod_by_TContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Traversal(GremlinParser.TraversalMethod_by_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_by_Traversal_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_by_Traversal_Comparator(GremlinParser.TraversalMethod_by_Traversal_ComparatorContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_call_string}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_call_string(GremlinParser.TraversalMethod_call_stringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_call_string_map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_call_string_map(GremlinParser.TraversalMethod_call_string_mapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_call_string_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_call_string_traversal(GremlinParser.TraversalMethod_call_string_traversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_call_string_map_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_call_string_map_traversal(GremlinParser.TraversalMethod_call_string_map_traversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_customService_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_customService_empty(GremlinParser.TraversalMethod_customService_emptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_customService_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_customService_traversal(GremlinParser.TraversalMethod_customService_traversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_customService_args}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_customService_args(GremlinParser.TraversalMethod_customService_argsContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_customService_args_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_customService_args_traversal(GremlinParser.TraversalMethod_customService_args_traversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_cap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_cap(GremlinParser.TraversalMethod_capContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_choose_Function}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_choose_Function(GremlinParser.TraversalMethod_choose_FunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_choose_Predicate_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_choose_Predicate_Traversal(GremlinParser.TraversalMethod_choose_Predicate_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_choose_Predicate_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_choose_Predicate_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Predicate_Traversal_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_choose_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_choose_Traversal(GremlinParser.TraversalMethod_choose_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_choose_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_choose_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_choose_Traversal_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_choose_Traversal_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_Traversal_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_coalesce}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_coalesce(GremlinParser.TraversalMethod_coalesceContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_coin}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_coin(GremlinParser.TraversalMethod_coinContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_combine_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_combine}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_combine_Object(GremlinParser.TraversalMethod_combine_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_concat_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_concat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_concat_Traversal_Traversal(GremlinParser.TraversalMethod_concat_Traversal_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_concat_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_concat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_concat_String(GremlinParser.TraversalMethod_concat_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_conjoin_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_conjoin}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_conjoin_String(GremlinParser.TraversalMethod_conjoin_StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_connectedComponent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_connectedComponent(GremlinParser.TraversalMethod_connectedComponentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_constant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_constant(GremlinParser.TraversalMethod_constantContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_count_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_count}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_count_Empty(GremlinParser.TraversalMethod_count_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_count_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_count}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_count_Scope(GremlinParser.TraversalMethod_count_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_cyclicPath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_cyclicPath(GremlinParser.TraversalMethod_cyclicPathContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_dateAdd}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_dateAdd(GremlinParser.TraversalMethod_dateAddContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_dateDiff_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dateDiff}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_dateDiff_Traversal(GremlinParser.TraversalMethod_dateDiff_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_dateDiff_Date}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dateDiff}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_dateDiff_Date(GremlinParser.TraversalMethod_dateDiff_DateContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_dedup_Scope_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dedup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_dedup_Scope_String(GremlinParser.TraversalMethod_dedup_Scope_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_dedup_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dedup}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_dedup_String(GremlinParser.TraversalMethod_dedup_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_difference_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_difference}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_difference_Object(GremlinParser.TraversalMethod_difference_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_discard}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_discard(GremlinParser.TraversalMethod_discardContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_disjunct_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_disjunct}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_disjunct_Object(GremlinParser.TraversalMethod_disjunct_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_drop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_drop(GremlinParser.TraversalMethod_dropContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_element}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_element(GremlinParser.TraversalMethod_elementContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_elementMap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_elementMap(GremlinParser.TraversalMethod_elementMapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_emit_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_emit_Empty(GremlinParser.TraversalMethod_emit_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_emit_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_emit_Predicate(GremlinParser.TraversalMethod_emit_PredicateContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_emit_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_emit_Traversal(GremlinParser.TraversalMethod_emit_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_fail_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_fail_Empty(GremlinParser.TraversalMethod_fail_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_fail_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_fail_String(GremlinParser.TraversalMethod_fail_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_filter_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_filter_Predicate(GremlinParser.TraversalMethod_filter_PredicateContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_filter_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_filter}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_filter_Traversal(GremlinParser.TraversalMethod_filter_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_flatMap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_flatMap(GremlinParser.TraversalMethod_flatMapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_fold_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fold}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_fold_Empty(GremlinParser.TraversalMethod_fold_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_fold_Object_BiFunction}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fold}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_fold_Object_BiFunction(GremlinParser.TraversalMethod_fold_Object_BiFunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_format_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_format}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_format_String(GremlinParser.TraversalMethod_format_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_from_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_from}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_from_String(GremlinParser.TraversalMethod_from_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_from_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_from}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_from_Traversal(GremlinParser.TraversalMethod_from_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_group_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_group}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_group_Empty(GremlinParser.TraversalMethod_group_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_group_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_group}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_group_String(GremlinParser.TraversalMethod_group_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_groupCount_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_groupCount}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_groupCount_Empty(GremlinParser.TraversalMethod_groupCount_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_groupCount_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_groupCount}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_groupCount_String(GremlinParser.TraversalMethod_groupCount_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_String(GremlinParser.TraversalMethod_has_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_String_Object(GremlinParser.TraversalMethod_has_String_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_String_P(GremlinParser.TraversalMethod_has_String_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_String_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_String_String_Object(GremlinParser.TraversalMethod_has_String_String_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_String_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_String_String_P(GremlinParser.TraversalMethod_has_String_String_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_T_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_T_Object(GremlinParser.TraversalMethod_has_T_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_has_T_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_has_T_P(GremlinParser.TraversalMethod_has_T_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasId_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasId_Object_Object(GremlinParser.TraversalMethod_hasId_Object_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasId_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasId}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasId_P(GremlinParser.TraversalMethod_hasId_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasKey_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasKey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasKey_P(GremlinParser.TraversalMethod_hasKey_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasKey_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasKey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasKey_String_String(GremlinParser.TraversalMethod_hasKey_String_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasLabel_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasLabel}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasLabel_P(GremlinParser.TraversalMethod_hasLabel_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasLabel_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasLabel}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasLabel_String_String(GremlinParser.TraversalMethod_hasLabel_String_StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_hasNot}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasNot(GremlinParser.TraversalMethod_hasNotContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasValue_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasValue_Object_Object(GremlinParser.TraversalMethod_hasValue_Object_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_hasValue_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasValue}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_hasValue_P(GremlinParser.TraversalMethod_hasValue_PContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_id}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_id(GremlinParser.TraversalMethod_idContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_identity}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_identity(GremlinParser.TraversalMethod_identityContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_in}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_in(GremlinParser.TraversalMethod_inContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_inE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_inE(GremlinParser.TraversalMethod_inEContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_intersect_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_intersect}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_intersect_Object(GremlinParser.TraversalMethod_intersect_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_inV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_inV(GremlinParser.TraversalMethod_inVContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_index}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_index(GremlinParser.TraversalMethod_indexContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_inject}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_inject(GremlinParser.TraversalMethod_injectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_is_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_is}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_is_Object(GremlinParser.TraversalMethod_is_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_is_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_is}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_is_P(GremlinParser.TraversalMethod_is_PContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_key}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_key(GremlinParser.TraversalMethod_keyContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_label}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_label(GremlinParser.TraversalMethod_labelContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_length_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_length}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_length_Empty(GremlinParser.TraversalMethod_length_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_length_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_length}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_length_Scope(GremlinParser.TraversalMethod_length_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_limit_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_limit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_limit_Scope_long(GremlinParser.TraversalMethod_limit_Scope_longContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_limit_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_limit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_limit_long(GremlinParser.TraversalMethod_limit_longContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_local}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_local(GremlinParser.TraversalMethod_localContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_loops_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_loops}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_loops_Empty(GremlinParser.TraversalMethod_loops_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_loops_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_loops}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_loops_String(GremlinParser.TraversalMethod_loops_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_lTrim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_lTrim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_lTrim_Empty(GremlinParser.TraversalMethod_lTrim_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_lTrim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_lTrim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_lTrim_Scope(GremlinParser.TraversalMethod_lTrim_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_map}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_map(GremlinParser.TraversalMethod_mapContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_match}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_match(GremlinParser.TraversalMethod_matchContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_math}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_math(GremlinParser.TraversalMethod_mathContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_max_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_max}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_max_Empty(GremlinParser.TraversalMethod_max_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_max_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_max}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_max_Scope(GremlinParser.TraversalMethod_max_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mean_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mean}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mean_Empty(GremlinParser.TraversalMethod_mean_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mean_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mean}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mean_Scope(GremlinParser.TraversalMethod_mean_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_merge_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_merge}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_merge_Object(GremlinParser.TraversalMethod_merge_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mergeV_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mergeV_empty(GremlinParser.TraversalMethod_mergeV_emptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mergeV_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mergeV_Map(GremlinParser.TraversalMethod_mergeV_MapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mergeV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mergeV_Traversal(GremlinParser.TraversalMethod_mergeV_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mergeE_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mergeE_empty(GremlinParser.TraversalMethod_mergeE_emptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mergeE_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mergeE_Map(GremlinParser.TraversalMethod_mergeE_MapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_mergeE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_mergeE_Traversal(GremlinParser.TraversalMethod_mergeE_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_min_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_min}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_min_Empty(GremlinParser.TraversalMethod_min_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_min_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_min}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_min_Scope(GremlinParser.TraversalMethod_min_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_none_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_none}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_none_P(GremlinParser.TraversalMethod_none_PContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_not}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_not(GremlinParser.TraversalMethod_notContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_option_Predicate_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_option_Predicate_Traversal(GremlinParser.TraversalMethod_option_Predicate_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_option_Merge_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_option_Merge_Map(GremlinParser.TraversalMethod_option_Merge_MapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_option_Merge_Map_Cardinality}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_option_Merge_Map_Cardinality(GremlinParser.TraversalMethod_option_Merge_Map_CardinalityContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_option_Merge_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_option_Merge_Traversal(GremlinParser.TraversalMethod_option_Merge_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_option_Object_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_option_Object_Traversal(GremlinParser.TraversalMethod_option_Object_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_option_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_option_Traversal(GremlinParser.TraversalMethod_option_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_optional}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_optional(GremlinParser.TraversalMethod_optionalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_or}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_or(GremlinParser.TraversalMethod_orContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_order_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_order}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_order_Empty(GremlinParser.TraversalMethod_order_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_order_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_order}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_order_Scope(GremlinParser.TraversalMethod_order_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_otherV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_otherV(GremlinParser.TraversalMethod_otherVContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_out}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_out(GremlinParser.TraversalMethod_outContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_outE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_outE(GremlinParser.TraversalMethod_outEContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_outV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_outV(GremlinParser.TraversalMethod_outVContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_pageRank_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_pageRank}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_pageRank_Empty(GremlinParser.TraversalMethod_pageRank_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_pageRank_double}
	 * labeled alternative in {@link GremlinParser#traversalMethod_pageRank}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_pageRank_double(GremlinParser.TraversalMethod_pageRank_doubleContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_path}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_path(GremlinParser.TraversalMethod_pathContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_peerPressure}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_peerPressure(GremlinParser.TraversalMethod_peerPressureContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_product_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_product}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_product_Object(GremlinParser.TraversalMethod_product_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_profile_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_profile}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_profile_Empty(GremlinParser.TraversalMethod_profile_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_profile_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_profile}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_profile_String(GremlinParser.TraversalMethod_profile_StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_project}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_project(GremlinParser.TraversalMethod_projectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_properties}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_properties(GremlinParser.TraversalMethod_propertiesContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_property_Cardinality_Object_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_property_Cardinality_Object_Object_Object(GremlinParser.TraversalMethod_property_Cardinality_Object_Object_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_property_Cardinality_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_property_Cardinality_Object(GremlinParser.TraversalMethod_property_Cardinality_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_property_Object_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_property_Object_Object_Object(GremlinParser.TraversalMethod_property_Object_Object_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_property_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_property_Object(GremlinParser.TraversalMethod_property_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_propertyMap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_propertyMap(GremlinParser.TraversalMethod_propertyMapContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_range_Scope_long_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_range}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_range_Scope_long_long(GremlinParser.TraversalMethod_range_Scope_long_longContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_range_long_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_range}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_range_long_long(GremlinParser.TraversalMethod_range_long_longContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_read}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_read(GremlinParser.TraversalMethod_readContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_repeat_String_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_repeat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_repeat_String_Traversal(GremlinParser.TraversalMethod_repeat_String_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_repeat_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_repeat}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_repeat_Traversal(GremlinParser.TraversalMethod_repeat_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_replace_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_replace}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_replace_String_String(GremlinParser.TraversalMethod_replace_String_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_replace_Scope_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_replace}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_replace_Scope_String_String(GremlinParser.TraversalMethod_replace_Scope_String_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_reverse_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_reverse}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_reverse_Empty(GremlinParser.TraversalMethod_reverse_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_rTrim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_rTrim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_rTrim_Empty(GremlinParser.TraversalMethod_rTrim_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_rTrim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_rTrim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_rTrim_Scope(GremlinParser.TraversalMethod_rTrim_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_sack_BiFunction}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sack}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sack_BiFunction(GremlinParser.TraversalMethod_sack_BiFunctionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_sack_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sack}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sack_Empty(GremlinParser.TraversalMethod_sack_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_sample_Scope_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sample}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sample_Scope_int(GremlinParser.TraversalMethod_sample_Scope_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_sample_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sample}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sample_int(GremlinParser.TraversalMethod_sample_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_Column}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_Column(GremlinParser.TraversalMethod_select_ColumnContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_Pop_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_Pop_String(GremlinParser.TraversalMethod_select_Pop_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_Pop_String_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_Pop_String_String_String(GremlinParser.TraversalMethod_select_Pop_String_String_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_Pop_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_Pop_Traversal(GremlinParser.TraversalMethod_select_Pop_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_String(GremlinParser.TraversalMethod_select_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_String_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_String_String_String(GremlinParser.TraversalMethod_select_String_String_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_select_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_select_Traversal(GremlinParser.TraversalMethod_select_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_shortestPath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_shortestPath(GremlinParser.TraversalMethod_shortestPathContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_sideEffect}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sideEffect(GremlinParser.TraversalMethod_sideEffectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_simplePath}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_simplePath(GremlinParser.TraversalMethod_simplePathContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_skip_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_skip}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_skip_Scope_long(GremlinParser.TraversalMethod_skip_Scope_longContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_skip_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_skip}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_skip_long(GremlinParser.TraversalMethod_skip_longContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_split_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_split}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_split_String(GremlinParser.TraversalMethod_split_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_split_Scope_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_split}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_split_Scope_String(GremlinParser.TraversalMethod_split_Scope_StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_subgraph}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_subgraph(GremlinParser.TraversalMethod_subgraphContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_substring_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_substring_int(GremlinParser.TraversalMethod_substring_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_substring_Scope_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_substring_Scope_int(GremlinParser.TraversalMethod_substring_Scope_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_substring_int_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_substring_int_int(GremlinParser.TraversalMethod_substring_int_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_substring_Scope_int_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_substring_Scope_int_int(GremlinParser.TraversalMethod_substring_Scope_int_intContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_sum_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sum_Empty(GremlinParser.TraversalMethod_sum_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_sum_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sum}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_sum_Scope(GremlinParser.TraversalMethod_sum_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_tail_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_tail_Empty(GremlinParser.TraversalMethod_tail_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_tail_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_tail_Scope(GremlinParser.TraversalMethod_tail_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_tail_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_tail_Scope_long(GremlinParser.TraversalMethod_tail_Scope_longContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_tail_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_tail_long(GremlinParser.TraversalMethod_tail_longContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_timeLimit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_timeLimit(GremlinParser.TraversalMethod_timeLimitContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_times}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_times(GremlinParser.TraversalMethod_timesContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_to_Direction_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_to_Direction_String(GremlinParser.TraversalMethod_to_Direction_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_to_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_to_String(GremlinParser.TraversalMethod_to_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_to_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_to_Traversal(GremlinParser.TraversalMethod_to_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_toE}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_toE(GremlinParser.TraversalMethod_toEContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_toLower_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toLower}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_toLower_Empty(GremlinParser.TraversalMethod_toLower_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_toLower_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toLower}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_toLower_Scope(GremlinParser.TraversalMethod_toLower_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_toUpper_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toUpper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_toUpper_Empty(GremlinParser.TraversalMethod_toUpper_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_toUpper_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toUpper}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_toUpper_Scope(GremlinParser.TraversalMethod_toUpper_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_toV}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_toV(GremlinParser.TraversalMethod_toVContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_tree_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tree}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_tree_Empty(GremlinParser.TraversalMethod_tree_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_tree_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tree}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_tree_String(GremlinParser.TraversalMethod_tree_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_trim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_trim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_trim_Empty(GremlinParser.TraversalMethod_trim_EmptyContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_trim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_trim}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_trim_Scope(GremlinParser.TraversalMethod_trim_ScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_unfold}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_unfold(GremlinParser.TraversalMethod_unfoldContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_union}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_union(GremlinParser.TraversalMethod_unionContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_until_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_until}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_until_Predicate(GremlinParser.TraversalMethod_until_PredicateContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_until_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_until}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_until_Traversal(GremlinParser.TraversalMethod_until_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_value}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_value(GremlinParser.TraversalMethod_valueContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_valueMap_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_valueMap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_valueMap_String(GremlinParser.TraversalMethod_valueMap_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_valueMap_boolean_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_valueMap}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_valueMap_boolean_String(GremlinParser.TraversalMethod_valueMap_boolean_StringContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_values}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_values(GremlinParser.TraversalMethod_valuesContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_where_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_where_P(GremlinParser.TraversalMethod_where_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_where_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_where_String_P(GremlinParser.TraversalMethod_where_String_PContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_where_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_where_Traversal(GremlinParser.TraversalMethod_where_TraversalContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_with_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_with}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_with_String(GremlinParser.TraversalMethod_with_StringContext ctx);
	/**
	 * Visit a parse tree produced by the {@code traversalMethod_with_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_with}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_with_String_Object(GremlinParser.TraversalMethod_with_String_ObjectContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMethod_write}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMethod_write(GremlinParser.TraversalMethod_writeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalStrategy}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalStrategy(GremlinParser.TraversalStrategyContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#configuration}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConfiguration(GremlinParser.ConfigurationContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalScope}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalScope(GremlinParser.TraversalScopeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalBarrier}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalBarrier(GremlinParser.TraversalBarrierContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalT}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalT(GremlinParser.TraversalTContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTShort}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTShort(GremlinParser.TraversalTShortContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTLong}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTLong(GremlinParser.TraversalTLongContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalMerge}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalMerge(GremlinParser.TraversalMergeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalOrder}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalOrder(GremlinParser.TraversalOrderContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalDirection}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalDirection(GremlinParser.TraversalDirectionContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalDirectionShort}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalDirectionShort(GremlinParser.TraversalDirectionShortContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalDirectionLong}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalDirectionLong(GremlinParser.TraversalDirectionLongContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalCardinality}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalCardinality(GremlinParser.TraversalCardinalityContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalColumn}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalColumn(GremlinParser.TraversalColumnContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPop}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPop(GremlinParser.TraversalPopContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalOperator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalOperator(GremlinParser.TraversalOperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPick}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPick(GremlinParser.TraversalPickContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalDT}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalDT(GremlinParser.TraversalDTContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalGType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalGType(GremlinParser.TraversalGTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate(GremlinParser.TraversalPredicateContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod(GremlinParser.TraversalTerminalMethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalSackMethod}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalSackMethod(GremlinParser.TraversalSackMethodContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalComparator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalComparator(GremlinParser.TraversalComparatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalFunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalFunction(GremlinParser.TraversalFunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalBiFunction}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalBiFunction(GremlinParser.TraversalBiFunctionContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_eq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_eq(GremlinParser.TraversalPredicate_eqContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_neq}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_neq(GremlinParser.TraversalPredicate_neqContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_typeOf}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_typeOf(GremlinParser.TraversalPredicate_typeOfContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_lt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_lt(GremlinParser.TraversalPredicate_ltContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_lte}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_lte(GremlinParser.TraversalPredicate_lteContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_gt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_gt(GremlinParser.TraversalPredicate_gtContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_gte}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_gte(GremlinParser.TraversalPredicate_gteContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_inside}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_inside(GremlinParser.TraversalPredicate_insideContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_outside}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_outside(GremlinParser.TraversalPredicate_outsideContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_between}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_between(GremlinParser.TraversalPredicate_betweenContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_within}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_within(GremlinParser.TraversalPredicate_withinContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_without}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_without(GremlinParser.TraversalPredicate_withoutContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_not}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_not(GremlinParser.TraversalPredicate_notContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_containing}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_containing(GremlinParser.TraversalPredicate_containingContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_notContaining}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_notContaining(GremlinParser.TraversalPredicate_notContainingContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_startingWith}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_startingWith(GremlinParser.TraversalPredicate_startingWithContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_notStartingWith}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_notStartingWith(GremlinParser.TraversalPredicate_notStartingWithContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_endingWith}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_endingWith(GremlinParser.TraversalPredicate_endingWithContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_notEndingWith}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_notEndingWith(GremlinParser.TraversalPredicate_notEndingWithContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_regex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_regex(GremlinParser.TraversalPredicate_regexContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalPredicate_notRegex}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalPredicate_notRegex(GremlinParser.TraversalPredicate_notRegexContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_explain}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_explain(GremlinParser.TraversalTerminalMethod_explainContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_hasNext}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_hasNext(GremlinParser.TraversalTerminalMethod_hasNextContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_iterate}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_iterate(GremlinParser.TraversalTerminalMethod_iterateContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_tryNext}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_tryNext(GremlinParser.TraversalTerminalMethod_tryNextContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_next}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_next(GremlinParser.TraversalTerminalMethod_nextContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_toList(GremlinParser.TraversalTerminalMethod_toListContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toSet}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_toSet(GremlinParser.TraversalTerminalMethod_toSetContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toBulkSet}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalTerminalMethod_toBulkSet(GremlinParser.TraversalTerminalMethod_toBulkSetContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionKeys}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionKeys(GremlinParser.WithOptionKeysContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#connectedComponentConstants}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConnectedComponentConstants(GremlinParser.ConnectedComponentConstantsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#pageRankConstants}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageRankConstants(GremlinParser.PageRankConstantsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#peerPressureConstants}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeerPressureConstants(GremlinParser.PeerPressureConstantsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathConstants}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathConstants(GremlinParser.ShortestPathConstantsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsValues}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsValues(GremlinParser.WithOptionsValuesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsKeys}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsKeys(GremlinParser.IoOptionsKeysContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsValues}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsValues(GremlinParser.IoOptionsValuesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#connectedComponentConstants_component}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConnectedComponentConstants_component(GremlinParser.ConnectedComponentConstants_componentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#connectedComponentConstants_edges}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConnectedComponentConstants_edges(GremlinParser.ConnectedComponentConstants_edgesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#connectedComponentConstants_propertyName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConnectedComponentConstants_propertyName(GremlinParser.ConnectedComponentConstants_propertyNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#pageRankConstants_edges}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageRankConstants_edges(GremlinParser.PageRankConstants_edgesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#pageRankConstants_times}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageRankConstants_times(GremlinParser.PageRankConstants_timesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#pageRankConstants_propertyName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageRankConstants_propertyName(GremlinParser.PageRankConstants_propertyNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#peerPressureConstants_edges}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeerPressureConstants_edges(GremlinParser.PeerPressureConstants_edgesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#peerPressureConstants_times}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeerPressureConstants_times(GremlinParser.PeerPressureConstants_timesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#peerPressureConstants_propertyName}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeerPressureConstants_propertyName(GremlinParser.PeerPressureConstants_propertyNameContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathConstants_target}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathConstants_target(GremlinParser.ShortestPathConstants_targetContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathConstants_edges}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathConstants_edges(GremlinParser.ShortestPathConstants_edgesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathConstants_distance}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathConstants_distance(GremlinParser.ShortestPathConstants_distanceContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathConstants_maxDistance}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathConstants_maxDistance(GremlinParser.ShortestPathConstants_maxDistanceContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathConstants_includeEdges}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathConstants_includeEdges(GremlinParser.ShortestPathConstants_includeEdgesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_tokens}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_tokens(GremlinParser.WithOptionsConstants_tokensContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_none}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_none(GremlinParser.WithOptionsConstants_noneContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_ids}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_ids(GremlinParser.WithOptionsConstants_idsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_labels}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_labels(GremlinParser.WithOptionsConstants_labelsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_keys}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_keys(GremlinParser.WithOptionsConstants_keysContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_values}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_values(GremlinParser.WithOptionsConstants_valuesContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_all}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_all(GremlinParser.WithOptionsConstants_allContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_indexer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_indexer(GremlinParser.WithOptionsConstants_indexerContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_list}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_list(GremlinParser.WithOptionsConstants_listContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsConstants_map}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsConstants_map(GremlinParser.WithOptionsConstants_mapContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsConstants_reader}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsConstants_reader(GremlinParser.IoOptionsConstants_readerContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsConstants_writer}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsConstants_writer(GremlinParser.IoOptionsConstants_writerContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsConstants_gryo}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsConstants_gryo(GremlinParser.IoOptionsConstants_gryoContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsConstants_graphson}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsConstants_graphson(GremlinParser.IoOptionsConstants_graphsonContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsConstants_graphml}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsConstants_graphml(GremlinParser.IoOptionsConstants_graphmlContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#connectedComponentStringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitConnectedComponentStringConstant(GremlinParser.ConnectedComponentStringConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#pageRankStringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPageRankStringConstant(GremlinParser.PageRankStringConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#peerPressureStringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPeerPressureStringConstant(GremlinParser.PeerPressureStringConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#shortestPathStringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitShortestPathStringConstant(GremlinParser.ShortestPathStringConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#withOptionsStringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWithOptionsStringConstant(GremlinParser.WithOptionsStringConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#ioOptionsStringConstant}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIoOptionsStringConstant(GremlinParser.IoOptionsStringConstantContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#booleanArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanArgument(GremlinParser.BooleanArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#integerArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntegerArgument(GremlinParser.IntegerArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#floatArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatArgument(GremlinParser.FloatArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#stringArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringArgument(GremlinParser.StringArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#stringNullableArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringNullableArgument(GremlinParser.StringNullableArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#stringNullableArgumentVarargs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringNullableArgumentVarargs(GremlinParser.StringNullableArgumentVarargsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#dateArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDateArgument(GremlinParser.DateArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericArgument(GremlinParser.GenericArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericArgumentVarargs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericArgumentVarargs(GremlinParser.GenericArgumentVarargsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericMapArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericMapArgument(GremlinParser.GenericMapArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericMapNullableArgument}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericMapNullableArgument(GremlinParser.GenericMapNullableArgumentContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalStrategyVarargs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalStrategyVarargs(GremlinParser.TraversalStrategyVarargsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#traversalStrategyExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTraversalStrategyExpr(GremlinParser.TraversalStrategyExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#classTypeList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClassTypeList(GremlinParser.ClassTypeListContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#classTypeExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClassTypeExpr(GremlinParser.ClassTypeExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#nestedTraversalList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNestedTraversalList(GremlinParser.NestedTraversalListContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#nestedTraversalExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNestedTraversalExpr(GremlinParser.NestedTraversalExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericCollectionLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericCollectionLiteral(GremlinParser.GenericCollectionLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericLiteralVarargs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericLiteralVarargs(GremlinParser.GenericLiteralVarargsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericLiteralExpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericLiteralExpr(GremlinParser.GenericLiteralExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericMapNullableLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericMapNullableLiteral(GremlinParser.GenericMapNullableLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericRangeLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericRangeLiteral(GremlinParser.GenericRangeLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericSetLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericSetLiteral(GremlinParser.GenericSetLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#stringNullableLiteralVarargs}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringNullableLiteralVarargs(GremlinParser.StringNullableLiteralVarargsContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericLiteral(GremlinParser.GenericLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#genericMapLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitGenericMapLiteral(GremlinParser.GenericMapLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#mapKey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMapKey(GremlinParser.MapKeyContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#mapEntry}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMapEntry(GremlinParser.MapEntryContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#stringLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringLiteral(GremlinParser.StringLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#stringNullableLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStringNullableLiteral(GremlinParser.StringNullableLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#integerLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntegerLiteral(GremlinParser.IntegerLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#floatLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatLiteral(GremlinParser.FloatLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#numericLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNumericLiteral(GremlinParser.NumericLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#booleanLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBooleanLiteral(GremlinParser.BooleanLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#dateLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDateLiteral(GremlinParser.DateLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#nullLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNullLiteral(GremlinParser.NullLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#nanLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNanLiteral(GremlinParser.NanLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#infLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInfLiteral(GremlinParser.InfLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#uuidLiteral}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitUuidLiteral(GremlinParser.UuidLiteralContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#nakedKey}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNakedKey(GremlinParser.NakedKeyContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#classType}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitClassType(GremlinParser.ClassTypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable(GremlinParser.VariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link GremlinParser#keyword}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitKeyword(GremlinParser.KeywordContext ctx);
}