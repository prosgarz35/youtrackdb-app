// Generated from Gremlin.g4 by ANTLR 4.13.2
package org.apache.tinkerpop.gremlin.language.grammar;

import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.TerminalNode;

/**
 * This class provides an empty implementation of {@link GremlinListener},
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
@SuppressWarnings("CheckReturnValue")
public class GremlinBaseListener implements GremlinListener {
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterQueryList(GremlinParser.QueryListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitQueryList(GremlinParser.QueryListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterQuery(GremlinParser.QueryContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitQuery(GremlinParser.QueryContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEmptyQuery(GremlinParser.EmptyQueryContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEmptyQuery(GremlinParser.EmptyQueryContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSource(GremlinParser.TraversalSourceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSource(GremlinParser.TraversalSourceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTransactionPart(GremlinParser.TransactionPartContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTransactionPart(GremlinParser.TransactionPartContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterRootTraversal(GremlinParser.RootTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitRootTraversal(GremlinParser.RootTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod(GremlinParser.TraversalSourceSelfMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod(GremlinParser.TraversalSourceSelfMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_withBulk(GremlinParser.TraversalSourceSelfMethod_withBulkContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_withBulk(GremlinParser.TraversalSourceSelfMethod_withBulkContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_withPath(GremlinParser.TraversalSourceSelfMethod_withPathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_withPath(GremlinParser.TraversalSourceSelfMethod_withPathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_withSack(GremlinParser.TraversalSourceSelfMethod_withSackContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_withSack(GremlinParser.TraversalSourceSelfMethod_withSackContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_withSideEffect(GremlinParser.TraversalSourceSelfMethod_withSideEffectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_withSideEffect(GremlinParser.TraversalSourceSelfMethod_withSideEffectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_withStrategies(GremlinParser.TraversalSourceSelfMethod_withStrategiesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_withStrategies(GremlinParser.TraversalSourceSelfMethod_withStrategiesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_withoutStrategies(GremlinParser.TraversalSourceSelfMethod_withoutStrategiesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_withoutStrategies(GremlinParser.TraversalSourceSelfMethod_withoutStrategiesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSelfMethod_with(GremlinParser.TraversalSourceSelfMethod_withContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSelfMethod_with(GremlinParser.TraversalSourceSelfMethod_withContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod(GremlinParser.TraversalSourceSpawnMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod(GremlinParser.TraversalSourceSpawnMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_addE(GremlinParser.TraversalSourceSpawnMethod_addEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_addE(GremlinParser.TraversalSourceSpawnMethod_addEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_addV(GremlinParser.TraversalSourceSpawnMethod_addVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_addV(GremlinParser.TraversalSourceSpawnMethod_addVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_E(GremlinParser.TraversalSourceSpawnMethod_EContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_E(GremlinParser.TraversalSourceSpawnMethod_EContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_V(GremlinParser.TraversalSourceSpawnMethod_VContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_V(GremlinParser.TraversalSourceSpawnMethod_VContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_inject(GremlinParser.TraversalSourceSpawnMethod_injectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_inject(GremlinParser.TraversalSourceSpawnMethod_injectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_io(GremlinParser.TraversalSourceSpawnMethod_ioContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_io(GremlinParser.TraversalSourceSpawnMethod_ioContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_mergeV_Map(GremlinParser.TraversalSourceSpawnMethod_mergeV_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_mergeV_Map(GremlinParser.TraversalSourceSpawnMethod_mergeV_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_mergeV_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeV_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_mergeV_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeV_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_mergeE_Map(GremlinParser.TraversalSourceSpawnMethod_mergeE_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_mergeE_Map(GremlinParser.TraversalSourceSpawnMethod_mergeE_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_mergeE_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeE_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_mergeE_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeE_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_call_empty(GremlinParser.TraversalSourceSpawnMethod_call_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_call_empty(GremlinParser.TraversalSourceSpawnMethod_call_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_call_string(GremlinParser.TraversalSourceSpawnMethod_call_stringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_call_string(GremlinParser.TraversalSourceSpawnMethod_call_stringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_call_string_map(GremlinParser.TraversalSourceSpawnMethod_call_string_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_call_string_map(GremlinParser.TraversalSourceSpawnMethod_call_string_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_call_string_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_call_string_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_call_string_map_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_map_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_call_string_map_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_map_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_union(GremlinParser.TraversalSourceSpawnMethod_unionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_union(GremlinParser.TraversalSourceSpawnMethod_unionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_customService_empty(GremlinParser.TraversalSourceSpawnMethod_customService_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_customService_empty(GremlinParser.TraversalSourceSpawnMethod_customService_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_customService_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_customService_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_customService_args(GremlinParser.TraversalSourceSpawnMethod_customService_argsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_customService_args(GremlinParser.TraversalSourceSpawnMethod_customService_argsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSourceSpawnMethod_customService_args_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_args_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSourceSpawnMethod_customService_args_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_args_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterChainedTraversal(GremlinParser.ChainedTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitChainedTraversal(GremlinParser.ChainedTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNestedTraversal(GremlinParser.NestedTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNestedTraversal(GremlinParser.NestedTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTerminatedTraversal(GremlinParser.TerminatedTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTerminatedTraversal(GremlinParser.TerminatedTraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod(GremlinParser.TraversalMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod(GremlinParser.TraversalMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_V(GremlinParser.TraversalMethod_VContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_V(GremlinParser.TraversalMethod_VContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_E(GremlinParser.TraversalMethod_EContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_E(GremlinParser.TraversalMethod_EContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_addE_String(GremlinParser.TraversalMethod_addE_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_addE_String(GremlinParser.TraversalMethod_addE_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_addE_Traversal(GremlinParser.TraversalMethod_addE_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_addE_Traversal(GremlinParser.TraversalMethod_addE_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_addV_Empty(GremlinParser.TraversalMethod_addV_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_addV_Empty(GremlinParser.TraversalMethod_addV_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_addV_String(GremlinParser.TraversalMethod_addV_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_addV_String(GremlinParser.TraversalMethod_addV_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_addV_Traversal(GremlinParser.TraversalMethod_addV_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_addV_Traversal(GremlinParser.TraversalMethod_addV_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_aggregate_String(GremlinParser.TraversalMethod_aggregate_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_aggregate_String(GremlinParser.TraversalMethod_aggregate_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_all_P(GremlinParser.TraversalMethod_all_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_all_P(GremlinParser.TraversalMethod_all_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_and(GremlinParser.TraversalMethod_andContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_and(GremlinParser.TraversalMethod_andContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_any_P(GremlinParser.TraversalMethod_any_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_any_P(GremlinParser.TraversalMethod_any_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_as(GremlinParser.TraversalMethod_asContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_as(GremlinParser.TraversalMethod_asContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_asBool(GremlinParser.TraversalMethod_asBoolContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_asBool(GremlinParser.TraversalMethod_asBoolContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_asDate(GremlinParser.TraversalMethod_asDateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_asDate(GremlinParser.TraversalMethod_asDateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_asNumber_Empty(GremlinParser.TraversalMethod_asNumber_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_asNumber_Empty(GremlinParser.TraversalMethod_asNumber_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_asNumber_traversalGType(GremlinParser.TraversalMethod_asNumber_traversalGTypeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_asNumber_traversalGType(GremlinParser.TraversalMethod_asNumber_traversalGTypeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_asString_Empty(GremlinParser.TraversalMethod_asString_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_asString_Empty(GremlinParser.TraversalMethod_asString_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_asString_Scope(GremlinParser.TraversalMethod_asString_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_asString_Scope(GremlinParser.TraversalMethod_asString_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_barrier_Consumer(GremlinParser.TraversalMethod_barrier_ConsumerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_barrier_Consumer(GremlinParser.TraversalMethod_barrier_ConsumerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_barrier_Empty(GremlinParser.TraversalMethod_barrier_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_barrier_Empty(GremlinParser.TraversalMethod_barrier_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_barrier_int(GremlinParser.TraversalMethod_barrier_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_barrier_int(GremlinParser.TraversalMethod_barrier_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_both(GremlinParser.TraversalMethod_bothContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_both(GremlinParser.TraversalMethod_bothContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_bothE(GremlinParser.TraversalMethod_bothEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_bothE(GremlinParser.TraversalMethod_bothEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_bothV(GremlinParser.TraversalMethod_bothVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_bothV(GremlinParser.TraversalMethod_bothVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_branch(GremlinParser.TraversalMethod_branchContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_branch(GremlinParser.TraversalMethod_branchContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Comparator(GremlinParser.TraversalMethod_by_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Comparator(GremlinParser.TraversalMethod_by_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Empty(GremlinParser.TraversalMethod_by_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Empty(GremlinParser.TraversalMethod_by_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Function(GremlinParser.TraversalMethod_by_FunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Function(GremlinParser.TraversalMethod_by_FunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Function_Comparator(GremlinParser.TraversalMethod_by_Function_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Function_Comparator(GremlinParser.TraversalMethod_by_Function_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Order(GremlinParser.TraversalMethod_by_OrderContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Order(GremlinParser.TraversalMethod_by_OrderContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_String(GremlinParser.TraversalMethod_by_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_String(GremlinParser.TraversalMethod_by_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_String_Comparator(GremlinParser.TraversalMethod_by_String_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_String_Comparator(GremlinParser.TraversalMethod_by_String_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_T(GremlinParser.TraversalMethod_by_TContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_T(GremlinParser.TraversalMethod_by_TContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Traversal(GremlinParser.TraversalMethod_by_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Traversal(GremlinParser.TraversalMethod_by_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_by_Traversal_Comparator(GremlinParser.TraversalMethod_by_Traversal_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_by_Traversal_Comparator(GremlinParser.TraversalMethod_by_Traversal_ComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_call_string(GremlinParser.TraversalMethod_call_stringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_call_string(GremlinParser.TraversalMethod_call_stringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_call_string_map(GremlinParser.TraversalMethod_call_string_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_call_string_map(GremlinParser.TraversalMethod_call_string_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_call_string_traversal(GremlinParser.TraversalMethod_call_string_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_call_string_traversal(GremlinParser.TraversalMethod_call_string_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_call_string_map_traversal(GremlinParser.TraversalMethod_call_string_map_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_call_string_map_traversal(GremlinParser.TraversalMethod_call_string_map_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_customService_empty(GremlinParser.TraversalMethod_customService_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_customService_empty(GremlinParser.TraversalMethod_customService_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_customService_traversal(GremlinParser.TraversalMethod_customService_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_customService_traversal(GremlinParser.TraversalMethod_customService_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_customService_args(GremlinParser.TraversalMethod_customService_argsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_customService_args(GremlinParser.TraversalMethod_customService_argsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_customService_args_traversal(GremlinParser.TraversalMethod_customService_args_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_customService_args_traversal(GremlinParser.TraversalMethod_customService_args_traversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_cap(GremlinParser.TraversalMethod_capContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_cap(GremlinParser.TraversalMethod_capContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_choose_Function(GremlinParser.TraversalMethod_choose_FunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_choose_Function(GremlinParser.TraversalMethod_choose_FunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_choose_Predicate_Traversal(GremlinParser.TraversalMethod_choose_Predicate_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_choose_Predicate_Traversal(GremlinParser.TraversalMethod_choose_Predicate_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_choose_Predicate_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Predicate_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_choose_Predicate_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Predicate_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_choose_Traversal(GremlinParser.TraversalMethod_choose_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_choose_Traversal(GremlinParser.TraversalMethod_choose_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_choose_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_choose_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_choose_Traversal_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_choose_Traversal_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_coalesce(GremlinParser.TraversalMethod_coalesceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_coalesce(GremlinParser.TraversalMethod_coalesceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_coin(GremlinParser.TraversalMethod_coinContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_coin(GremlinParser.TraversalMethod_coinContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_combine_Object(GremlinParser.TraversalMethod_combine_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_combine_Object(GremlinParser.TraversalMethod_combine_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_concat_Traversal_Traversal(GremlinParser.TraversalMethod_concat_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_concat_Traversal_Traversal(GremlinParser.TraversalMethod_concat_Traversal_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_concat_String(GremlinParser.TraversalMethod_concat_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_concat_String(GremlinParser.TraversalMethod_concat_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_conjoin_String(GremlinParser.TraversalMethod_conjoin_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_conjoin_String(GremlinParser.TraversalMethod_conjoin_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_connectedComponent(GremlinParser.TraversalMethod_connectedComponentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_connectedComponent(GremlinParser.TraversalMethod_connectedComponentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_constant(GremlinParser.TraversalMethod_constantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_constant(GremlinParser.TraversalMethod_constantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_count_Empty(GremlinParser.TraversalMethod_count_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_count_Empty(GremlinParser.TraversalMethod_count_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_count_Scope(GremlinParser.TraversalMethod_count_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_count_Scope(GremlinParser.TraversalMethod_count_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_cyclicPath(GremlinParser.TraversalMethod_cyclicPathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_cyclicPath(GremlinParser.TraversalMethod_cyclicPathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_dateAdd(GremlinParser.TraversalMethod_dateAddContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_dateAdd(GremlinParser.TraversalMethod_dateAddContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_dateDiff_Traversal(GremlinParser.TraversalMethod_dateDiff_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_dateDiff_Traversal(GremlinParser.TraversalMethod_dateDiff_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_dateDiff_Date(GremlinParser.TraversalMethod_dateDiff_DateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_dateDiff_Date(GremlinParser.TraversalMethod_dateDiff_DateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_dedup_Scope_String(GremlinParser.TraversalMethod_dedup_Scope_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_dedup_Scope_String(GremlinParser.TraversalMethod_dedup_Scope_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_dedup_String(GremlinParser.TraversalMethod_dedup_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_dedup_String(GremlinParser.TraversalMethod_dedup_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_difference_Object(GremlinParser.TraversalMethod_difference_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_difference_Object(GremlinParser.TraversalMethod_difference_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_discard(GremlinParser.TraversalMethod_discardContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_discard(GremlinParser.TraversalMethod_discardContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_disjunct_Object(GremlinParser.TraversalMethod_disjunct_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_disjunct_Object(GremlinParser.TraversalMethod_disjunct_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_drop(GremlinParser.TraversalMethod_dropContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_drop(GremlinParser.TraversalMethod_dropContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_element(GremlinParser.TraversalMethod_elementContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_element(GremlinParser.TraversalMethod_elementContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_elementMap(GremlinParser.TraversalMethod_elementMapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_elementMap(GremlinParser.TraversalMethod_elementMapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_emit_Empty(GremlinParser.TraversalMethod_emit_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_emit_Empty(GremlinParser.TraversalMethod_emit_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_emit_Predicate(GremlinParser.TraversalMethod_emit_PredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_emit_Predicate(GremlinParser.TraversalMethod_emit_PredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_emit_Traversal(GremlinParser.TraversalMethod_emit_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_emit_Traversal(GremlinParser.TraversalMethod_emit_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_fail_Empty(GremlinParser.TraversalMethod_fail_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_fail_Empty(GremlinParser.TraversalMethod_fail_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_fail_String(GremlinParser.TraversalMethod_fail_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_fail_String(GremlinParser.TraversalMethod_fail_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_filter_Predicate(GremlinParser.TraversalMethod_filter_PredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_filter_Predicate(GremlinParser.TraversalMethod_filter_PredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_filter_Traversal(GremlinParser.TraversalMethod_filter_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_filter_Traversal(GremlinParser.TraversalMethod_filter_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_flatMap(GremlinParser.TraversalMethod_flatMapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_flatMap(GremlinParser.TraversalMethod_flatMapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_fold_Empty(GremlinParser.TraversalMethod_fold_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_fold_Empty(GremlinParser.TraversalMethod_fold_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_fold_Object_BiFunction(GremlinParser.TraversalMethod_fold_Object_BiFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_fold_Object_BiFunction(GremlinParser.TraversalMethod_fold_Object_BiFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_format_String(GremlinParser.TraversalMethod_format_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_format_String(GremlinParser.TraversalMethod_format_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_from_String(GremlinParser.TraversalMethod_from_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_from_String(GremlinParser.TraversalMethod_from_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_from_Traversal(GremlinParser.TraversalMethod_from_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_from_Traversal(GremlinParser.TraversalMethod_from_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_group_Empty(GremlinParser.TraversalMethod_group_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_group_Empty(GremlinParser.TraversalMethod_group_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_group_String(GremlinParser.TraversalMethod_group_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_group_String(GremlinParser.TraversalMethod_group_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_groupCount_Empty(GremlinParser.TraversalMethod_groupCount_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_groupCount_Empty(GremlinParser.TraversalMethod_groupCount_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_groupCount_String(GremlinParser.TraversalMethod_groupCount_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_groupCount_String(GremlinParser.TraversalMethod_groupCount_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_String(GremlinParser.TraversalMethod_has_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_String(GremlinParser.TraversalMethod_has_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_String_Object(GremlinParser.TraversalMethod_has_String_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_String_Object(GremlinParser.TraversalMethod_has_String_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_String_P(GremlinParser.TraversalMethod_has_String_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_String_P(GremlinParser.TraversalMethod_has_String_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_String_String_Object(GremlinParser.TraversalMethod_has_String_String_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_String_String_Object(GremlinParser.TraversalMethod_has_String_String_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_String_String_P(GremlinParser.TraversalMethod_has_String_String_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_String_String_P(GremlinParser.TraversalMethod_has_String_String_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_T_Object(GremlinParser.TraversalMethod_has_T_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_T_Object(GremlinParser.TraversalMethod_has_T_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_has_T_P(GremlinParser.TraversalMethod_has_T_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_has_T_P(GremlinParser.TraversalMethod_has_T_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasId_Object_Object(GremlinParser.TraversalMethod_hasId_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasId_Object_Object(GremlinParser.TraversalMethod_hasId_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasId_P(GremlinParser.TraversalMethod_hasId_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasId_P(GremlinParser.TraversalMethod_hasId_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasKey_P(GremlinParser.TraversalMethod_hasKey_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasKey_P(GremlinParser.TraversalMethod_hasKey_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasKey_String_String(GremlinParser.TraversalMethod_hasKey_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasKey_String_String(GremlinParser.TraversalMethod_hasKey_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasLabel_P(GremlinParser.TraversalMethod_hasLabel_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasLabel_P(GremlinParser.TraversalMethod_hasLabel_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasLabel_String_String(GremlinParser.TraversalMethod_hasLabel_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasLabel_String_String(GremlinParser.TraversalMethod_hasLabel_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasNot(GremlinParser.TraversalMethod_hasNotContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasNot(GremlinParser.TraversalMethod_hasNotContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasValue_Object_Object(GremlinParser.TraversalMethod_hasValue_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasValue_Object_Object(GremlinParser.TraversalMethod_hasValue_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_hasValue_P(GremlinParser.TraversalMethod_hasValue_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_hasValue_P(GremlinParser.TraversalMethod_hasValue_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_id(GremlinParser.TraversalMethod_idContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_id(GremlinParser.TraversalMethod_idContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_identity(GremlinParser.TraversalMethod_identityContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_identity(GremlinParser.TraversalMethod_identityContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_in(GremlinParser.TraversalMethod_inContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_in(GremlinParser.TraversalMethod_inContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_inE(GremlinParser.TraversalMethod_inEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_inE(GremlinParser.TraversalMethod_inEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_intersect_Object(GremlinParser.TraversalMethod_intersect_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_intersect_Object(GremlinParser.TraversalMethod_intersect_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_inV(GremlinParser.TraversalMethod_inVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_inV(GremlinParser.TraversalMethod_inVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_index(GremlinParser.TraversalMethod_indexContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_index(GremlinParser.TraversalMethod_indexContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_inject(GremlinParser.TraversalMethod_injectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_inject(GremlinParser.TraversalMethod_injectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_is_Object(GremlinParser.TraversalMethod_is_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_is_Object(GremlinParser.TraversalMethod_is_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_is_P(GremlinParser.TraversalMethod_is_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_is_P(GremlinParser.TraversalMethod_is_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_key(GremlinParser.TraversalMethod_keyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_key(GremlinParser.TraversalMethod_keyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_label(GremlinParser.TraversalMethod_labelContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_label(GremlinParser.TraversalMethod_labelContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_length_Empty(GremlinParser.TraversalMethod_length_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_length_Empty(GremlinParser.TraversalMethod_length_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_length_Scope(GremlinParser.TraversalMethod_length_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_length_Scope(GremlinParser.TraversalMethod_length_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_limit_Scope_long(GremlinParser.TraversalMethod_limit_Scope_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_limit_Scope_long(GremlinParser.TraversalMethod_limit_Scope_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_limit_long(GremlinParser.TraversalMethod_limit_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_limit_long(GremlinParser.TraversalMethod_limit_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_local(GremlinParser.TraversalMethod_localContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_local(GremlinParser.TraversalMethod_localContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_loops_Empty(GremlinParser.TraversalMethod_loops_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_loops_Empty(GremlinParser.TraversalMethod_loops_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_loops_String(GremlinParser.TraversalMethod_loops_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_loops_String(GremlinParser.TraversalMethod_loops_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_lTrim_Empty(GremlinParser.TraversalMethod_lTrim_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_lTrim_Empty(GremlinParser.TraversalMethod_lTrim_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_lTrim_Scope(GremlinParser.TraversalMethod_lTrim_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_lTrim_Scope(GremlinParser.TraversalMethod_lTrim_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_map(GremlinParser.TraversalMethod_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_map(GremlinParser.TraversalMethod_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_match(GremlinParser.TraversalMethod_matchContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_match(GremlinParser.TraversalMethod_matchContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_math(GremlinParser.TraversalMethod_mathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_math(GremlinParser.TraversalMethod_mathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_max_Empty(GremlinParser.TraversalMethod_max_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_max_Empty(GremlinParser.TraversalMethod_max_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_max_Scope(GremlinParser.TraversalMethod_max_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_max_Scope(GremlinParser.TraversalMethod_max_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mean_Empty(GremlinParser.TraversalMethod_mean_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mean_Empty(GremlinParser.TraversalMethod_mean_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mean_Scope(GremlinParser.TraversalMethod_mean_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mean_Scope(GremlinParser.TraversalMethod_mean_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_merge_Object(GremlinParser.TraversalMethod_merge_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_merge_Object(GremlinParser.TraversalMethod_merge_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mergeV_empty(GremlinParser.TraversalMethod_mergeV_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mergeV_empty(GremlinParser.TraversalMethod_mergeV_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mergeV_Map(GremlinParser.TraversalMethod_mergeV_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mergeV_Map(GremlinParser.TraversalMethod_mergeV_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mergeV_Traversal(GremlinParser.TraversalMethod_mergeV_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mergeV_Traversal(GremlinParser.TraversalMethod_mergeV_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mergeE_empty(GremlinParser.TraversalMethod_mergeE_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mergeE_empty(GremlinParser.TraversalMethod_mergeE_emptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mergeE_Map(GremlinParser.TraversalMethod_mergeE_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mergeE_Map(GremlinParser.TraversalMethod_mergeE_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_mergeE_Traversal(GremlinParser.TraversalMethod_mergeE_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_mergeE_Traversal(GremlinParser.TraversalMethod_mergeE_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_min_Empty(GremlinParser.TraversalMethod_min_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_min_Empty(GremlinParser.TraversalMethod_min_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_min_Scope(GremlinParser.TraversalMethod_min_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_min_Scope(GremlinParser.TraversalMethod_min_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_none_P(GremlinParser.TraversalMethod_none_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_none_P(GremlinParser.TraversalMethod_none_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_not(GremlinParser.TraversalMethod_notContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_not(GremlinParser.TraversalMethod_notContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_option_Predicate_Traversal(GremlinParser.TraversalMethod_option_Predicate_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_option_Predicate_Traversal(GremlinParser.TraversalMethod_option_Predicate_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_option_Merge_Map(GremlinParser.TraversalMethod_option_Merge_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_option_Merge_Map(GremlinParser.TraversalMethod_option_Merge_MapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_option_Merge_Map_Cardinality(GremlinParser.TraversalMethod_option_Merge_Map_CardinalityContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_option_Merge_Map_Cardinality(GremlinParser.TraversalMethod_option_Merge_Map_CardinalityContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_option_Merge_Traversal(GremlinParser.TraversalMethod_option_Merge_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_option_Merge_Traversal(GremlinParser.TraversalMethod_option_Merge_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_option_Object_Traversal(GremlinParser.TraversalMethod_option_Object_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_option_Object_Traversal(GremlinParser.TraversalMethod_option_Object_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_option_Traversal(GremlinParser.TraversalMethod_option_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_option_Traversal(GremlinParser.TraversalMethod_option_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_optional(GremlinParser.TraversalMethod_optionalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_optional(GremlinParser.TraversalMethod_optionalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_or(GremlinParser.TraversalMethod_orContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_or(GremlinParser.TraversalMethod_orContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_order_Empty(GremlinParser.TraversalMethod_order_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_order_Empty(GremlinParser.TraversalMethod_order_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_order_Scope(GremlinParser.TraversalMethod_order_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_order_Scope(GremlinParser.TraversalMethod_order_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_otherV(GremlinParser.TraversalMethod_otherVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_otherV(GremlinParser.TraversalMethod_otherVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_out(GremlinParser.TraversalMethod_outContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_out(GremlinParser.TraversalMethod_outContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_outE(GremlinParser.TraversalMethod_outEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_outE(GremlinParser.TraversalMethod_outEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_outV(GremlinParser.TraversalMethod_outVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_outV(GremlinParser.TraversalMethod_outVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_pageRank_Empty(GremlinParser.TraversalMethod_pageRank_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_pageRank_Empty(GremlinParser.TraversalMethod_pageRank_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_pageRank_double(GremlinParser.TraversalMethod_pageRank_doubleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_pageRank_double(GremlinParser.TraversalMethod_pageRank_doubleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_path(GremlinParser.TraversalMethod_pathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_path(GremlinParser.TraversalMethod_pathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_peerPressure(GremlinParser.TraversalMethod_peerPressureContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_peerPressure(GremlinParser.TraversalMethod_peerPressureContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_product_Object(GremlinParser.TraversalMethod_product_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_product_Object(GremlinParser.TraversalMethod_product_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_profile_Empty(GremlinParser.TraversalMethod_profile_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_profile_Empty(GremlinParser.TraversalMethod_profile_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_profile_String(GremlinParser.TraversalMethod_profile_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_profile_String(GremlinParser.TraversalMethod_profile_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_project(GremlinParser.TraversalMethod_projectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_project(GremlinParser.TraversalMethod_projectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_properties(GremlinParser.TraversalMethod_propertiesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_properties(GremlinParser.TraversalMethod_propertiesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_property_Cardinality_Object_Object_Object(GremlinParser.TraversalMethod_property_Cardinality_Object_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_property_Cardinality_Object_Object_Object(GremlinParser.TraversalMethod_property_Cardinality_Object_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_property_Cardinality_Object(GremlinParser.TraversalMethod_property_Cardinality_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_property_Cardinality_Object(GremlinParser.TraversalMethod_property_Cardinality_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_property_Object_Object_Object(GremlinParser.TraversalMethod_property_Object_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_property_Object_Object_Object(GremlinParser.TraversalMethod_property_Object_Object_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_property_Object(GremlinParser.TraversalMethod_property_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_property_Object(GremlinParser.TraversalMethod_property_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_propertyMap(GremlinParser.TraversalMethod_propertyMapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_propertyMap(GremlinParser.TraversalMethod_propertyMapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_range_Scope_long_long(GremlinParser.TraversalMethod_range_Scope_long_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_range_Scope_long_long(GremlinParser.TraversalMethod_range_Scope_long_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_range_long_long(GremlinParser.TraversalMethod_range_long_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_range_long_long(GremlinParser.TraversalMethod_range_long_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_read(GremlinParser.TraversalMethod_readContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_read(GremlinParser.TraversalMethod_readContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_repeat_String_Traversal(GremlinParser.TraversalMethod_repeat_String_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_repeat_String_Traversal(GremlinParser.TraversalMethod_repeat_String_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_repeat_Traversal(GremlinParser.TraversalMethod_repeat_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_repeat_Traversal(GremlinParser.TraversalMethod_repeat_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_replace_String_String(GremlinParser.TraversalMethod_replace_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_replace_String_String(GremlinParser.TraversalMethod_replace_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_replace_Scope_String_String(GremlinParser.TraversalMethod_replace_Scope_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_replace_Scope_String_String(GremlinParser.TraversalMethod_replace_Scope_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_reverse_Empty(GremlinParser.TraversalMethod_reverse_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_reverse_Empty(GremlinParser.TraversalMethod_reverse_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_rTrim_Empty(GremlinParser.TraversalMethod_rTrim_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_rTrim_Empty(GremlinParser.TraversalMethod_rTrim_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_rTrim_Scope(GremlinParser.TraversalMethod_rTrim_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_rTrim_Scope(GremlinParser.TraversalMethod_rTrim_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sack_BiFunction(GremlinParser.TraversalMethod_sack_BiFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sack_BiFunction(GremlinParser.TraversalMethod_sack_BiFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sack_Empty(GremlinParser.TraversalMethod_sack_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sack_Empty(GremlinParser.TraversalMethod_sack_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sample_Scope_int(GremlinParser.TraversalMethod_sample_Scope_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sample_Scope_int(GremlinParser.TraversalMethod_sample_Scope_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sample_int(GremlinParser.TraversalMethod_sample_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sample_int(GremlinParser.TraversalMethod_sample_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_Column(GremlinParser.TraversalMethod_select_ColumnContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_Column(GremlinParser.TraversalMethod_select_ColumnContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_Pop_String(GremlinParser.TraversalMethod_select_Pop_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_Pop_String(GremlinParser.TraversalMethod_select_Pop_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_Pop_String_String_String(GremlinParser.TraversalMethod_select_Pop_String_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_Pop_String_String_String(GremlinParser.TraversalMethod_select_Pop_String_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_Pop_Traversal(GremlinParser.TraversalMethod_select_Pop_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_Pop_Traversal(GremlinParser.TraversalMethod_select_Pop_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_String(GremlinParser.TraversalMethod_select_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_String(GremlinParser.TraversalMethod_select_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_String_String_String(GremlinParser.TraversalMethod_select_String_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_String_String_String(GremlinParser.TraversalMethod_select_String_String_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_select_Traversal(GremlinParser.TraversalMethod_select_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_select_Traversal(GremlinParser.TraversalMethod_select_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_shortestPath(GremlinParser.TraversalMethod_shortestPathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_shortestPath(GremlinParser.TraversalMethod_shortestPathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sideEffect(GremlinParser.TraversalMethod_sideEffectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sideEffect(GremlinParser.TraversalMethod_sideEffectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_simplePath(GremlinParser.TraversalMethod_simplePathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_simplePath(GremlinParser.TraversalMethod_simplePathContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_skip_Scope_long(GremlinParser.TraversalMethod_skip_Scope_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_skip_Scope_long(GremlinParser.TraversalMethod_skip_Scope_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_skip_long(GremlinParser.TraversalMethod_skip_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_skip_long(GremlinParser.TraversalMethod_skip_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_split_String(GremlinParser.TraversalMethod_split_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_split_String(GremlinParser.TraversalMethod_split_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_split_Scope_String(GremlinParser.TraversalMethod_split_Scope_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_split_Scope_String(GremlinParser.TraversalMethod_split_Scope_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_subgraph(GremlinParser.TraversalMethod_subgraphContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_subgraph(GremlinParser.TraversalMethod_subgraphContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_substring_int(GremlinParser.TraversalMethod_substring_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_substring_int(GremlinParser.TraversalMethod_substring_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_substring_Scope_int(GremlinParser.TraversalMethod_substring_Scope_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_substring_Scope_int(GremlinParser.TraversalMethod_substring_Scope_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_substring_int_int(GremlinParser.TraversalMethod_substring_int_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_substring_int_int(GremlinParser.TraversalMethod_substring_int_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_substring_Scope_int_int(GremlinParser.TraversalMethod_substring_Scope_int_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_substring_Scope_int_int(GremlinParser.TraversalMethod_substring_Scope_int_intContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sum_Empty(GremlinParser.TraversalMethod_sum_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sum_Empty(GremlinParser.TraversalMethod_sum_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_sum_Scope(GremlinParser.TraversalMethod_sum_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_sum_Scope(GremlinParser.TraversalMethod_sum_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_tail_Empty(GremlinParser.TraversalMethod_tail_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_tail_Empty(GremlinParser.TraversalMethod_tail_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_tail_Scope(GremlinParser.TraversalMethod_tail_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_tail_Scope(GremlinParser.TraversalMethod_tail_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_tail_Scope_long(GremlinParser.TraversalMethod_tail_Scope_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_tail_Scope_long(GremlinParser.TraversalMethod_tail_Scope_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_tail_long(GremlinParser.TraversalMethod_tail_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_tail_long(GremlinParser.TraversalMethod_tail_longContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_timeLimit(GremlinParser.TraversalMethod_timeLimitContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_timeLimit(GremlinParser.TraversalMethod_timeLimitContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_times(GremlinParser.TraversalMethod_timesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_times(GremlinParser.TraversalMethod_timesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_to_Direction_String(GremlinParser.TraversalMethod_to_Direction_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_to_Direction_String(GremlinParser.TraversalMethod_to_Direction_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_to_String(GremlinParser.TraversalMethod_to_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_to_String(GremlinParser.TraversalMethod_to_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_to_Traversal(GremlinParser.TraversalMethod_to_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_to_Traversal(GremlinParser.TraversalMethod_to_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_toE(GremlinParser.TraversalMethod_toEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_toE(GremlinParser.TraversalMethod_toEContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_toLower_Empty(GremlinParser.TraversalMethod_toLower_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_toLower_Empty(GremlinParser.TraversalMethod_toLower_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_toLower_Scope(GremlinParser.TraversalMethod_toLower_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_toLower_Scope(GremlinParser.TraversalMethod_toLower_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_toUpper_Empty(GremlinParser.TraversalMethod_toUpper_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_toUpper_Empty(GremlinParser.TraversalMethod_toUpper_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_toUpper_Scope(GremlinParser.TraversalMethod_toUpper_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_toUpper_Scope(GremlinParser.TraversalMethod_toUpper_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_toV(GremlinParser.TraversalMethod_toVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_toV(GremlinParser.TraversalMethod_toVContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_tree_Empty(GremlinParser.TraversalMethod_tree_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_tree_Empty(GremlinParser.TraversalMethod_tree_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_tree_String(GremlinParser.TraversalMethod_tree_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_tree_String(GremlinParser.TraversalMethod_tree_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_trim_Empty(GremlinParser.TraversalMethod_trim_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_trim_Empty(GremlinParser.TraversalMethod_trim_EmptyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_trim_Scope(GremlinParser.TraversalMethod_trim_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_trim_Scope(GremlinParser.TraversalMethod_trim_ScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_unfold(GremlinParser.TraversalMethod_unfoldContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_unfold(GremlinParser.TraversalMethod_unfoldContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_union(GremlinParser.TraversalMethod_unionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_union(GremlinParser.TraversalMethod_unionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_until_Predicate(GremlinParser.TraversalMethod_until_PredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_until_Predicate(GremlinParser.TraversalMethod_until_PredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_until_Traversal(GremlinParser.TraversalMethod_until_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_until_Traversal(GremlinParser.TraversalMethod_until_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_value(GremlinParser.TraversalMethod_valueContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_value(GremlinParser.TraversalMethod_valueContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_valueMap_String(GremlinParser.TraversalMethod_valueMap_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_valueMap_String(GremlinParser.TraversalMethod_valueMap_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_valueMap_boolean_String(GremlinParser.TraversalMethod_valueMap_boolean_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_valueMap_boolean_String(GremlinParser.TraversalMethod_valueMap_boolean_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_values(GremlinParser.TraversalMethod_valuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_values(GremlinParser.TraversalMethod_valuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_where_P(GremlinParser.TraversalMethod_where_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_where_P(GremlinParser.TraversalMethod_where_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_where_String_P(GremlinParser.TraversalMethod_where_String_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_where_String_P(GremlinParser.TraversalMethod_where_String_PContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_where_Traversal(GremlinParser.TraversalMethod_where_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_where_Traversal(GremlinParser.TraversalMethod_where_TraversalContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_with_String(GremlinParser.TraversalMethod_with_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_with_String(GremlinParser.TraversalMethod_with_StringContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_with_String_Object(GremlinParser.TraversalMethod_with_String_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_with_String_Object(GremlinParser.TraversalMethod_with_String_ObjectContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMethod_write(GremlinParser.TraversalMethod_writeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMethod_write(GremlinParser.TraversalMethod_writeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalStrategy(GremlinParser.TraversalStrategyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalStrategy(GremlinParser.TraversalStrategyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterConfiguration(GremlinParser.ConfigurationContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitConfiguration(GremlinParser.ConfigurationContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalScope(GremlinParser.TraversalScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalScope(GremlinParser.TraversalScopeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalBarrier(GremlinParser.TraversalBarrierContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalBarrier(GremlinParser.TraversalBarrierContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalT(GremlinParser.TraversalTContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalT(GremlinParser.TraversalTContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTShort(GremlinParser.TraversalTShortContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTShort(GremlinParser.TraversalTShortContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTLong(GremlinParser.TraversalTLongContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTLong(GremlinParser.TraversalTLongContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalMerge(GremlinParser.TraversalMergeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalMerge(GremlinParser.TraversalMergeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalOrder(GremlinParser.TraversalOrderContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalOrder(GremlinParser.TraversalOrderContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalDirection(GremlinParser.TraversalDirectionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalDirection(GremlinParser.TraversalDirectionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalDirectionShort(GremlinParser.TraversalDirectionShortContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalDirectionShort(GremlinParser.TraversalDirectionShortContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalDirectionLong(GremlinParser.TraversalDirectionLongContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalDirectionLong(GremlinParser.TraversalDirectionLongContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalCardinality(GremlinParser.TraversalCardinalityContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalCardinality(GremlinParser.TraversalCardinalityContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalColumn(GremlinParser.TraversalColumnContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalColumn(GremlinParser.TraversalColumnContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPop(GremlinParser.TraversalPopContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPop(GremlinParser.TraversalPopContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalOperator(GremlinParser.TraversalOperatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalOperator(GremlinParser.TraversalOperatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPick(GremlinParser.TraversalPickContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPick(GremlinParser.TraversalPickContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalDT(GremlinParser.TraversalDTContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalDT(GremlinParser.TraversalDTContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalGType(GremlinParser.TraversalGTypeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalGType(GremlinParser.TraversalGTypeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate(GremlinParser.TraversalPredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate(GremlinParser.TraversalPredicateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod(GremlinParser.TraversalTerminalMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod(GremlinParser.TraversalTerminalMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalSackMethod(GremlinParser.TraversalSackMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalSackMethod(GremlinParser.TraversalSackMethodContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalComparator(GremlinParser.TraversalComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalComparator(GremlinParser.TraversalComparatorContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalFunction(GremlinParser.TraversalFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalFunction(GremlinParser.TraversalFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalBiFunction(GremlinParser.TraversalBiFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalBiFunction(GremlinParser.TraversalBiFunctionContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_eq(GremlinParser.TraversalPredicate_eqContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_eq(GremlinParser.TraversalPredicate_eqContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_neq(GremlinParser.TraversalPredicate_neqContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_neq(GremlinParser.TraversalPredicate_neqContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_typeOf(GremlinParser.TraversalPredicate_typeOfContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_typeOf(GremlinParser.TraversalPredicate_typeOfContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_lt(GremlinParser.TraversalPredicate_ltContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_lt(GremlinParser.TraversalPredicate_ltContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_lte(GremlinParser.TraversalPredicate_lteContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_lte(GremlinParser.TraversalPredicate_lteContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_gt(GremlinParser.TraversalPredicate_gtContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_gt(GremlinParser.TraversalPredicate_gtContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_gte(GremlinParser.TraversalPredicate_gteContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_gte(GremlinParser.TraversalPredicate_gteContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_inside(GremlinParser.TraversalPredicate_insideContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_inside(GremlinParser.TraversalPredicate_insideContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_outside(GremlinParser.TraversalPredicate_outsideContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_outside(GremlinParser.TraversalPredicate_outsideContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_between(GremlinParser.TraversalPredicate_betweenContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_between(GremlinParser.TraversalPredicate_betweenContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_within(GremlinParser.TraversalPredicate_withinContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_within(GremlinParser.TraversalPredicate_withinContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_without(GremlinParser.TraversalPredicate_withoutContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_without(GremlinParser.TraversalPredicate_withoutContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_not(GremlinParser.TraversalPredicate_notContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_not(GremlinParser.TraversalPredicate_notContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_containing(GremlinParser.TraversalPredicate_containingContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_containing(GremlinParser.TraversalPredicate_containingContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_notContaining(GremlinParser.TraversalPredicate_notContainingContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_notContaining(GremlinParser.TraversalPredicate_notContainingContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_startingWith(GremlinParser.TraversalPredicate_startingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_startingWith(GremlinParser.TraversalPredicate_startingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_notStartingWith(GremlinParser.TraversalPredicate_notStartingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_notStartingWith(GremlinParser.TraversalPredicate_notStartingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_endingWith(GremlinParser.TraversalPredicate_endingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_endingWith(GremlinParser.TraversalPredicate_endingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_notEndingWith(GremlinParser.TraversalPredicate_notEndingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_notEndingWith(GremlinParser.TraversalPredicate_notEndingWithContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_regex(GremlinParser.TraversalPredicate_regexContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_regex(GremlinParser.TraversalPredicate_regexContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalPredicate_notRegex(GremlinParser.TraversalPredicate_notRegexContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalPredicate_notRegex(GremlinParser.TraversalPredicate_notRegexContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_explain(GremlinParser.TraversalTerminalMethod_explainContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_explain(GremlinParser.TraversalTerminalMethod_explainContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_hasNext(GremlinParser.TraversalTerminalMethod_hasNextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_hasNext(GremlinParser.TraversalTerminalMethod_hasNextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_iterate(GremlinParser.TraversalTerminalMethod_iterateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_iterate(GremlinParser.TraversalTerminalMethod_iterateContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_tryNext(GremlinParser.TraversalTerminalMethod_tryNextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_tryNext(GremlinParser.TraversalTerminalMethod_tryNextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_next(GremlinParser.TraversalTerminalMethod_nextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_next(GremlinParser.TraversalTerminalMethod_nextContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_toList(GremlinParser.TraversalTerminalMethod_toListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_toList(GremlinParser.TraversalTerminalMethod_toListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_toSet(GremlinParser.TraversalTerminalMethod_toSetContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_toSet(GremlinParser.TraversalTerminalMethod_toSetContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalTerminalMethod_toBulkSet(GremlinParser.TraversalTerminalMethod_toBulkSetContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalTerminalMethod_toBulkSet(GremlinParser.TraversalTerminalMethod_toBulkSetContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionKeys(GremlinParser.WithOptionKeysContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionKeys(GremlinParser.WithOptionKeysContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterConnectedComponentConstants(GremlinParser.ConnectedComponentConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitConnectedComponentConstants(GremlinParser.ConnectedComponentConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPageRankConstants(GremlinParser.PageRankConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPageRankConstants(GremlinParser.PageRankConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPeerPressureConstants(GremlinParser.PeerPressureConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPeerPressureConstants(GremlinParser.PeerPressureConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathConstants(GremlinParser.ShortestPathConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathConstants(GremlinParser.ShortestPathConstantsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsValues(GremlinParser.WithOptionsValuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsValues(GremlinParser.WithOptionsValuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsKeys(GremlinParser.IoOptionsKeysContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsKeys(GremlinParser.IoOptionsKeysContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsValues(GremlinParser.IoOptionsValuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsValues(GremlinParser.IoOptionsValuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterConnectedComponentConstants_component(GremlinParser.ConnectedComponentConstants_componentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitConnectedComponentConstants_component(GremlinParser.ConnectedComponentConstants_componentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterConnectedComponentConstants_edges(GremlinParser.ConnectedComponentConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitConnectedComponentConstants_edges(GremlinParser.ConnectedComponentConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterConnectedComponentConstants_propertyName(GremlinParser.ConnectedComponentConstants_propertyNameContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitConnectedComponentConstants_propertyName(GremlinParser.ConnectedComponentConstants_propertyNameContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPageRankConstants_edges(GremlinParser.PageRankConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPageRankConstants_edges(GremlinParser.PageRankConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPageRankConstants_times(GremlinParser.PageRankConstants_timesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPageRankConstants_times(GremlinParser.PageRankConstants_timesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPageRankConstants_propertyName(GremlinParser.PageRankConstants_propertyNameContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPageRankConstants_propertyName(GremlinParser.PageRankConstants_propertyNameContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPeerPressureConstants_edges(GremlinParser.PeerPressureConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPeerPressureConstants_edges(GremlinParser.PeerPressureConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPeerPressureConstants_times(GremlinParser.PeerPressureConstants_timesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPeerPressureConstants_times(GremlinParser.PeerPressureConstants_timesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPeerPressureConstants_propertyName(GremlinParser.PeerPressureConstants_propertyNameContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPeerPressureConstants_propertyName(GremlinParser.PeerPressureConstants_propertyNameContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathConstants_target(GremlinParser.ShortestPathConstants_targetContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathConstants_target(GremlinParser.ShortestPathConstants_targetContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathConstants_edges(GremlinParser.ShortestPathConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathConstants_edges(GremlinParser.ShortestPathConstants_edgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathConstants_distance(GremlinParser.ShortestPathConstants_distanceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathConstants_distance(GremlinParser.ShortestPathConstants_distanceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathConstants_maxDistance(GremlinParser.ShortestPathConstants_maxDistanceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathConstants_maxDistance(GremlinParser.ShortestPathConstants_maxDistanceContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathConstants_includeEdges(GremlinParser.ShortestPathConstants_includeEdgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathConstants_includeEdges(GremlinParser.ShortestPathConstants_includeEdgesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_tokens(GremlinParser.WithOptionsConstants_tokensContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_tokens(GremlinParser.WithOptionsConstants_tokensContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_none(GremlinParser.WithOptionsConstants_noneContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_none(GremlinParser.WithOptionsConstants_noneContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_ids(GremlinParser.WithOptionsConstants_idsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_ids(GremlinParser.WithOptionsConstants_idsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_labels(GremlinParser.WithOptionsConstants_labelsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_labels(GremlinParser.WithOptionsConstants_labelsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_keys(GremlinParser.WithOptionsConstants_keysContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_keys(GremlinParser.WithOptionsConstants_keysContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_values(GremlinParser.WithOptionsConstants_valuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_values(GremlinParser.WithOptionsConstants_valuesContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_all(GremlinParser.WithOptionsConstants_allContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_all(GremlinParser.WithOptionsConstants_allContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_indexer(GremlinParser.WithOptionsConstants_indexerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_indexer(GremlinParser.WithOptionsConstants_indexerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_list(GremlinParser.WithOptionsConstants_listContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_list(GremlinParser.WithOptionsConstants_listContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsConstants_map(GremlinParser.WithOptionsConstants_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsConstants_map(GremlinParser.WithOptionsConstants_mapContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsConstants_reader(GremlinParser.IoOptionsConstants_readerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsConstants_reader(GremlinParser.IoOptionsConstants_readerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsConstants_writer(GremlinParser.IoOptionsConstants_writerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsConstants_writer(GremlinParser.IoOptionsConstants_writerContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsConstants_gryo(GremlinParser.IoOptionsConstants_gryoContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsConstants_gryo(GremlinParser.IoOptionsConstants_gryoContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsConstants_graphson(GremlinParser.IoOptionsConstants_graphsonContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsConstants_graphson(GremlinParser.IoOptionsConstants_graphsonContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsConstants_graphml(GremlinParser.IoOptionsConstants_graphmlContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsConstants_graphml(GremlinParser.IoOptionsConstants_graphmlContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterConnectedComponentStringConstant(GremlinParser.ConnectedComponentStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitConnectedComponentStringConstant(GremlinParser.ConnectedComponentStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPageRankStringConstant(GremlinParser.PageRankStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPageRankStringConstant(GremlinParser.PageRankStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterPeerPressureStringConstant(GremlinParser.PeerPressureStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitPeerPressureStringConstant(GremlinParser.PeerPressureStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterShortestPathStringConstant(GremlinParser.ShortestPathStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitShortestPathStringConstant(GremlinParser.ShortestPathStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterWithOptionsStringConstant(GremlinParser.WithOptionsStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitWithOptionsStringConstant(GremlinParser.WithOptionsStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIoOptionsStringConstant(GremlinParser.IoOptionsStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIoOptionsStringConstant(GremlinParser.IoOptionsStringConstantContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterBooleanArgument(GremlinParser.BooleanArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitBooleanArgument(GremlinParser.BooleanArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIntegerArgument(GremlinParser.IntegerArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIntegerArgument(GremlinParser.IntegerArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterFloatArgument(GremlinParser.FloatArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitFloatArgument(GremlinParser.FloatArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterStringArgument(GremlinParser.StringArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitStringArgument(GremlinParser.StringArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterStringNullableArgument(GremlinParser.StringNullableArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitStringNullableArgument(GremlinParser.StringNullableArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterStringNullableArgumentVarargs(GremlinParser.StringNullableArgumentVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitStringNullableArgumentVarargs(GremlinParser.StringNullableArgumentVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterDateArgument(GremlinParser.DateArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitDateArgument(GremlinParser.DateArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericArgument(GremlinParser.GenericArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericArgument(GremlinParser.GenericArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericArgumentVarargs(GremlinParser.GenericArgumentVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericArgumentVarargs(GremlinParser.GenericArgumentVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericMapArgument(GremlinParser.GenericMapArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericMapArgument(GremlinParser.GenericMapArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericMapNullableArgument(GremlinParser.GenericMapNullableArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericMapNullableArgument(GremlinParser.GenericMapNullableArgumentContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalStrategyVarargs(GremlinParser.TraversalStrategyVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalStrategyVarargs(GremlinParser.TraversalStrategyVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterTraversalStrategyExpr(GremlinParser.TraversalStrategyExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitTraversalStrategyExpr(GremlinParser.TraversalStrategyExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterClassTypeList(GremlinParser.ClassTypeListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitClassTypeList(GremlinParser.ClassTypeListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterClassTypeExpr(GremlinParser.ClassTypeExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitClassTypeExpr(GremlinParser.ClassTypeExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNestedTraversalList(GremlinParser.NestedTraversalListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNestedTraversalList(GremlinParser.NestedTraversalListContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNestedTraversalExpr(GremlinParser.NestedTraversalExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNestedTraversalExpr(GremlinParser.NestedTraversalExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericCollectionLiteral(GremlinParser.GenericCollectionLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericCollectionLiteral(GremlinParser.GenericCollectionLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericLiteralVarargs(GremlinParser.GenericLiteralVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericLiteralVarargs(GremlinParser.GenericLiteralVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericLiteralExpr(GremlinParser.GenericLiteralExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericLiteralExpr(GremlinParser.GenericLiteralExprContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericMapNullableLiteral(GremlinParser.GenericMapNullableLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericMapNullableLiteral(GremlinParser.GenericMapNullableLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericRangeLiteral(GremlinParser.GenericRangeLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericRangeLiteral(GremlinParser.GenericRangeLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericSetLiteral(GremlinParser.GenericSetLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericSetLiteral(GremlinParser.GenericSetLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterStringNullableLiteralVarargs(GremlinParser.StringNullableLiteralVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitStringNullableLiteralVarargs(GremlinParser.StringNullableLiteralVarargsContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericLiteral(GremlinParser.GenericLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericLiteral(GremlinParser.GenericLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterGenericMapLiteral(GremlinParser.GenericMapLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitGenericMapLiteral(GremlinParser.GenericMapLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMapKey(GremlinParser.MapKeyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMapKey(GremlinParser.MapKeyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterMapEntry(GremlinParser.MapEntryContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitMapEntry(GremlinParser.MapEntryContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterStringLiteral(GremlinParser.StringLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitStringLiteral(GremlinParser.StringLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterStringNullableLiteral(GremlinParser.StringNullableLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitStringNullableLiteral(GremlinParser.StringNullableLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterIntegerLiteral(GremlinParser.IntegerLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitIntegerLiteral(GremlinParser.IntegerLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterFloatLiteral(GremlinParser.FloatLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitFloatLiteral(GremlinParser.FloatLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNumericLiteral(GremlinParser.NumericLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNumericLiteral(GremlinParser.NumericLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterBooleanLiteral(GremlinParser.BooleanLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitBooleanLiteral(GremlinParser.BooleanLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterDateLiteral(GremlinParser.DateLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitDateLiteral(GremlinParser.DateLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNullLiteral(GremlinParser.NullLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNullLiteral(GremlinParser.NullLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNanLiteral(GremlinParser.NanLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNanLiteral(GremlinParser.NanLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterInfLiteral(GremlinParser.InfLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitInfLiteral(GremlinParser.InfLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterUuidLiteral(GremlinParser.UuidLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitUuidLiteral(GremlinParser.UuidLiteralContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterNakedKey(GremlinParser.NakedKeyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitNakedKey(GremlinParser.NakedKeyContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterClassType(GremlinParser.ClassTypeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitClassType(GremlinParser.ClassTypeContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterVariable(GremlinParser.VariableContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitVariable(GremlinParser.VariableContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterKeyword(GremlinParser.KeywordContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitKeyword(GremlinParser.KeywordContext ctx) { }

	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void enterEveryRule(ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void exitEveryRule(ParserRuleContext ctx) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void visitTerminal(TerminalNode node) { }
	/**
	 * {@inheritDoc}
	 *
	 * <p>The default implementation does nothing.</p>
	 */
	@Override public void visitErrorNode(ErrorNode node) { }
}