// Generated from Gremlin.g4 by ANTLR 4.13.2
package org.apache.tinkerpop.gremlin.language.grammar;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link GremlinParser}.
 */
public interface GremlinListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link GremlinParser#queryList}.
	 * @param ctx the parse tree
	 */
	void enterQueryList(GremlinParser.QueryListContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#queryList}.
	 * @param ctx the parse tree
	 */
	void exitQueryList(GremlinParser.QueryListContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#query}.
	 * @param ctx the parse tree
	 */
	void enterQuery(GremlinParser.QueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#query}.
	 * @param ctx the parse tree
	 */
	void exitQuery(GremlinParser.QueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#emptyQuery}.
	 * @param ctx the parse tree
	 */
	void enterEmptyQuery(GremlinParser.EmptyQueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#emptyQuery}.
	 * @param ctx the parse tree
	 */
	void exitEmptyQuery(GremlinParser.EmptyQueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSource}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSource(GremlinParser.TraversalSourceContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSource}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSource(GremlinParser.TraversalSourceContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#transactionPart}.
	 * @param ctx the parse tree
	 */
	void enterTransactionPart(GremlinParser.TransactionPartContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#transactionPart}.
	 * @param ctx the parse tree
	 */
	void exitTransactionPart(GremlinParser.TransactionPartContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#rootTraversal}.
	 * @param ctx the parse tree
	 */
	void enterRootTraversal(GremlinParser.RootTraversalContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#rootTraversal}.
	 * @param ctx the parse tree
	 */
	void exitRootTraversal(GremlinParser.RootTraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod(GremlinParser.TraversalSourceSelfMethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod(GremlinParser.TraversalSourceSelfMethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withBulk}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_withBulk(GremlinParser.TraversalSourceSelfMethod_withBulkContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withBulk}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_withBulk(GremlinParser.TraversalSourceSelfMethod_withBulkContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withPath}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_withPath(GremlinParser.TraversalSourceSelfMethod_withPathContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withPath}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_withPath(GremlinParser.TraversalSourceSelfMethod_withPathContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withSack}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_withSack(GremlinParser.TraversalSourceSelfMethod_withSackContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withSack}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_withSack(GremlinParser.TraversalSourceSelfMethod_withSackContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withSideEffect}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_withSideEffect(GremlinParser.TraversalSourceSelfMethod_withSideEffectContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withSideEffect}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_withSideEffect(GremlinParser.TraversalSourceSelfMethod_withSideEffectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withStrategies}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_withStrategies(GremlinParser.TraversalSourceSelfMethod_withStrategiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withStrategies}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_withStrategies(GremlinParser.TraversalSourceSelfMethod_withStrategiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withoutStrategies}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_withoutStrategies(GremlinParser.TraversalSourceSelfMethod_withoutStrategiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_withoutStrategies}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_withoutStrategies(GremlinParser.TraversalSourceSelfMethod_withoutStrategiesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_with}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSelfMethod_with(GremlinParser.TraversalSourceSelfMethod_withContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSelfMethod_with}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSelfMethod_with(GremlinParser.TraversalSourceSelfMethod_withContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod(GremlinParser.TraversalSourceSpawnMethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod(GremlinParser.TraversalSourceSpawnMethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_addE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_addE(GremlinParser.TraversalSourceSpawnMethod_addEContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_addE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_addE(GremlinParser.TraversalSourceSpawnMethod_addEContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_addV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_addV(GremlinParser.TraversalSourceSpawnMethod_addVContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_addV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_addV(GremlinParser.TraversalSourceSpawnMethod_addVContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_E}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_E(GremlinParser.TraversalSourceSpawnMethod_EContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_E}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_E(GremlinParser.TraversalSourceSpawnMethod_EContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_V}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_V(GremlinParser.TraversalSourceSpawnMethod_VContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_V}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_V(GremlinParser.TraversalSourceSpawnMethod_VContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_inject}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_inject(GremlinParser.TraversalSourceSpawnMethod_injectContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_inject}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_inject(GremlinParser.TraversalSourceSpawnMethod_injectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_io}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_io(GremlinParser.TraversalSourceSpawnMethod_ioContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_io}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_io(GremlinParser.TraversalSourceSpawnMethod_ioContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_mergeV_Map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_mergeV_Map(GremlinParser.TraversalSourceSpawnMethod_mergeV_MapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeV_Map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_mergeV_Map(GremlinParser.TraversalSourceSpawnMethod_mergeV_MapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_mergeV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_mergeV_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeV_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_mergeV_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeV_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_mergeE_Map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_mergeE_Map(GremlinParser.TraversalSourceSpawnMethod_mergeE_MapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeE_Map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_mergeE_Map(GremlinParser.TraversalSourceSpawnMethod_mergeE_MapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_mergeE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_mergeE_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeE_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_mergeE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_mergeE_Traversal(GremlinParser.TraversalSourceSpawnMethod_mergeE_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_call_empty}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_call_empty(GremlinParser.TraversalSourceSpawnMethod_call_emptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_call_empty}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_call_empty(GremlinParser.TraversalSourceSpawnMethod_call_emptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_call_string}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_call_string(GremlinParser.TraversalSourceSpawnMethod_call_stringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_call_string(GremlinParser.TraversalSourceSpawnMethod_call_stringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_call_string_map(GremlinParser.TraversalSourceSpawnMethod_call_string_mapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_map}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_call_string_map(GremlinParser.TraversalSourceSpawnMethod_call_string_mapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_call_string_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_call_string_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_traversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_map_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_call_string_map_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_map_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_call_string_map_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_call_string_map_traversal(GremlinParser.TraversalSourceSpawnMethod_call_string_map_traversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_union}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_union(GremlinParser.TraversalSourceSpawnMethod_unionContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSourceSpawnMethod_union}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_union(GremlinParser.TraversalSourceSpawnMethod_unionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_customService_empty}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_customService_empty(GremlinParser.TraversalSourceSpawnMethod_customService_emptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_empty}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_customService_empty(GremlinParser.TraversalSourceSpawnMethod_customService_emptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_customService_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_customService_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_customService_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_traversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_customService_args}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_customService_args(GremlinParser.TraversalSourceSpawnMethod_customService_argsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_args}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_customService_args(GremlinParser.TraversalSourceSpawnMethod_customService_argsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalSourceSpawnMethod_customService_args_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSourceSpawnMethod_customService_args_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_args_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalSourceSpawnMethod_customService_args_traversal}
	 * labeled alternative in {@link GremlinParser#traversalSourceSpawnMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSourceSpawnMethod_customService_args_traversal(GremlinParser.TraversalSourceSpawnMethod_customService_args_traversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#chainedTraversal}.
	 * @param ctx the parse tree
	 */
	void enterChainedTraversal(GremlinParser.ChainedTraversalContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#chainedTraversal}.
	 * @param ctx the parse tree
	 */
	void exitChainedTraversal(GremlinParser.ChainedTraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#nestedTraversal}.
	 * @param ctx the parse tree
	 */
	void enterNestedTraversal(GremlinParser.NestedTraversalContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#nestedTraversal}.
	 * @param ctx the parse tree
	 */
	void exitNestedTraversal(GremlinParser.NestedTraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#terminatedTraversal}.
	 * @param ctx the parse tree
	 */
	void enterTerminatedTraversal(GremlinParser.TerminatedTraversalContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#terminatedTraversal}.
	 * @param ctx the parse tree
	 */
	void exitTerminatedTraversal(GremlinParser.TerminatedTraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod(GremlinParser.TraversalMethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod(GremlinParser.TraversalMethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_V}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_V(GremlinParser.TraversalMethod_VContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_V}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_V(GremlinParser.TraversalMethod_VContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_E}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_E(GremlinParser.TraversalMethod_EContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_E}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_E(GremlinParser.TraversalMethod_EContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_addE_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_addE_String(GremlinParser.TraversalMethod_addE_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_addE_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_addE_String(GremlinParser.TraversalMethod_addE_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_addE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_addE_Traversal(GremlinParser.TraversalMethod_addE_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_addE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_addE_Traversal(GremlinParser.TraversalMethod_addE_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_addV_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_addV_Empty(GremlinParser.TraversalMethod_addV_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_addV_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_addV_Empty(GremlinParser.TraversalMethod_addV_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_addV_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_addV_String(GremlinParser.TraversalMethod_addV_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_addV_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_addV_String(GremlinParser.TraversalMethod_addV_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_addV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_addV_Traversal(GremlinParser.TraversalMethod_addV_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_addV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_addV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_addV_Traversal(GremlinParser.TraversalMethod_addV_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_aggregate_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_aggregate}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_aggregate_String(GremlinParser.TraversalMethod_aggregate_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_aggregate_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_aggregate}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_aggregate_String(GremlinParser.TraversalMethod_aggregate_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_all_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_all}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_all_P(GremlinParser.TraversalMethod_all_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_all_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_all}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_all_P(GremlinParser.TraversalMethod_all_PContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_and}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_and(GremlinParser.TraversalMethod_andContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_and}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_and(GremlinParser.TraversalMethod_andContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_any_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_any}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_any_P(GremlinParser.TraversalMethod_any_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_any_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_any}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_any_P(GremlinParser.TraversalMethod_any_PContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_as}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_as(GremlinParser.TraversalMethod_asContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_as}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_as(GremlinParser.TraversalMethod_asContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_asBool}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_asBool(GremlinParser.TraversalMethod_asBoolContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_asBool}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_asBool(GremlinParser.TraversalMethod_asBoolContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_asDate}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_asDate(GremlinParser.TraversalMethod_asDateContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_asDate}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_asDate(GremlinParser.TraversalMethod_asDateContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_asNumber_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asNumber}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_asNumber_Empty(GremlinParser.TraversalMethod_asNumber_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_asNumber_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asNumber}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_asNumber_Empty(GremlinParser.TraversalMethod_asNumber_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_asNumber_traversalGType}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asNumber}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_asNumber_traversalGType(GremlinParser.TraversalMethod_asNumber_traversalGTypeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_asNumber_traversalGType}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asNumber}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_asNumber_traversalGType(GremlinParser.TraversalMethod_asNumber_traversalGTypeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_asString_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asString}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_asString_Empty(GremlinParser.TraversalMethod_asString_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_asString_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asString}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_asString_Empty(GremlinParser.TraversalMethod_asString_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_asString_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asString}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_asString_Scope(GremlinParser.TraversalMethod_asString_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_asString_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_asString}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_asString_Scope(GremlinParser.TraversalMethod_asString_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_barrier_Consumer}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_barrier_Consumer(GremlinParser.TraversalMethod_barrier_ConsumerContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_barrier_Consumer}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_barrier_Consumer(GremlinParser.TraversalMethod_barrier_ConsumerContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_barrier_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_barrier_Empty(GremlinParser.TraversalMethod_barrier_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_barrier_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_barrier_Empty(GremlinParser.TraversalMethod_barrier_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_barrier_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_barrier_int(GremlinParser.TraversalMethod_barrier_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_barrier_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_barrier}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_barrier_int(GremlinParser.TraversalMethod_barrier_intContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_both}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_both(GremlinParser.TraversalMethod_bothContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_both}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_both(GremlinParser.TraversalMethod_bothContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_bothE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_bothE(GremlinParser.TraversalMethod_bothEContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_bothE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_bothE(GremlinParser.TraversalMethod_bothEContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_bothV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_bothV(GremlinParser.TraversalMethod_bothVContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_bothV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_bothV(GremlinParser.TraversalMethod_bothVContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_branch}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_branch(GremlinParser.TraversalMethod_branchContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_branch}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_branch(GremlinParser.TraversalMethod_branchContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Comparator(GremlinParser.TraversalMethod_by_ComparatorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Comparator(GremlinParser.TraversalMethod_by_ComparatorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Empty(GremlinParser.TraversalMethod_by_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Empty(GremlinParser.TraversalMethod_by_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Function}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Function(GremlinParser.TraversalMethod_by_FunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Function}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Function(GremlinParser.TraversalMethod_by_FunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Function_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Function_Comparator(GremlinParser.TraversalMethod_by_Function_ComparatorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Function_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Function_Comparator(GremlinParser.TraversalMethod_by_Function_ComparatorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Order}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Order(GremlinParser.TraversalMethod_by_OrderContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Order}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Order(GremlinParser.TraversalMethod_by_OrderContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_String(GremlinParser.TraversalMethod_by_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_String(GremlinParser.TraversalMethod_by_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_String_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_String_Comparator(GremlinParser.TraversalMethod_by_String_ComparatorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_String_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_String_Comparator(GremlinParser.TraversalMethod_by_String_ComparatorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_T}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_T(GremlinParser.TraversalMethod_by_TContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_T}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_T(GremlinParser.TraversalMethod_by_TContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Traversal(GremlinParser.TraversalMethod_by_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Traversal(GremlinParser.TraversalMethod_by_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_by_Traversal_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_by_Traversal_Comparator(GremlinParser.TraversalMethod_by_Traversal_ComparatorContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_by_Traversal_Comparator}
	 * labeled alternative in {@link GremlinParser#traversalMethod_by}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_by_Traversal_Comparator(GremlinParser.TraversalMethod_by_Traversal_ComparatorContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_call_string}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_call_string(GremlinParser.TraversalMethod_call_stringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_call_string}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_call_string(GremlinParser.TraversalMethod_call_stringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_call_string_map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_call_string_map(GremlinParser.TraversalMethod_call_string_mapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_call_string_map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_call_string_map(GremlinParser.TraversalMethod_call_string_mapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_call_string_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_call_string_traversal(GremlinParser.TraversalMethod_call_string_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_call_string_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_call_string_traversal(GremlinParser.TraversalMethod_call_string_traversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_call_string_map_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_call_string_map_traversal(GremlinParser.TraversalMethod_call_string_map_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_call_string_map_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_call}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_call_string_map_traversal(GremlinParser.TraversalMethod_call_string_map_traversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_customService_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_customService_empty(GremlinParser.TraversalMethod_customService_emptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_customService_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_customService_empty(GremlinParser.TraversalMethod_customService_emptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_customService_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_customService_traversal(GremlinParser.TraversalMethod_customService_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_customService_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_customService_traversal(GremlinParser.TraversalMethod_customService_traversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_customService_args}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_customService_args(GremlinParser.TraversalMethod_customService_argsContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_customService_args}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_customService_args(GremlinParser.TraversalMethod_customService_argsContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_customService_args_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_customService_args_traversal(GremlinParser.TraversalMethod_customService_args_traversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_customService_args_traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_customService}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_customService_args_traversal(GremlinParser.TraversalMethod_customService_args_traversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_cap}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_cap(GremlinParser.TraversalMethod_capContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_cap}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_cap(GremlinParser.TraversalMethod_capContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_choose_Function}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_choose_Function(GremlinParser.TraversalMethod_choose_FunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_choose_Function}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_choose_Function(GremlinParser.TraversalMethod_choose_FunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_choose_Predicate_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_choose_Predicate_Traversal(GremlinParser.TraversalMethod_choose_Predicate_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_choose_Predicate_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_choose_Predicate_Traversal(GremlinParser.TraversalMethod_choose_Predicate_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_choose_Predicate_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_choose_Predicate_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Predicate_Traversal_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_choose_Predicate_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_choose_Predicate_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Predicate_Traversal_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_choose_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_choose_Traversal(GremlinParser.TraversalMethod_choose_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_choose_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_choose_Traversal(GremlinParser.TraversalMethod_choose_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_choose_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_choose_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_choose_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_choose_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_choose_Traversal_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_choose_Traversal_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_Traversal_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_choose_Traversal_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_choose}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_choose_Traversal_Traversal_Traversal(GremlinParser.TraversalMethod_choose_Traversal_Traversal_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_coalesce}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_coalesce(GremlinParser.TraversalMethod_coalesceContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_coalesce}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_coalesce(GremlinParser.TraversalMethod_coalesceContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_coin}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_coin(GremlinParser.TraversalMethod_coinContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_coin}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_coin(GremlinParser.TraversalMethod_coinContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_combine_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_combine}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_combine_Object(GremlinParser.TraversalMethod_combine_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_combine_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_combine}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_combine_Object(GremlinParser.TraversalMethod_combine_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_concat_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_concat}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_concat_Traversal_Traversal(GremlinParser.TraversalMethod_concat_Traversal_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_concat_Traversal_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_concat}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_concat_Traversal_Traversal(GremlinParser.TraversalMethod_concat_Traversal_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_concat_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_concat}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_concat_String(GremlinParser.TraversalMethod_concat_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_concat_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_concat}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_concat_String(GremlinParser.TraversalMethod_concat_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_conjoin_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_conjoin}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_conjoin_String(GremlinParser.TraversalMethod_conjoin_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_conjoin_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_conjoin}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_conjoin_String(GremlinParser.TraversalMethod_conjoin_StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_connectedComponent}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_connectedComponent(GremlinParser.TraversalMethod_connectedComponentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_connectedComponent}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_connectedComponent(GremlinParser.TraversalMethod_connectedComponentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_constant}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_constant(GremlinParser.TraversalMethod_constantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_constant}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_constant(GremlinParser.TraversalMethod_constantContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_count_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_count}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_count_Empty(GremlinParser.TraversalMethod_count_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_count_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_count}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_count_Empty(GremlinParser.TraversalMethod_count_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_count_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_count}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_count_Scope(GremlinParser.TraversalMethod_count_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_count_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_count}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_count_Scope(GremlinParser.TraversalMethod_count_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_cyclicPath}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_cyclicPath(GremlinParser.TraversalMethod_cyclicPathContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_cyclicPath}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_cyclicPath(GremlinParser.TraversalMethod_cyclicPathContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_dateAdd}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_dateAdd(GremlinParser.TraversalMethod_dateAddContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_dateAdd}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_dateAdd(GremlinParser.TraversalMethod_dateAddContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_dateDiff_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dateDiff}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_dateDiff_Traversal(GremlinParser.TraversalMethod_dateDiff_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_dateDiff_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dateDiff}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_dateDiff_Traversal(GremlinParser.TraversalMethod_dateDiff_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_dateDiff_Date}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dateDiff}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_dateDiff_Date(GremlinParser.TraversalMethod_dateDiff_DateContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_dateDiff_Date}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dateDiff}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_dateDiff_Date(GremlinParser.TraversalMethod_dateDiff_DateContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_dedup_Scope_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dedup}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_dedup_Scope_String(GremlinParser.TraversalMethod_dedup_Scope_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_dedup_Scope_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dedup}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_dedup_Scope_String(GremlinParser.TraversalMethod_dedup_Scope_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_dedup_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dedup}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_dedup_String(GremlinParser.TraversalMethod_dedup_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_dedup_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_dedup}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_dedup_String(GremlinParser.TraversalMethod_dedup_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_difference_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_difference}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_difference_Object(GremlinParser.TraversalMethod_difference_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_difference_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_difference}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_difference_Object(GremlinParser.TraversalMethod_difference_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_discard}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_discard(GremlinParser.TraversalMethod_discardContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_discard}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_discard(GremlinParser.TraversalMethod_discardContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_disjunct_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_disjunct}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_disjunct_Object(GremlinParser.TraversalMethod_disjunct_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_disjunct_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_disjunct}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_disjunct_Object(GremlinParser.TraversalMethod_disjunct_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_drop}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_drop(GremlinParser.TraversalMethod_dropContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_drop}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_drop(GremlinParser.TraversalMethod_dropContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_element}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_element(GremlinParser.TraversalMethod_elementContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_element}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_element(GremlinParser.TraversalMethod_elementContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_elementMap}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_elementMap(GremlinParser.TraversalMethod_elementMapContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_elementMap}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_elementMap(GremlinParser.TraversalMethod_elementMapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_emit_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_emit_Empty(GremlinParser.TraversalMethod_emit_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_emit_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_emit_Empty(GremlinParser.TraversalMethod_emit_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_emit_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_emit_Predicate(GremlinParser.TraversalMethod_emit_PredicateContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_emit_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_emit_Predicate(GremlinParser.TraversalMethod_emit_PredicateContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_emit_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_emit_Traversal(GremlinParser.TraversalMethod_emit_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_emit_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_emit}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_emit_Traversal(GremlinParser.TraversalMethod_emit_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_fail_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fail}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_fail_Empty(GremlinParser.TraversalMethod_fail_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_fail_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fail}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_fail_Empty(GremlinParser.TraversalMethod_fail_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_fail_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fail}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_fail_String(GremlinParser.TraversalMethod_fail_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_fail_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fail}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_fail_String(GremlinParser.TraversalMethod_fail_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_filter_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_filter}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_filter_Predicate(GremlinParser.TraversalMethod_filter_PredicateContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_filter_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_filter}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_filter_Predicate(GremlinParser.TraversalMethod_filter_PredicateContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_filter_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_filter}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_filter_Traversal(GremlinParser.TraversalMethod_filter_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_filter_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_filter}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_filter_Traversal(GremlinParser.TraversalMethod_filter_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_flatMap}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_flatMap(GremlinParser.TraversalMethod_flatMapContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_flatMap}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_flatMap(GremlinParser.TraversalMethod_flatMapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_fold_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fold}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_fold_Empty(GremlinParser.TraversalMethod_fold_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_fold_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fold}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_fold_Empty(GremlinParser.TraversalMethod_fold_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_fold_Object_BiFunction}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fold}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_fold_Object_BiFunction(GremlinParser.TraversalMethod_fold_Object_BiFunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_fold_Object_BiFunction}
	 * labeled alternative in {@link GremlinParser#traversalMethod_fold}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_fold_Object_BiFunction(GremlinParser.TraversalMethod_fold_Object_BiFunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_format_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_format}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_format_String(GremlinParser.TraversalMethod_format_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_format_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_format}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_format_String(GremlinParser.TraversalMethod_format_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_from_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_from}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_from_String(GremlinParser.TraversalMethod_from_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_from_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_from}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_from_String(GremlinParser.TraversalMethod_from_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_from_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_from}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_from_Traversal(GremlinParser.TraversalMethod_from_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_from_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_from}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_from_Traversal(GremlinParser.TraversalMethod_from_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_group_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_group}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_group_Empty(GremlinParser.TraversalMethod_group_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_group_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_group}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_group_Empty(GremlinParser.TraversalMethod_group_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_group_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_group}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_group_String(GremlinParser.TraversalMethod_group_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_group_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_group}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_group_String(GremlinParser.TraversalMethod_group_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_groupCount_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_groupCount}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_groupCount_Empty(GremlinParser.TraversalMethod_groupCount_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_groupCount_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_groupCount}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_groupCount_Empty(GremlinParser.TraversalMethod_groupCount_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_groupCount_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_groupCount}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_groupCount_String(GremlinParser.TraversalMethod_groupCount_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_groupCount_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_groupCount}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_groupCount_String(GremlinParser.TraversalMethod_groupCount_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_String(GremlinParser.TraversalMethod_has_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_String(GremlinParser.TraversalMethod_has_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_String_Object(GremlinParser.TraversalMethod_has_String_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_String_Object(GremlinParser.TraversalMethod_has_String_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_String_P(GremlinParser.TraversalMethod_has_String_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_String_P(GremlinParser.TraversalMethod_has_String_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_String_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_String_String_Object(GremlinParser.TraversalMethod_has_String_String_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_String_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_String_String_Object(GremlinParser.TraversalMethod_has_String_String_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_String_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_String_String_P(GremlinParser.TraversalMethod_has_String_String_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_String_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_String_String_P(GremlinParser.TraversalMethod_has_String_String_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_T_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_T_Object(GremlinParser.TraversalMethod_has_T_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_T_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_T_Object(GremlinParser.TraversalMethod_has_T_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_has_T_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_has_T_P(GremlinParser.TraversalMethod_has_T_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_has_T_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_has}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_has_T_P(GremlinParser.TraversalMethod_has_T_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasId_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasId}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasId_Object_Object(GremlinParser.TraversalMethod_hasId_Object_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasId_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasId}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasId_Object_Object(GremlinParser.TraversalMethod_hasId_Object_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasId_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasId}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasId_P(GremlinParser.TraversalMethod_hasId_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasId_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasId}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasId_P(GremlinParser.TraversalMethod_hasId_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasKey_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasKey}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasKey_P(GremlinParser.TraversalMethod_hasKey_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasKey_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasKey}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasKey_P(GremlinParser.TraversalMethod_hasKey_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasKey_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasKey}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasKey_String_String(GremlinParser.TraversalMethod_hasKey_String_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasKey_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasKey}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasKey_String_String(GremlinParser.TraversalMethod_hasKey_String_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasLabel_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasLabel}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasLabel_P(GremlinParser.TraversalMethod_hasLabel_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasLabel_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasLabel}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasLabel_P(GremlinParser.TraversalMethod_hasLabel_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasLabel_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasLabel}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasLabel_String_String(GremlinParser.TraversalMethod_hasLabel_String_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasLabel_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasLabel}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasLabel_String_String(GremlinParser.TraversalMethod_hasLabel_String_StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_hasNot}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasNot(GremlinParser.TraversalMethod_hasNotContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_hasNot}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasNot(GremlinParser.TraversalMethod_hasNotContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasValue_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasValue}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasValue_Object_Object(GremlinParser.TraversalMethod_hasValue_Object_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasValue_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasValue}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasValue_Object_Object(GremlinParser.TraversalMethod_hasValue_Object_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_hasValue_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasValue}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_hasValue_P(GremlinParser.TraversalMethod_hasValue_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_hasValue_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_hasValue}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_hasValue_P(GremlinParser.TraversalMethod_hasValue_PContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_id}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_id(GremlinParser.TraversalMethod_idContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_id}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_id(GremlinParser.TraversalMethod_idContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_identity}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_identity(GremlinParser.TraversalMethod_identityContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_identity}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_identity(GremlinParser.TraversalMethod_identityContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_in}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_in(GremlinParser.TraversalMethod_inContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_in}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_in(GremlinParser.TraversalMethod_inContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_inE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_inE(GremlinParser.TraversalMethod_inEContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_inE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_inE(GremlinParser.TraversalMethod_inEContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_intersect_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_intersect}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_intersect_Object(GremlinParser.TraversalMethod_intersect_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_intersect_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_intersect}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_intersect_Object(GremlinParser.TraversalMethod_intersect_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_inV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_inV(GremlinParser.TraversalMethod_inVContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_inV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_inV(GremlinParser.TraversalMethod_inVContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_index}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_index(GremlinParser.TraversalMethod_indexContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_index}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_index(GremlinParser.TraversalMethod_indexContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_inject}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_inject(GremlinParser.TraversalMethod_injectContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_inject}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_inject(GremlinParser.TraversalMethod_injectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_is_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_is}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_is_Object(GremlinParser.TraversalMethod_is_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_is_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_is}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_is_Object(GremlinParser.TraversalMethod_is_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_is_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_is}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_is_P(GremlinParser.TraversalMethod_is_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_is_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_is}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_is_P(GremlinParser.TraversalMethod_is_PContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_key}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_key(GremlinParser.TraversalMethod_keyContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_key}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_key(GremlinParser.TraversalMethod_keyContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_label}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_label(GremlinParser.TraversalMethod_labelContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_label}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_label(GremlinParser.TraversalMethod_labelContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_length_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_length}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_length_Empty(GremlinParser.TraversalMethod_length_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_length_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_length}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_length_Empty(GremlinParser.TraversalMethod_length_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_length_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_length}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_length_Scope(GremlinParser.TraversalMethod_length_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_length_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_length}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_length_Scope(GremlinParser.TraversalMethod_length_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_limit_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_limit}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_limit_Scope_long(GremlinParser.TraversalMethod_limit_Scope_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_limit_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_limit}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_limit_Scope_long(GremlinParser.TraversalMethod_limit_Scope_longContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_limit_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_limit}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_limit_long(GremlinParser.TraversalMethod_limit_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_limit_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_limit}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_limit_long(GremlinParser.TraversalMethod_limit_longContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_local}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_local(GremlinParser.TraversalMethod_localContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_local}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_local(GremlinParser.TraversalMethod_localContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_loops_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_loops}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_loops_Empty(GremlinParser.TraversalMethod_loops_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_loops_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_loops}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_loops_Empty(GremlinParser.TraversalMethod_loops_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_loops_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_loops}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_loops_String(GremlinParser.TraversalMethod_loops_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_loops_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_loops}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_loops_String(GremlinParser.TraversalMethod_loops_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_lTrim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_lTrim}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_lTrim_Empty(GremlinParser.TraversalMethod_lTrim_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_lTrim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_lTrim}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_lTrim_Empty(GremlinParser.TraversalMethod_lTrim_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_lTrim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_lTrim}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_lTrim_Scope(GremlinParser.TraversalMethod_lTrim_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_lTrim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_lTrim}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_lTrim_Scope(GremlinParser.TraversalMethod_lTrim_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_map}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_map(GremlinParser.TraversalMethod_mapContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_map}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_map(GremlinParser.TraversalMethod_mapContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_match}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_match(GremlinParser.TraversalMethod_matchContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_match}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_match(GremlinParser.TraversalMethod_matchContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_math}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_math(GremlinParser.TraversalMethod_mathContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_math}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_math(GremlinParser.TraversalMethod_mathContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_max_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_max}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_max_Empty(GremlinParser.TraversalMethod_max_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_max_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_max}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_max_Empty(GremlinParser.TraversalMethod_max_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_max_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_max}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_max_Scope(GremlinParser.TraversalMethod_max_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_max_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_max}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_max_Scope(GremlinParser.TraversalMethod_max_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mean_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mean}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mean_Empty(GremlinParser.TraversalMethod_mean_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mean_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mean}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mean_Empty(GremlinParser.TraversalMethod_mean_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mean_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mean}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mean_Scope(GremlinParser.TraversalMethod_mean_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mean_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mean}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mean_Scope(GremlinParser.TraversalMethod_mean_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_merge_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_merge}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_merge_Object(GremlinParser.TraversalMethod_merge_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_merge_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_merge}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_merge_Object(GremlinParser.TraversalMethod_merge_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mergeV_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mergeV_empty(GremlinParser.TraversalMethod_mergeV_emptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mergeV_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mergeV_empty(GremlinParser.TraversalMethod_mergeV_emptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mergeV_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mergeV_Map(GremlinParser.TraversalMethod_mergeV_MapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mergeV_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mergeV_Map(GremlinParser.TraversalMethod_mergeV_MapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mergeV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mergeV_Traversal(GremlinParser.TraversalMethod_mergeV_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mergeV_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mergeV_Traversal(GremlinParser.TraversalMethod_mergeV_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mergeE_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mergeE_empty(GremlinParser.TraversalMethod_mergeE_emptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mergeE_empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mergeE_empty(GremlinParser.TraversalMethod_mergeE_emptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mergeE_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mergeE_Map(GremlinParser.TraversalMethod_mergeE_MapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mergeE_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mergeE_Map(GremlinParser.TraversalMethod_mergeE_MapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_mergeE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_mergeE_Traversal(GremlinParser.TraversalMethod_mergeE_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_mergeE_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_mergeE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_mergeE_Traversal(GremlinParser.TraversalMethod_mergeE_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_min_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_min}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_min_Empty(GremlinParser.TraversalMethod_min_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_min_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_min}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_min_Empty(GremlinParser.TraversalMethod_min_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_min_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_min}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_min_Scope(GremlinParser.TraversalMethod_min_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_min_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_min}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_min_Scope(GremlinParser.TraversalMethod_min_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_none_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_none}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_none_P(GremlinParser.TraversalMethod_none_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_none_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_none}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_none_P(GremlinParser.TraversalMethod_none_PContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_not}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_not(GremlinParser.TraversalMethod_notContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_not}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_not(GremlinParser.TraversalMethod_notContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_option_Predicate_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_option_Predicate_Traversal(GremlinParser.TraversalMethod_option_Predicate_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_option_Predicate_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_option_Predicate_Traversal(GremlinParser.TraversalMethod_option_Predicate_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_option_Merge_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_option_Merge_Map(GremlinParser.TraversalMethod_option_Merge_MapContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_option_Merge_Map}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_option_Merge_Map(GremlinParser.TraversalMethod_option_Merge_MapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_option_Merge_Map_Cardinality}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_option_Merge_Map_Cardinality(GremlinParser.TraversalMethod_option_Merge_Map_CardinalityContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_option_Merge_Map_Cardinality}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_option_Merge_Map_Cardinality(GremlinParser.TraversalMethod_option_Merge_Map_CardinalityContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_option_Merge_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_option_Merge_Traversal(GremlinParser.TraversalMethod_option_Merge_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_option_Merge_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_option_Merge_Traversal(GremlinParser.TraversalMethod_option_Merge_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_option_Object_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_option_Object_Traversal(GremlinParser.TraversalMethod_option_Object_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_option_Object_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_option_Object_Traversal(GremlinParser.TraversalMethod_option_Object_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_option_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_option_Traversal(GremlinParser.TraversalMethod_option_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_option_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_option}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_option_Traversal(GremlinParser.TraversalMethod_option_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_optional}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_optional(GremlinParser.TraversalMethod_optionalContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_optional}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_optional(GremlinParser.TraversalMethod_optionalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_or}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_or(GremlinParser.TraversalMethod_orContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_or}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_or(GremlinParser.TraversalMethod_orContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_order_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_order}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_order_Empty(GremlinParser.TraversalMethod_order_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_order_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_order}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_order_Empty(GremlinParser.TraversalMethod_order_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_order_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_order}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_order_Scope(GremlinParser.TraversalMethod_order_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_order_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_order}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_order_Scope(GremlinParser.TraversalMethod_order_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_otherV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_otherV(GremlinParser.TraversalMethod_otherVContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_otherV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_otherV(GremlinParser.TraversalMethod_otherVContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_out}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_out(GremlinParser.TraversalMethod_outContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_out}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_out(GremlinParser.TraversalMethod_outContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_outE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_outE(GremlinParser.TraversalMethod_outEContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_outE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_outE(GremlinParser.TraversalMethod_outEContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_outV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_outV(GremlinParser.TraversalMethod_outVContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_outV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_outV(GremlinParser.TraversalMethod_outVContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_pageRank_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_pageRank}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_pageRank_Empty(GremlinParser.TraversalMethod_pageRank_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_pageRank_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_pageRank}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_pageRank_Empty(GremlinParser.TraversalMethod_pageRank_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_pageRank_double}
	 * labeled alternative in {@link GremlinParser#traversalMethod_pageRank}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_pageRank_double(GremlinParser.TraversalMethod_pageRank_doubleContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_pageRank_double}
	 * labeled alternative in {@link GremlinParser#traversalMethod_pageRank}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_pageRank_double(GremlinParser.TraversalMethod_pageRank_doubleContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_path}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_path(GremlinParser.TraversalMethod_pathContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_path}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_path(GremlinParser.TraversalMethod_pathContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_peerPressure}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_peerPressure(GremlinParser.TraversalMethod_peerPressureContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_peerPressure}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_peerPressure(GremlinParser.TraversalMethod_peerPressureContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_product_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_product}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_product_Object(GremlinParser.TraversalMethod_product_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_product_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_product}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_product_Object(GremlinParser.TraversalMethod_product_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_profile_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_profile}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_profile_Empty(GremlinParser.TraversalMethod_profile_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_profile_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_profile}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_profile_Empty(GremlinParser.TraversalMethod_profile_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_profile_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_profile}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_profile_String(GremlinParser.TraversalMethod_profile_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_profile_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_profile}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_profile_String(GremlinParser.TraversalMethod_profile_StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_project}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_project(GremlinParser.TraversalMethod_projectContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_project}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_project(GremlinParser.TraversalMethod_projectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_properties}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_properties(GremlinParser.TraversalMethod_propertiesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_properties}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_properties(GremlinParser.TraversalMethod_propertiesContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_property_Cardinality_Object_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_property_Cardinality_Object_Object_Object(GremlinParser.TraversalMethod_property_Cardinality_Object_Object_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_property_Cardinality_Object_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_property_Cardinality_Object_Object_Object(GremlinParser.TraversalMethod_property_Cardinality_Object_Object_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_property_Cardinality_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_property_Cardinality_Object(GremlinParser.TraversalMethod_property_Cardinality_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_property_Cardinality_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_property_Cardinality_Object(GremlinParser.TraversalMethod_property_Cardinality_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_property_Object_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_property_Object_Object_Object(GremlinParser.TraversalMethod_property_Object_Object_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_property_Object_Object_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_property_Object_Object_Object(GremlinParser.TraversalMethod_property_Object_Object_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_property_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_property_Object(GremlinParser.TraversalMethod_property_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_property_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_property}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_property_Object(GremlinParser.TraversalMethod_property_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_propertyMap}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_propertyMap(GremlinParser.TraversalMethod_propertyMapContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_propertyMap}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_propertyMap(GremlinParser.TraversalMethod_propertyMapContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_range_Scope_long_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_range}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_range_Scope_long_long(GremlinParser.TraversalMethod_range_Scope_long_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_range_Scope_long_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_range}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_range_Scope_long_long(GremlinParser.TraversalMethod_range_Scope_long_longContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_range_long_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_range}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_range_long_long(GremlinParser.TraversalMethod_range_long_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_range_long_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_range}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_range_long_long(GremlinParser.TraversalMethod_range_long_longContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_read}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_read(GremlinParser.TraversalMethod_readContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_read}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_read(GremlinParser.TraversalMethod_readContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_repeat_String_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_repeat}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_repeat_String_Traversal(GremlinParser.TraversalMethod_repeat_String_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_repeat_String_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_repeat}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_repeat_String_Traversal(GremlinParser.TraversalMethod_repeat_String_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_repeat_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_repeat}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_repeat_Traversal(GremlinParser.TraversalMethod_repeat_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_repeat_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_repeat}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_repeat_Traversal(GremlinParser.TraversalMethod_repeat_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_replace_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_replace}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_replace_String_String(GremlinParser.TraversalMethod_replace_String_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_replace_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_replace}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_replace_String_String(GremlinParser.TraversalMethod_replace_String_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_replace_Scope_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_replace}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_replace_Scope_String_String(GremlinParser.TraversalMethod_replace_Scope_String_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_replace_Scope_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_replace}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_replace_Scope_String_String(GremlinParser.TraversalMethod_replace_Scope_String_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_reverse_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_reverse}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_reverse_Empty(GremlinParser.TraversalMethod_reverse_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_reverse_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_reverse}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_reverse_Empty(GremlinParser.TraversalMethod_reverse_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_rTrim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_rTrim}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_rTrim_Empty(GremlinParser.TraversalMethod_rTrim_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_rTrim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_rTrim}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_rTrim_Empty(GremlinParser.TraversalMethod_rTrim_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_rTrim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_rTrim}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_rTrim_Scope(GremlinParser.TraversalMethod_rTrim_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_rTrim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_rTrim}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_rTrim_Scope(GremlinParser.TraversalMethod_rTrim_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_sack_BiFunction}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sack}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sack_BiFunction(GremlinParser.TraversalMethod_sack_BiFunctionContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_sack_BiFunction}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sack}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sack_BiFunction(GremlinParser.TraversalMethod_sack_BiFunctionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_sack_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sack}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sack_Empty(GremlinParser.TraversalMethod_sack_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_sack_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sack}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sack_Empty(GremlinParser.TraversalMethod_sack_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_sample_Scope_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sample}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sample_Scope_int(GremlinParser.TraversalMethod_sample_Scope_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_sample_Scope_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sample}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sample_Scope_int(GremlinParser.TraversalMethod_sample_Scope_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_sample_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sample}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sample_int(GremlinParser.TraversalMethod_sample_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_sample_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sample}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sample_int(GremlinParser.TraversalMethod_sample_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_Column}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_Column(GremlinParser.TraversalMethod_select_ColumnContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_Column}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_Column(GremlinParser.TraversalMethod_select_ColumnContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_Pop_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_Pop_String(GremlinParser.TraversalMethod_select_Pop_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_Pop_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_Pop_String(GremlinParser.TraversalMethod_select_Pop_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_Pop_String_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_Pop_String_String_String(GremlinParser.TraversalMethod_select_Pop_String_String_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_Pop_String_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_Pop_String_String_String(GremlinParser.TraversalMethod_select_Pop_String_String_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_Pop_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_Pop_Traversal(GremlinParser.TraversalMethod_select_Pop_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_Pop_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_Pop_Traversal(GremlinParser.TraversalMethod_select_Pop_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_String(GremlinParser.TraversalMethod_select_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_String(GremlinParser.TraversalMethod_select_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_String_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_String_String_String(GremlinParser.TraversalMethod_select_String_String_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_String_String_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_String_String_String(GremlinParser.TraversalMethod_select_String_String_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_select_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_select_Traversal(GremlinParser.TraversalMethod_select_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_select_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_select}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_select_Traversal(GremlinParser.TraversalMethod_select_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_shortestPath}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_shortestPath(GremlinParser.TraversalMethod_shortestPathContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_shortestPath}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_shortestPath(GremlinParser.TraversalMethod_shortestPathContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_sideEffect}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sideEffect(GremlinParser.TraversalMethod_sideEffectContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_sideEffect}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sideEffect(GremlinParser.TraversalMethod_sideEffectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_simplePath}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_simplePath(GremlinParser.TraversalMethod_simplePathContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_simplePath}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_simplePath(GremlinParser.TraversalMethod_simplePathContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_skip_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_skip}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_skip_Scope_long(GremlinParser.TraversalMethod_skip_Scope_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_skip_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_skip}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_skip_Scope_long(GremlinParser.TraversalMethod_skip_Scope_longContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_skip_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_skip}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_skip_long(GremlinParser.TraversalMethod_skip_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_skip_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_skip}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_skip_long(GremlinParser.TraversalMethod_skip_longContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_split_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_split}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_split_String(GremlinParser.TraversalMethod_split_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_split_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_split}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_split_String(GremlinParser.TraversalMethod_split_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_split_Scope_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_split}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_split_Scope_String(GremlinParser.TraversalMethod_split_Scope_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_split_Scope_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_split}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_split_Scope_String(GremlinParser.TraversalMethod_split_Scope_StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_subgraph}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_subgraph(GremlinParser.TraversalMethod_subgraphContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_subgraph}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_subgraph(GremlinParser.TraversalMethod_subgraphContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_substring_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_substring_int(GremlinParser.TraversalMethod_substring_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_substring_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_substring_int(GremlinParser.TraversalMethod_substring_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_substring_Scope_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_substring_Scope_int(GremlinParser.TraversalMethod_substring_Scope_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_substring_Scope_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_substring_Scope_int(GremlinParser.TraversalMethod_substring_Scope_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_substring_int_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_substring_int_int(GremlinParser.TraversalMethod_substring_int_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_substring_int_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_substring_int_int(GremlinParser.TraversalMethod_substring_int_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_substring_Scope_int_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_substring_Scope_int_int(GremlinParser.TraversalMethod_substring_Scope_int_intContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_substring_Scope_int_int}
	 * labeled alternative in {@link GremlinParser#traversalMethod_substring}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_substring_Scope_int_int(GremlinParser.TraversalMethod_substring_Scope_int_intContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_sum_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sum}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sum_Empty(GremlinParser.TraversalMethod_sum_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_sum_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sum}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sum_Empty(GremlinParser.TraversalMethod_sum_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_sum_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sum}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_sum_Scope(GremlinParser.TraversalMethod_sum_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_sum_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_sum}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_sum_Scope(GremlinParser.TraversalMethod_sum_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_tail_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_tail_Empty(GremlinParser.TraversalMethod_tail_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_tail_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_tail_Empty(GremlinParser.TraversalMethod_tail_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_tail_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_tail_Scope(GremlinParser.TraversalMethod_tail_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_tail_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_tail_Scope(GremlinParser.TraversalMethod_tail_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_tail_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_tail_Scope_long(GremlinParser.TraversalMethod_tail_Scope_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_tail_Scope_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_tail_Scope_long(GremlinParser.TraversalMethod_tail_Scope_longContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_tail_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_tail_long(GremlinParser.TraversalMethod_tail_longContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_tail_long}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tail}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_tail_long(GremlinParser.TraversalMethod_tail_longContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_timeLimit}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_timeLimit(GremlinParser.TraversalMethod_timeLimitContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_timeLimit}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_timeLimit(GremlinParser.TraversalMethod_timeLimitContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_times}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_times(GremlinParser.TraversalMethod_timesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_times}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_times(GremlinParser.TraversalMethod_timesContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_to_Direction_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_to_Direction_String(GremlinParser.TraversalMethod_to_Direction_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_to_Direction_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_to_Direction_String(GremlinParser.TraversalMethod_to_Direction_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_to_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_to_String(GremlinParser.TraversalMethod_to_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_to_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_to_String(GremlinParser.TraversalMethod_to_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_to_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_to_Traversal(GremlinParser.TraversalMethod_to_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_to_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_to}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_to_Traversal(GremlinParser.TraversalMethod_to_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_toE}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_toE(GremlinParser.TraversalMethod_toEContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_toE}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_toE(GremlinParser.TraversalMethod_toEContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_toLower_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toLower}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_toLower_Empty(GremlinParser.TraversalMethod_toLower_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_toLower_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toLower}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_toLower_Empty(GremlinParser.TraversalMethod_toLower_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_toLower_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toLower}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_toLower_Scope(GremlinParser.TraversalMethod_toLower_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_toLower_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toLower}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_toLower_Scope(GremlinParser.TraversalMethod_toLower_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_toUpper_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toUpper}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_toUpper_Empty(GremlinParser.TraversalMethod_toUpper_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_toUpper_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toUpper}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_toUpper_Empty(GremlinParser.TraversalMethod_toUpper_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_toUpper_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toUpper}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_toUpper_Scope(GremlinParser.TraversalMethod_toUpper_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_toUpper_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_toUpper}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_toUpper_Scope(GremlinParser.TraversalMethod_toUpper_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_toV}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_toV(GremlinParser.TraversalMethod_toVContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_toV}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_toV(GremlinParser.TraversalMethod_toVContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_tree_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tree}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_tree_Empty(GremlinParser.TraversalMethod_tree_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_tree_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tree}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_tree_Empty(GremlinParser.TraversalMethod_tree_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_tree_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tree}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_tree_String(GremlinParser.TraversalMethod_tree_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_tree_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_tree}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_tree_String(GremlinParser.TraversalMethod_tree_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_trim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_trim}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_trim_Empty(GremlinParser.TraversalMethod_trim_EmptyContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_trim_Empty}
	 * labeled alternative in {@link GremlinParser#traversalMethod_trim}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_trim_Empty(GremlinParser.TraversalMethod_trim_EmptyContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_trim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_trim}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_trim_Scope(GremlinParser.TraversalMethod_trim_ScopeContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_trim_Scope}
	 * labeled alternative in {@link GremlinParser#traversalMethod_trim}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_trim_Scope(GremlinParser.TraversalMethod_trim_ScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_unfold}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_unfold(GremlinParser.TraversalMethod_unfoldContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_unfold}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_unfold(GremlinParser.TraversalMethod_unfoldContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_union}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_union(GremlinParser.TraversalMethod_unionContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_union}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_union(GremlinParser.TraversalMethod_unionContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_until_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_until}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_until_Predicate(GremlinParser.TraversalMethod_until_PredicateContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_until_Predicate}
	 * labeled alternative in {@link GremlinParser#traversalMethod_until}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_until_Predicate(GremlinParser.TraversalMethod_until_PredicateContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_until_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_until}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_until_Traversal(GremlinParser.TraversalMethod_until_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_until_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_until}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_until_Traversal(GremlinParser.TraversalMethod_until_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_value}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_value(GremlinParser.TraversalMethod_valueContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_value}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_value(GremlinParser.TraversalMethod_valueContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_valueMap_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_valueMap}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_valueMap_String(GremlinParser.TraversalMethod_valueMap_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_valueMap_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_valueMap}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_valueMap_String(GremlinParser.TraversalMethod_valueMap_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_valueMap_boolean_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_valueMap}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_valueMap_boolean_String(GremlinParser.TraversalMethod_valueMap_boolean_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_valueMap_boolean_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_valueMap}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_valueMap_boolean_String(GremlinParser.TraversalMethod_valueMap_boolean_StringContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_values}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_values(GremlinParser.TraversalMethod_valuesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_values}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_values(GremlinParser.TraversalMethod_valuesContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_where_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_where_P(GremlinParser.TraversalMethod_where_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_where_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_where_P(GremlinParser.TraversalMethod_where_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_where_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_where_String_P(GremlinParser.TraversalMethod_where_String_PContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_where_String_P}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_where_String_P(GremlinParser.TraversalMethod_where_String_PContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_where_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_where_Traversal(GremlinParser.TraversalMethod_where_TraversalContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_where_Traversal}
	 * labeled alternative in {@link GremlinParser#traversalMethod_where}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_where_Traversal(GremlinParser.TraversalMethod_where_TraversalContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_with_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_with}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_with_String(GremlinParser.TraversalMethod_with_StringContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_with_String}
	 * labeled alternative in {@link GremlinParser#traversalMethod_with}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_with_String(GremlinParser.TraversalMethod_with_StringContext ctx);
	/**
	 * Enter a parse tree produced by the {@code traversalMethod_with_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_with}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_with_String_Object(GremlinParser.TraversalMethod_with_String_ObjectContext ctx);
	/**
	 * Exit a parse tree produced by the {@code traversalMethod_with_String_Object}
	 * labeled alternative in {@link GremlinParser#traversalMethod_with}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_with_String_Object(GremlinParser.TraversalMethod_with_String_ObjectContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMethod_write}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMethod_write(GremlinParser.TraversalMethod_writeContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMethod_write}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMethod_write(GremlinParser.TraversalMethod_writeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalStrategy}.
	 * @param ctx the parse tree
	 */
	void enterTraversalStrategy(GremlinParser.TraversalStrategyContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalStrategy}.
	 * @param ctx the parse tree
	 */
	void exitTraversalStrategy(GremlinParser.TraversalStrategyContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#configuration}.
	 * @param ctx the parse tree
	 */
	void enterConfiguration(GremlinParser.ConfigurationContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#configuration}.
	 * @param ctx the parse tree
	 */
	void exitConfiguration(GremlinParser.ConfigurationContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalScope}.
	 * @param ctx the parse tree
	 */
	void enterTraversalScope(GremlinParser.TraversalScopeContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalScope}.
	 * @param ctx the parse tree
	 */
	void exitTraversalScope(GremlinParser.TraversalScopeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalBarrier}.
	 * @param ctx the parse tree
	 */
	void enterTraversalBarrier(GremlinParser.TraversalBarrierContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalBarrier}.
	 * @param ctx the parse tree
	 */
	void exitTraversalBarrier(GremlinParser.TraversalBarrierContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalT}.
	 * @param ctx the parse tree
	 */
	void enterTraversalT(GremlinParser.TraversalTContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalT}.
	 * @param ctx the parse tree
	 */
	void exitTraversalT(GremlinParser.TraversalTContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTShort}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTShort(GremlinParser.TraversalTShortContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTShort}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTShort(GremlinParser.TraversalTShortContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTLong}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTLong(GremlinParser.TraversalTLongContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTLong}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTLong(GremlinParser.TraversalTLongContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalMerge}.
	 * @param ctx the parse tree
	 */
	void enterTraversalMerge(GremlinParser.TraversalMergeContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalMerge}.
	 * @param ctx the parse tree
	 */
	void exitTraversalMerge(GremlinParser.TraversalMergeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalOrder}.
	 * @param ctx the parse tree
	 */
	void enterTraversalOrder(GremlinParser.TraversalOrderContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalOrder}.
	 * @param ctx the parse tree
	 */
	void exitTraversalOrder(GremlinParser.TraversalOrderContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalDirection}.
	 * @param ctx the parse tree
	 */
	void enterTraversalDirection(GremlinParser.TraversalDirectionContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalDirection}.
	 * @param ctx the parse tree
	 */
	void exitTraversalDirection(GremlinParser.TraversalDirectionContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalDirectionShort}.
	 * @param ctx the parse tree
	 */
	void enterTraversalDirectionShort(GremlinParser.TraversalDirectionShortContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalDirectionShort}.
	 * @param ctx the parse tree
	 */
	void exitTraversalDirectionShort(GremlinParser.TraversalDirectionShortContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalDirectionLong}.
	 * @param ctx the parse tree
	 */
	void enterTraversalDirectionLong(GremlinParser.TraversalDirectionLongContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalDirectionLong}.
	 * @param ctx the parse tree
	 */
	void exitTraversalDirectionLong(GremlinParser.TraversalDirectionLongContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalCardinality}.
	 * @param ctx the parse tree
	 */
	void enterTraversalCardinality(GremlinParser.TraversalCardinalityContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalCardinality}.
	 * @param ctx the parse tree
	 */
	void exitTraversalCardinality(GremlinParser.TraversalCardinalityContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalColumn}.
	 * @param ctx the parse tree
	 */
	void enterTraversalColumn(GremlinParser.TraversalColumnContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalColumn}.
	 * @param ctx the parse tree
	 */
	void exitTraversalColumn(GremlinParser.TraversalColumnContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPop}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPop(GremlinParser.TraversalPopContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPop}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPop(GremlinParser.TraversalPopContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalOperator}.
	 * @param ctx the parse tree
	 */
	void enterTraversalOperator(GremlinParser.TraversalOperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalOperator}.
	 * @param ctx the parse tree
	 */
	void exitTraversalOperator(GremlinParser.TraversalOperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPick}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPick(GremlinParser.TraversalPickContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPick}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPick(GremlinParser.TraversalPickContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalDT}.
	 * @param ctx the parse tree
	 */
	void enterTraversalDT(GremlinParser.TraversalDTContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalDT}.
	 * @param ctx the parse tree
	 */
	void exitTraversalDT(GremlinParser.TraversalDTContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalGType}.
	 * @param ctx the parse tree
	 */
	void enterTraversalGType(GremlinParser.TraversalGTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalGType}.
	 * @param ctx the parse tree
	 */
	void exitTraversalGType(GremlinParser.TraversalGTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate(GremlinParser.TraversalPredicateContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate(GremlinParser.TraversalPredicateContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod(GremlinParser.TraversalTerminalMethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod(GremlinParser.TraversalTerminalMethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalSackMethod}.
	 * @param ctx the parse tree
	 */
	void enterTraversalSackMethod(GremlinParser.TraversalSackMethodContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalSackMethod}.
	 * @param ctx the parse tree
	 */
	void exitTraversalSackMethod(GremlinParser.TraversalSackMethodContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalComparator}.
	 * @param ctx the parse tree
	 */
	void enterTraversalComparator(GremlinParser.TraversalComparatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalComparator}.
	 * @param ctx the parse tree
	 */
	void exitTraversalComparator(GremlinParser.TraversalComparatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalFunction}.
	 * @param ctx the parse tree
	 */
	void enterTraversalFunction(GremlinParser.TraversalFunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalFunction}.
	 * @param ctx the parse tree
	 */
	void exitTraversalFunction(GremlinParser.TraversalFunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalBiFunction}.
	 * @param ctx the parse tree
	 */
	void enterTraversalBiFunction(GremlinParser.TraversalBiFunctionContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalBiFunction}.
	 * @param ctx the parse tree
	 */
	void exitTraversalBiFunction(GremlinParser.TraversalBiFunctionContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_eq}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_eq(GremlinParser.TraversalPredicate_eqContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_eq}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_eq(GremlinParser.TraversalPredicate_eqContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_neq}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_neq(GremlinParser.TraversalPredicate_neqContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_neq}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_neq(GremlinParser.TraversalPredicate_neqContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_typeOf}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_typeOf(GremlinParser.TraversalPredicate_typeOfContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_typeOf}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_typeOf(GremlinParser.TraversalPredicate_typeOfContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_lt}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_lt(GremlinParser.TraversalPredicate_ltContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_lt}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_lt(GremlinParser.TraversalPredicate_ltContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_lte}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_lte(GremlinParser.TraversalPredicate_lteContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_lte}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_lte(GremlinParser.TraversalPredicate_lteContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_gt}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_gt(GremlinParser.TraversalPredicate_gtContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_gt}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_gt(GremlinParser.TraversalPredicate_gtContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_gte}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_gte(GremlinParser.TraversalPredicate_gteContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_gte}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_gte(GremlinParser.TraversalPredicate_gteContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_inside}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_inside(GremlinParser.TraversalPredicate_insideContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_inside}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_inside(GremlinParser.TraversalPredicate_insideContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_outside}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_outside(GremlinParser.TraversalPredicate_outsideContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_outside}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_outside(GremlinParser.TraversalPredicate_outsideContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_between}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_between(GremlinParser.TraversalPredicate_betweenContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_between}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_between(GremlinParser.TraversalPredicate_betweenContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_within}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_within(GremlinParser.TraversalPredicate_withinContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_within}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_within(GremlinParser.TraversalPredicate_withinContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_without}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_without(GremlinParser.TraversalPredicate_withoutContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_without}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_without(GremlinParser.TraversalPredicate_withoutContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_not}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_not(GremlinParser.TraversalPredicate_notContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_not}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_not(GremlinParser.TraversalPredicate_notContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_containing}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_containing(GremlinParser.TraversalPredicate_containingContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_containing}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_containing(GremlinParser.TraversalPredicate_containingContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_notContaining}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_notContaining(GremlinParser.TraversalPredicate_notContainingContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_notContaining}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_notContaining(GremlinParser.TraversalPredicate_notContainingContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_startingWith}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_startingWith(GremlinParser.TraversalPredicate_startingWithContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_startingWith}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_startingWith(GremlinParser.TraversalPredicate_startingWithContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_notStartingWith}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_notStartingWith(GremlinParser.TraversalPredicate_notStartingWithContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_notStartingWith}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_notStartingWith(GremlinParser.TraversalPredicate_notStartingWithContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_endingWith}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_endingWith(GremlinParser.TraversalPredicate_endingWithContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_endingWith}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_endingWith(GremlinParser.TraversalPredicate_endingWithContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_notEndingWith}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_notEndingWith(GremlinParser.TraversalPredicate_notEndingWithContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_notEndingWith}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_notEndingWith(GremlinParser.TraversalPredicate_notEndingWithContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_regex}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_regex(GremlinParser.TraversalPredicate_regexContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_regex}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_regex(GremlinParser.TraversalPredicate_regexContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalPredicate_notRegex}.
	 * @param ctx the parse tree
	 */
	void enterTraversalPredicate_notRegex(GremlinParser.TraversalPredicate_notRegexContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalPredicate_notRegex}.
	 * @param ctx the parse tree
	 */
	void exitTraversalPredicate_notRegex(GremlinParser.TraversalPredicate_notRegexContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_explain}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_explain(GremlinParser.TraversalTerminalMethod_explainContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_explain}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_explain(GremlinParser.TraversalTerminalMethod_explainContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_hasNext}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_hasNext(GremlinParser.TraversalTerminalMethod_hasNextContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_hasNext}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_hasNext(GremlinParser.TraversalTerminalMethod_hasNextContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_iterate}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_iterate(GremlinParser.TraversalTerminalMethod_iterateContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_iterate}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_iterate(GremlinParser.TraversalTerminalMethod_iterateContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_tryNext}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_tryNext(GremlinParser.TraversalTerminalMethod_tryNextContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_tryNext}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_tryNext(GremlinParser.TraversalTerminalMethod_tryNextContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_next}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_next(GremlinParser.TraversalTerminalMethod_nextContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_next}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_next(GremlinParser.TraversalTerminalMethod_nextContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toList}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_toList(GremlinParser.TraversalTerminalMethod_toListContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toList}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_toList(GremlinParser.TraversalTerminalMethod_toListContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toSet}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_toSet(GremlinParser.TraversalTerminalMethod_toSetContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toSet}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_toSet(GremlinParser.TraversalTerminalMethod_toSetContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toBulkSet}.
	 * @param ctx the parse tree
	 */
	void enterTraversalTerminalMethod_toBulkSet(GremlinParser.TraversalTerminalMethod_toBulkSetContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalTerminalMethod_toBulkSet}.
	 * @param ctx the parse tree
	 */
	void exitTraversalTerminalMethod_toBulkSet(GremlinParser.TraversalTerminalMethod_toBulkSetContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionKeys}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionKeys(GremlinParser.WithOptionKeysContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionKeys}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionKeys(GremlinParser.WithOptionKeysContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#connectedComponentConstants}.
	 * @param ctx the parse tree
	 */
	void enterConnectedComponentConstants(GremlinParser.ConnectedComponentConstantsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#connectedComponentConstants}.
	 * @param ctx the parse tree
	 */
	void exitConnectedComponentConstants(GremlinParser.ConnectedComponentConstantsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#pageRankConstants}.
	 * @param ctx the parse tree
	 */
	void enterPageRankConstants(GremlinParser.PageRankConstantsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#pageRankConstants}.
	 * @param ctx the parse tree
	 */
	void exitPageRankConstants(GremlinParser.PageRankConstantsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#peerPressureConstants}.
	 * @param ctx the parse tree
	 */
	void enterPeerPressureConstants(GremlinParser.PeerPressureConstantsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#peerPressureConstants}.
	 * @param ctx the parse tree
	 */
	void exitPeerPressureConstants(GremlinParser.PeerPressureConstantsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathConstants}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathConstants(GremlinParser.ShortestPathConstantsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathConstants}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathConstants(GremlinParser.ShortestPathConstantsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsValues}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsValues(GremlinParser.WithOptionsValuesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsValues}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsValues(GremlinParser.WithOptionsValuesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsKeys}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsKeys(GremlinParser.IoOptionsKeysContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsKeys}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsKeys(GremlinParser.IoOptionsKeysContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsValues}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsValues(GremlinParser.IoOptionsValuesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsValues}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsValues(GremlinParser.IoOptionsValuesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#connectedComponentConstants_component}.
	 * @param ctx the parse tree
	 */
	void enterConnectedComponentConstants_component(GremlinParser.ConnectedComponentConstants_componentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#connectedComponentConstants_component}.
	 * @param ctx the parse tree
	 */
	void exitConnectedComponentConstants_component(GremlinParser.ConnectedComponentConstants_componentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#connectedComponentConstants_edges}.
	 * @param ctx the parse tree
	 */
	void enterConnectedComponentConstants_edges(GremlinParser.ConnectedComponentConstants_edgesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#connectedComponentConstants_edges}.
	 * @param ctx the parse tree
	 */
	void exitConnectedComponentConstants_edges(GremlinParser.ConnectedComponentConstants_edgesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#connectedComponentConstants_propertyName}.
	 * @param ctx the parse tree
	 */
	void enterConnectedComponentConstants_propertyName(GremlinParser.ConnectedComponentConstants_propertyNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#connectedComponentConstants_propertyName}.
	 * @param ctx the parse tree
	 */
	void exitConnectedComponentConstants_propertyName(GremlinParser.ConnectedComponentConstants_propertyNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#pageRankConstants_edges}.
	 * @param ctx the parse tree
	 */
	void enterPageRankConstants_edges(GremlinParser.PageRankConstants_edgesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#pageRankConstants_edges}.
	 * @param ctx the parse tree
	 */
	void exitPageRankConstants_edges(GremlinParser.PageRankConstants_edgesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#pageRankConstants_times}.
	 * @param ctx the parse tree
	 */
	void enterPageRankConstants_times(GremlinParser.PageRankConstants_timesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#pageRankConstants_times}.
	 * @param ctx the parse tree
	 */
	void exitPageRankConstants_times(GremlinParser.PageRankConstants_timesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#pageRankConstants_propertyName}.
	 * @param ctx the parse tree
	 */
	void enterPageRankConstants_propertyName(GremlinParser.PageRankConstants_propertyNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#pageRankConstants_propertyName}.
	 * @param ctx the parse tree
	 */
	void exitPageRankConstants_propertyName(GremlinParser.PageRankConstants_propertyNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#peerPressureConstants_edges}.
	 * @param ctx the parse tree
	 */
	void enterPeerPressureConstants_edges(GremlinParser.PeerPressureConstants_edgesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#peerPressureConstants_edges}.
	 * @param ctx the parse tree
	 */
	void exitPeerPressureConstants_edges(GremlinParser.PeerPressureConstants_edgesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#peerPressureConstants_times}.
	 * @param ctx the parse tree
	 */
	void enterPeerPressureConstants_times(GremlinParser.PeerPressureConstants_timesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#peerPressureConstants_times}.
	 * @param ctx the parse tree
	 */
	void exitPeerPressureConstants_times(GremlinParser.PeerPressureConstants_timesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#peerPressureConstants_propertyName}.
	 * @param ctx the parse tree
	 */
	void enterPeerPressureConstants_propertyName(GremlinParser.PeerPressureConstants_propertyNameContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#peerPressureConstants_propertyName}.
	 * @param ctx the parse tree
	 */
	void exitPeerPressureConstants_propertyName(GremlinParser.PeerPressureConstants_propertyNameContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathConstants_target}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathConstants_target(GremlinParser.ShortestPathConstants_targetContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathConstants_target}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathConstants_target(GremlinParser.ShortestPathConstants_targetContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathConstants_edges}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathConstants_edges(GremlinParser.ShortestPathConstants_edgesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathConstants_edges}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathConstants_edges(GremlinParser.ShortestPathConstants_edgesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathConstants_distance}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathConstants_distance(GremlinParser.ShortestPathConstants_distanceContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathConstants_distance}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathConstants_distance(GremlinParser.ShortestPathConstants_distanceContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathConstants_maxDistance}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathConstants_maxDistance(GremlinParser.ShortestPathConstants_maxDistanceContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathConstants_maxDistance}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathConstants_maxDistance(GremlinParser.ShortestPathConstants_maxDistanceContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathConstants_includeEdges}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathConstants_includeEdges(GremlinParser.ShortestPathConstants_includeEdgesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathConstants_includeEdges}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathConstants_includeEdges(GremlinParser.ShortestPathConstants_includeEdgesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_tokens}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_tokens(GremlinParser.WithOptionsConstants_tokensContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_tokens}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_tokens(GremlinParser.WithOptionsConstants_tokensContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_none}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_none(GremlinParser.WithOptionsConstants_noneContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_none}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_none(GremlinParser.WithOptionsConstants_noneContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_ids}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_ids(GremlinParser.WithOptionsConstants_idsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_ids}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_ids(GremlinParser.WithOptionsConstants_idsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_labels}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_labels(GremlinParser.WithOptionsConstants_labelsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_labels}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_labels(GremlinParser.WithOptionsConstants_labelsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_keys}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_keys(GremlinParser.WithOptionsConstants_keysContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_keys}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_keys(GremlinParser.WithOptionsConstants_keysContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_values}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_values(GremlinParser.WithOptionsConstants_valuesContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_values}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_values(GremlinParser.WithOptionsConstants_valuesContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_all}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_all(GremlinParser.WithOptionsConstants_allContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_all}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_all(GremlinParser.WithOptionsConstants_allContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_indexer}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_indexer(GremlinParser.WithOptionsConstants_indexerContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_indexer}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_indexer(GremlinParser.WithOptionsConstants_indexerContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_list}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_list(GremlinParser.WithOptionsConstants_listContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_list}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_list(GremlinParser.WithOptionsConstants_listContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsConstants_map}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsConstants_map(GremlinParser.WithOptionsConstants_mapContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsConstants_map}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsConstants_map(GremlinParser.WithOptionsConstants_mapContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsConstants_reader}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsConstants_reader(GremlinParser.IoOptionsConstants_readerContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsConstants_reader}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsConstants_reader(GremlinParser.IoOptionsConstants_readerContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsConstants_writer}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsConstants_writer(GremlinParser.IoOptionsConstants_writerContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsConstants_writer}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsConstants_writer(GremlinParser.IoOptionsConstants_writerContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsConstants_gryo}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsConstants_gryo(GremlinParser.IoOptionsConstants_gryoContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsConstants_gryo}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsConstants_gryo(GremlinParser.IoOptionsConstants_gryoContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsConstants_graphson}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsConstants_graphson(GremlinParser.IoOptionsConstants_graphsonContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsConstants_graphson}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsConstants_graphson(GremlinParser.IoOptionsConstants_graphsonContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsConstants_graphml}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsConstants_graphml(GremlinParser.IoOptionsConstants_graphmlContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsConstants_graphml}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsConstants_graphml(GremlinParser.IoOptionsConstants_graphmlContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#connectedComponentStringConstant}.
	 * @param ctx the parse tree
	 */
	void enterConnectedComponentStringConstant(GremlinParser.ConnectedComponentStringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#connectedComponentStringConstant}.
	 * @param ctx the parse tree
	 */
	void exitConnectedComponentStringConstant(GremlinParser.ConnectedComponentStringConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#pageRankStringConstant}.
	 * @param ctx the parse tree
	 */
	void enterPageRankStringConstant(GremlinParser.PageRankStringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#pageRankStringConstant}.
	 * @param ctx the parse tree
	 */
	void exitPageRankStringConstant(GremlinParser.PageRankStringConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#peerPressureStringConstant}.
	 * @param ctx the parse tree
	 */
	void enterPeerPressureStringConstant(GremlinParser.PeerPressureStringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#peerPressureStringConstant}.
	 * @param ctx the parse tree
	 */
	void exitPeerPressureStringConstant(GremlinParser.PeerPressureStringConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#shortestPathStringConstant}.
	 * @param ctx the parse tree
	 */
	void enterShortestPathStringConstant(GremlinParser.ShortestPathStringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#shortestPathStringConstant}.
	 * @param ctx the parse tree
	 */
	void exitShortestPathStringConstant(GremlinParser.ShortestPathStringConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#withOptionsStringConstant}.
	 * @param ctx the parse tree
	 */
	void enterWithOptionsStringConstant(GremlinParser.WithOptionsStringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#withOptionsStringConstant}.
	 * @param ctx the parse tree
	 */
	void exitWithOptionsStringConstant(GremlinParser.WithOptionsStringConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#ioOptionsStringConstant}.
	 * @param ctx the parse tree
	 */
	void enterIoOptionsStringConstant(GremlinParser.IoOptionsStringConstantContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#ioOptionsStringConstant}.
	 * @param ctx the parse tree
	 */
	void exitIoOptionsStringConstant(GremlinParser.IoOptionsStringConstantContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#booleanArgument}.
	 * @param ctx the parse tree
	 */
	void enterBooleanArgument(GremlinParser.BooleanArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#booleanArgument}.
	 * @param ctx the parse tree
	 */
	void exitBooleanArgument(GremlinParser.BooleanArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#integerArgument}.
	 * @param ctx the parse tree
	 */
	void enterIntegerArgument(GremlinParser.IntegerArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#integerArgument}.
	 * @param ctx the parse tree
	 */
	void exitIntegerArgument(GremlinParser.IntegerArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#floatArgument}.
	 * @param ctx the parse tree
	 */
	void enterFloatArgument(GremlinParser.FloatArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#floatArgument}.
	 * @param ctx the parse tree
	 */
	void exitFloatArgument(GremlinParser.FloatArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#stringArgument}.
	 * @param ctx the parse tree
	 */
	void enterStringArgument(GremlinParser.StringArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#stringArgument}.
	 * @param ctx the parse tree
	 */
	void exitStringArgument(GremlinParser.StringArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#stringNullableArgument}.
	 * @param ctx the parse tree
	 */
	void enterStringNullableArgument(GremlinParser.StringNullableArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#stringNullableArgument}.
	 * @param ctx the parse tree
	 */
	void exitStringNullableArgument(GremlinParser.StringNullableArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#stringNullableArgumentVarargs}.
	 * @param ctx the parse tree
	 */
	void enterStringNullableArgumentVarargs(GremlinParser.StringNullableArgumentVarargsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#stringNullableArgumentVarargs}.
	 * @param ctx the parse tree
	 */
	void exitStringNullableArgumentVarargs(GremlinParser.StringNullableArgumentVarargsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#dateArgument}.
	 * @param ctx the parse tree
	 */
	void enterDateArgument(GremlinParser.DateArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#dateArgument}.
	 * @param ctx the parse tree
	 */
	void exitDateArgument(GremlinParser.DateArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericArgument}.
	 * @param ctx the parse tree
	 */
	void enterGenericArgument(GremlinParser.GenericArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericArgument}.
	 * @param ctx the parse tree
	 */
	void exitGenericArgument(GremlinParser.GenericArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericArgumentVarargs}.
	 * @param ctx the parse tree
	 */
	void enterGenericArgumentVarargs(GremlinParser.GenericArgumentVarargsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericArgumentVarargs}.
	 * @param ctx the parse tree
	 */
	void exitGenericArgumentVarargs(GremlinParser.GenericArgumentVarargsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericMapArgument}.
	 * @param ctx the parse tree
	 */
	void enterGenericMapArgument(GremlinParser.GenericMapArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericMapArgument}.
	 * @param ctx the parse tree
	 */
	void exitGenericMapArgument(GremlinParser.GenericMapArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericMapNullableArgument}.
	 * @param ctx the parse tree
	 */
	void enterGenericMapNullableArgument(GremlinParser.GenericMapNullableArgumentContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericMapNullableArgument}.
	 * @param ctx the parse tree
	 */
	void exitGenericMapNullableArgument(GremlinParser.GenericMapNullableArgumentContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalStrategyVarargs}.
	 * @param ctx the parse tree
	 */
	void enterTraversalStrategyVarargs(GremlinParser.TraversalStrategyVarargsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalStrategyVarargs}.
	 * @param ctx the parse tree
	 */
	void exitTraversalStrategyVarargs(GremlinParser.TraversalStrategyVarargsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#traversalStrategyExpr}.
	 * @param ctx the parse tree
	 */
	void enterTraversalStrategyExpr(GremlinParser.TraversalStrategyExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#traversalStrategyExpr}.
	 * @param ctx the parse tree
	 */
	void exitTraversalStrategyExpr(GremlinParser.TraversalStrategyExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#classTypeList}.
	 * @param ctx the parse tree
	 */
	void enterClassTypeList(GremlinParser.ClassTypeListContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#classTypeList}.
	 * @param ctx the parse tree
	 */
	void exitClassTypeList(GremlinParser.ClassTypeListContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#classTypeExpr}.
	 * @param ctx the parse tree
	 */
	void enterClassTypeExpr(GremlinParser.ClassTypeExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#classTypeExpr}.
	 * @param ctx the parse tree
	 */
	void exitClassTypeExpr(GremlinParser.ClassTypeExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#nestedTraversalList}.
	 * @param ctx the parse tree
	 */
	void enterNestedTraversalList(GremlinParser.NestedTraversalListContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#nestedTraversalList}.
	 * @param ctx the parse tree
	 */
	void exitNestedTraversalList(GremlinParser.NestedTraversalListContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#nestedTraversalExpr}.
	 * @param ctx the parse tree
	 */
	void enterNestedTraversalExpr(GremlinParser.NestedTraversalExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#nestedTraversalExpr}.
	 * @param ctx the parse tree
	 */
	void exitNestedTraversalExpr(GremlinParser.NestedTraversalExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericCollectionLiteral}.
	 * @param ctx the parse tree
	 */
	void enterGenericCollectionLiteral(GremlinParser.GenericCollectionLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericCollectionLiteral}.
	 * @param ctx the parse tree
	 */
	void exitGenericCollectionLiteral(GremlinParser.GenericCollectionLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericLiteralVarargs}.
	 * @param ctx the parse tree
	 */
	void enterGenericLiteralVarargs(GremlinParser.GenericLiteralVarargsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericLiteralVarargs}.
	 * @param ctx the parse tree
	 */
	void exitGenericLiteralVarargs(GremlinParser.GenericLiteralVarargsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericLiteralExpr}.
	 * @param ctx the parse tree
	 */
	void enterGenericLiteralExpr(GremlinParser.GenericLiteralExprContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericLiteralExpr}.
	 * @param ctx the parse tree
	 */
	void exitGenericLiteralExpr(GremlinParser.GenericLiteralExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericMapNullableLiteral}.
	 * @param ctx the parse tree
	 */
	void enterGenericMapNullableLiteral(GremlinParser.GenericMapNullableLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericMapNullableLiteral}.
	 * @param ctx the parse tree
	 */
	void exitGenericMapNullableLiteral(GremlinParser.GenericMapNullableLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericRangeLiteral}.
	 * @param ctx the parse tree
	 */
	void enterGenericRangeLiteral(GremlinParser.GenericRangeLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericRangeLiteral}.
	 * @param ctx the parse tree
	 */
	void exitGenericRangeLiteral(GremlinParser.GenericRangeLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericSetLiteral}.
	 * @param ctx the parse tree
	 */
	void enterGenericSetLiteral(GremlinParser.GenericSetLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericSetLiteral}.
	 * @param ctx the parse tree
	 */
	void exitGenericSetLiteral(GremlinParser.GenericSetLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#stringNullableLiteralVarargs}.
	 * @param ctx the parse tree
	 */
	void enterStringNullableLiteralVarargs(GremlinParser.StringNullableLiteralVarargsContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#stringNullableLiteralVarargs}.
	 * @param ctx the parse tree
	 */
	void exitStringNullableLiteralVarargs(GremlinParser.StringNullableLiteralVarargsContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericLiteral}.
	 * @param ctx the parse tree
	 */
	void enterGenericLiteral(GremlinParser.GenericLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericLiteral}.
	 * @param ctx the parse tree
	 */
	void exitGenericLiteral(GremlinParser.GenericLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#genericMapLiteral}.
	 * @param ctx the parse tree
	 */
	void enterGenericMapLiteral(GremlinParser.GenericMapLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#genericMapLiteral}.
	 * @param ctx the parse tree
	 */
	void exitGenericMapLiteral(GremlinParser.GenericMapLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#mapKey}.
	 * @param ctx the parse tree
	 */
	void enterMapKey(GremlinParser.MapKeyContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#mapKey}.
	 * @param ctx the parse tree
	 */
	void exitMapKey(GremlinParser.MapKeyContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#mapEntry}.
	 * @param ctx the parse tree
	 */
	void enterMapEntry(GremlinParser.MapEntryContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#mapEntry}.
	 * @param ctx the parse tree
	 */
	void exitMapEntry(GremlinParser.MapEntryContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#stringLiteral}.
	 * @param ctx the parse tree
	 */
	void enterStringLiteral(GremlinParser.StringLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#stringLiteral}.
	 * @param ctx the parse tree
	 */
	void exitStringLiteral(GremlinParser.StringLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#stringNullableLiteral}.
	 * @param ctx the parse tree
	 */
	void enterStringNullableLiteral(GremlinParser.StringNullableLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#stringNullableLiteral}.
	 * @param ctx the parse tree
	 */
	void exitStringNullableLiteral(GremlinParser.StringNullableLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#integerLiteral}.
	 * @param ctx the parse tree
	 */
	void enterIntegerLiteral(GremlinParser.IntegerLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#integerLiteral}.
	 * @param ctx the parse tree
	 */
	void exitIntegerLiteral(GremlinParser.IntegerLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#floatLiteral}.
	 * @param ctx the parse tree
	 */
	void enterFloatLiteral(GremlinParser.FloatLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#floatLiteral}.
	 * @param ctx the parse tree
	 */
	void exitFloatLiteral(GremlinParser.FloatLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#numericLiteral}.
	 * @param ctx the parse tree
	 */
	void enterNumericLiteral(GremlinParser.NumericLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#numericLiteral}.
	 * @param ctx the parse tree
	 */
	void exitNumericLiteral(GremlinParser.NumericLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#booleanLiteral}.
	 * @param ctx the parse tree
	 */
	void enterBooleanLiteral(GremlinParser.BooleanLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#booleanLiteral}.
	 * @param ctx the parse tree
	 */
	void exitBooleanLiteral(GremlinParser.BooleanLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#dateLiteral}.
	 * @param ctx the parse tree
	 */
	void enterDateLiteral(GremlinParser.DateLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#dateLiteral}.
	 * @param ctx the parse tree
	 */
	void exitDateLiteral(GremlinParser.DateLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#nullLiteral}.
	 * @param ctx the parse tree
	 */
	void enterNullLiteral(GremlinParser.NullLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#nullLiteral}.
	 * @param ctx the parse tree
	 */
	void exitNullLiteral(GremlinParser.NullLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#nanLiteral}.
	 * @param ctx the parse tree
	 */
	void enterNanLiteral(GremlinParser.NanLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#nanLiteral}.
	 * @param ctx the parse tree
	 */
	void exitNanLiteral(GremlinParser.NanLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#infLiteral}.
	 * @param ctx the parse tree
	 */
	void enterInfLiteral(GremlinParser.InfLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#infLiteral}.
	 * @param ctx the parse tree
	 */
	void exitInfLiteral(GremlinParser.InfLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#uuidLiteral}.
	 * @param ctx the parse tree
	 */
	void enterUuidLiteral(GremlinParser.UuidLiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#uuidLiteral}.
	 * @param ctx the parse tree
	 */
	void exitUuidLiteral(GremlinParser.UuidLiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#nakedKey}.
	 * @param ctx the parse tree
	 */
	void enterNakedKey(GremlinParser.NakedKeyContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#nakedKey}.
	 * @param ctx the parse tree
	 */
	void exitNakedKey(GremlinParser.NakedKeyContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#classType}.
	 * @param ctx the parse tree
	 */
	void enterClassType(GremlinParser.ClassTypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#classType}.
	 * @param ctx the parse tree
	 */
	void exitClassType(GremlinParser.ClassTypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#variable}.
	 * @param ctx the parse tree
	 */
	void enterVariable(GremlinParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#variable}.
	 * @param ctx the parse tree
	 */
	void exitVariable(GremlinParser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link GremlinParser#keyword}.
	 * @param ctx the parse tree
	 */
	void enterKeyword(GremlinParser.KeywordContext ctx);
	/**
	 * Exit a parse tree produced by {@link GremlinParser#keyword}.
	 * @param ctx the parse tree
	 */
	void exitKeyword(GremlinParser.KeywordContext ctx);
}