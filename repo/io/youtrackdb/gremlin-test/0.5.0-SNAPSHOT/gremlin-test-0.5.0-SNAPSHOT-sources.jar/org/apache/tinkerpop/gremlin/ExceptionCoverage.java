/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.tinkerpop.gremlin;

import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Defines the list of standard exceptions covered by a test set.  Used in conjunction with the exception compliance
 * unit tests to ensure full coverage of defined exceptions in Gremlin Structure.  The list of exceptions is defined with by
 * the exception class and the list of methods that generate the exceptions that are covered by the test.
 *
 * @author Stephen Mallette (http://stephen.genoprime.com)
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Repeatable(ExceptionCoverageSet.class)
public @interface ExceptionCoverage {
    /**
     * The exception class from Gremlin Structure that contains the exceptions that are covered by the block of tests.
     */
    public Class exceptionClass();

    /**
     * The list of method names from the related {@link #exceptionClass()} that are covered by the tests.
     */
    public String[] methods();
}
