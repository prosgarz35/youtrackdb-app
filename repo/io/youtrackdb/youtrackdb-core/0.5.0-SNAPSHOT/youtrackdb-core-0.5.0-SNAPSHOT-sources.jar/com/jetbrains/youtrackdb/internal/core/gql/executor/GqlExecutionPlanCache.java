package com.jetbrains.youtrackdb.internal.core.gql.executor;

import com.jetbrains.youtrackdb.internal.core.db.AbstractMetadataUpdateCache;
import com.jetbrains.youtrackdb.internal.core.db.DatabaseSessionEmbedded;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * LRU cache for already prepared GQL execution plans using Guava Cache.
 * Stores itself in SharedContext as a resource and acts as an entry point for the GQL executor.
 */
public class GqlExecutionPlanCache extends AbstractMetadataUpdateCache<String, GqlExecutionPlan> {

  /**
   * @param size maximum number of plans to cache; 0 means cache disabled (no storage)
   */
  public GqlExecutionPlanCache(int size) {
    super(size);
  }

  public static long getLastInvalidation(@Nonnull DatabaseSessionEmbedded db) {
    return instance(db).getLastInvalidation();
  }

  /**
   * Returns true if the corresponding execution plan is present in the cache.
   *
   * @param statement a GQL statement
   * @return true if the corresponding execution plan is present in the cache
   */
  @SuppressWarnings("unused")
  public boolean contains(@Nonnull String statement) {
    return containsKey(statement);
  }

  /**
   * Returns an already prepared GQL execution plan from cache, or null if not found.
   *
   * @param statement the GQL query string
   * @param ctx       the execution context
   * @param db        the current DB instance
   * @return an execution plan from the cache, or null if not cached
   */
  @Nullable public static GqlExecutionPlan get(
      @Nonnull String statement, @Nonnull GqlExecutionContext ctx,
      @Nonnull DatabaseSessionEmbedded db) {
    if (db.getTxSchemaState() != null) {
      // An open schema- or index-changing transaction plans against its tx-local schema view
      // (tx-created classes with provisional collection ids, tx-dropped classes and indexes). A
      // plan cached from committed state can be stale against that view (for example a pre-cached
      // polymorphic scan that misses a tx-created subclass), so the shared cache is bypassed for
      // the transaction's duration, mirroring the YqlExecutionPlanCache guard. Schema
      // transactions are rare, so the extra planning cost is negligible.
      return null;
    }
    var resource = db.getSharedContext().getGqlExecutionPlanCache();
    return resource.getInternal(statement, ctx);
  }

  /**
   * Stores a GQL execution plan in the cache.
   *
   * @param statement the GQL query string
   * @param plan      the execution plan to cache
   * @param db        the current DB instance
   */
  public static void put(@Nonnull String statement, @Nonnull GqlExecutionPlan plan,
      @Nonnull DatabaseSessionEmbedded db) {
    if (db.getTxSchemaState() != null) {
      // The mirror of the get-side bypass: a plan built during a schema- or index-changing
      // transaction is shaped by the tx-local schema view and must not be published to other
      // sessions through the shared cache. A leaked entry would outlive the transaction's
      // rollback, because only a schema commit invalidates this cache.
      return;
    }
    var resource = db.getSharedContext().getGqlExecutionPlanCache();
    resource.putInternal(statement, plan);
  }

  /**
   * Internal method to store a plan in cache. The schema-transaction bypass is applied by the
   * static {@link #put(String, GqlExecutionPlan, DatabaseSessionEmbedded)} wrapper (the
   * production entry point); this primitive implements only the cache mechanics.
   */
  public void putInternal(@Nonnull String statement, @Nonnull GqlExecutionPlan plan) {
    if (!cacheEnabled()) {
      return;
    }
    putCached(statement, plan.copy());
  }

  /**
   * Returns the cached execution plan for the given GQL statement, or null if not found.
   *
   * @param statement a GQL query string
   * @param ctx       execution context
   * @return the corresponding execution plan from cache, or null if not found
   * @see #get(String, GqlExecutionContext, DatabaseSessionEmbedded) the static wrapper that
   *     applies the schema-transaction bypass before delegating here
   */
  @SuppressWarnings("unused")
  @Nullable public GqlExecutionPlan getInternal(@Nonnull String statement, @Nonnull GqlExecutionContext ctx) {
    if (!cacheEnabled()) {
      return null;
    }
    var cached = getCached(statement);
    if (cached != null) {
      recordHit();
      return cached.copy();
    }
    recordMiss();
    return null;
  }

  public static @Nonnull GqlExecutionPlanCache instance(@Nonnull DatabaseSessionEmbedded db) {
    return db.getSharedContext().getGqlExecutionPlanCache();
  }
}
