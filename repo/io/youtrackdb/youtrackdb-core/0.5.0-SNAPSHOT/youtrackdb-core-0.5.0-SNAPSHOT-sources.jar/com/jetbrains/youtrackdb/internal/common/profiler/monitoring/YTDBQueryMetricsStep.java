package com.jetbrains.youtrackdb.internal.common.profiler.monitoring;

import com.jetbrains.youtrackdb.internal.common.log.LogManager;
import com.jetbrains.youtrackdb.internal.common.profiler.Ticker;
import com.jetbrains.youtrackdb.internal.common.profiler.monitoring.QueryMetricsListener.QueryDetails;
import com.jetbrains.youtrackdb.internal.core.gremlin.YTDBTransaction;
import com.jetbrains.youtrackdb.internal.core.gremlin.translator.step.MultiPlanMatchStep;
import com.jetbrains.youtrackdb.internal.core.gremlin.translator.step.YTDBMatchPlanStep;
import com.jetbrains.youtrackdb.internal.core.gremlin.traversal.step.sideeffect.YTDBGraphStep;
import com.jetbrains.youtrackdb.internal.core.query.ExecutionPlan;
import java.util.NoSuchElementException;
import java.util.Set;
import javax.annotation.Nullable;
import org.apache.tinkerpop.gremlin.process.traversal.Bytecode;
import org.apache.tinkerpop.gremlin.process.traversal.Script;
import org.apache.tinkerpop.gremlin.process.traversal.Traversal;
import org.apache.tinkerpop.gremlin.process.traversal.Traverser.Admin;
import org.apache.tinkerpop.gremlin.process.traversal.dsl.graph.GraphTraversal;
import org.apache.tinkerpop.gremlin.process.traversal.dsl.graph.GraphTraversalSource;
import org.apache.tinkerpop.gremlin.process.traversal.step.util.AbstractStep;
import org.apache.tinkerpop.gremlin.process.traversal.translator.GroovyTranslator;
import org.apache.tinkerpop.gremlin.process.traversal.util.TraversalHelper;

/// A transparent TinkerPop step that measures query execution time and reports it to a
/// [QueryMetricsListener] when the traversal is closed.
///
/// This step is injected at the end of every traversal by [YTDBQueryMetricsStrategy] when
/// query monitoring is enabled on the transaction. It passes traversers through unchanged
/// while recording timing information.
///
/// Two timing modes are supported:
///
/// - **Lightweight** ([QueryMonitoringMode#LIGHTWEIGHT]): uses an approximate [Ticker] to
///   measure wall-clock duration from the first to the last `hasNext()`/`next()` call.
///   Low overhead, suitable for production.
///
/// - **Exact** ([QueryMonitoringMode#EXACT]): uses `System.nanoTime()` to accumulate the
///   actual CPU time spent inside `hasNext()`/`next()` calls, excluding time between calls.
///   Higher overhead, useful for profiling.
///
/// On [#close], the step translates the traversal bytecode into a readable Gremlin string
/// (with values anonymized) and delivers it together with timing data to the listener.
/// If the traversal was never iterated, the listener is not notified.
///
/// @see YTDBQueryMetricsStrategy
/// @see QueryMetricsListener
public class YTDBQueryMetricsStep<S> extends AbstractStep<S, S> implements AutoCloseable {

  /// GroovyTranslator is not thread-safe: its internal TypeTranslator reuses a mutable Script
  /// object across calls. ThreadLocal gives one instance per thread to avoid both repeated
  /// allocation and concurrent corruption.
  private static final ThreadLocal<GroovyTranslator> GROOVY_TRANSLATOR =
      ThreadLocal.withInitial(() -> GroovyTranslator.of("g",
          new ValueAnonymizingTypeTranslator()));

  private final YTDBTransaction ytdbTx;
  private final String querySummary;
  private final Ticker ticker;
  private final boolean isLightweight;
  private boolean hasStarted = false;
  private boolean closed = false;
  private long startMillis;
  private long nano;
  private long endNano;

  public YTDBQueryMetricsStep(
      Traversal.Admin<?, ?> traversal,
      YTDBTransaction ytdbTx,
      @Nullable String querySummary,
      Ticker ticker) {
    super(traversal);
    this.ytdbTx = ytdbTx;
    this.querySummary = querySummary;
    this.isLightweight = ytdbTx.getQueryMonitoringMode() == QueryMonitoringMode.LIGHTWEIGHT;
    this.ticker = ticker;
  }

  @Override
  protected Admin<S> processNextStart() throws NoSuchElementException {
    return starts.next();
  }

  /// The execution plan of the monitored query for the listener, or {@code null} if none is
  /// available. Prefers a Gremlin-to-MATCH boundary step when present ({@link YTDBMatchPlanStep} /
  /// {@link MultiPlanMatchStep}): those steps own the compiled MATCH plan and replace the
  /// half-measure {@link YTDBGraphStep} source. Otherwise reads {@link
  /// YTDBGraphStep#getLastExecutionPlan()} from the half-measure source. A root traversal has a
  /// single such source; if that step ran no plan-backed query (for example a by-id lookup) its
  /// plan is {@code null}, which is correct. For a multi-plan union the first child's plan is
  /// surfaced — enough for scan/index detectors that inspect step types.
  ///
  /// Called from inside the listener callback [#close] fires, which is what pins WHICH plan object
  /// a re-iterated traversal reports. A boundary step re-armed after a close swaps its plan for a
  /// fresh copy, so its accessor returns a different object per pass; the boundary's contract is
  /// that within a pass — up to and including the close that ends it — the accessor returns the
  /// plan that produced that pass's rows. Reading it here rather than caching a plan at
  /// first-iteration time is what keeps each reported run matched to its own plan.
  @Nullable private ExecutionPlan capturedExecutionPlan() {
    var matchPlan =
        TraversalHelper.getFirstStepOfAssignableClass(YTDBMatchPlanStep.class, traversal);
    if (matchPlan.isPresent()) {
      return matchPlan.get().getPlan();
    }
    var multiPlan =
        TraversalHelper.getFirstStepOfAssignableClass(MultiPlanMatchStep.class, traversal);
    if (multiPlan.isPresent()) {
      // getFirstStepOfAssignableClass returns a raw Optional; pin the wildcard so getPlans()
      // keeps InternalExecutionPlan rather than erasing to Object.
      MultiPlanMatchStep<?, ?> multi = multiPlan.get();
      var plans = multi.getPlans();
      return plans.isEmpty() ? null : plans.getFirst();
    }
    return TraversalHelper.getFirstStepOfAssignableClass(YTDBGraphStep.class, traversal)
        .map(YTDBGraphStep::getLastExecutionPlan)
        .orElse(null);
  }

  @Override
  public boolean hasNext() {
    queryHasStarted();
    if (isLightweight) {
      try {
        return super.hasNext();
      } finally {
        endNano = ticker.approximateNanoTime();
      }
    } else {
      final var now = System.nanoTime();
      try {
        return super.hasNext();
      } finally {
        nano += System.nanoTime() - now;
      }
    }
  }

  @Override
  public Admin<S> next() {
    queryHasStarted();
    if (isLightweight) {
      try {
        return super.next();
      } finally {
        endNano = ticker.approximateNanoTime();
      }
    } else {
      final var now = System.nanoTime();
      try {
        return super.next();
      } finally {
        nano += System.nanoTime() - now;
      }
    }
  }

  @Override
  public void close() throws Exception {
    // Guard against a second close: close() is not naturally idempotent, and a started
    // traversal can be closed more than once (e.g. toList() closes it, then an enclosing
    // try-with-resources closes it again). Set the flag before queryFinished(...) so that
    // even if the listener throws (the body catches and logs), a later close is still a no-op.
    if (!hasStarted || closed) {
      return;
    }
    closed = true;

    final var duration = isLightweight ? endNano - nano : nano;
    try {
      ytdbTx.getQueryMetricsListener().queryFinished(
          new QueryDetails() {
            private String cachedQuery;

            @Override
            public String getQuery() {
              if (cachedQuery == null) {
                cachedQuery =
                    GROOVY_TRANSLATOR.get().translate(traversal.getBytecode()).getScript();
              }
              return cachedQuery;
            }

            @Override
            public String getQuerySummary() {
              return querySummary;
            }

            @Override
            public String getTransactionTrackingId() {
              return ytdbTx.getTrackingId();
            }

            @Override
            public ExecutionPlan getExecutionPlan() {
              return capturedExecutionPlan();
            }
          },
          startMillis,
          duration);
    } catch (Exception e) {
      LogManager.instance().error(this,
          "Error in QueryMetricsListener callback", e);
    }
  }

  @Override
  public void reset() {
    // Re-arm the base AbstractStep iterator first: super.reset() clears the exhausted state
    // so this step can be iterated again. Only then clear the monitoring state, so a re-run
    // starts fresh with new timing measurements and fires queryFinished exactly once.
    super.reset();
    this.hasStarted = false;
    this.closed = false;
    this.startMillis = 0;
    this.nano = 0;
    this.endNano = 0;
  }

  private void queryHasStarted() {
    if (hasStarted) {
      return;
    }
    hasStarted = true;

    if (isLightweight) {
      this.startMillis = ticker.approximateCurrentTimeMillis();
      this.nano = ticker.approximateNanoTime();
    } else {
      this.startMillis = System.currentTimeMillis();
    }
  }

  /// Extends [GroovyTranslator.DefaultTypeTranslator] to produce a readable Gremlin query string
  /// that preserves structural identifiers (labels, property keys, step labels, side effect keys)
  /// while replacing actual data values with bind variable placeholders (`_args_N`).
  ///
  /// This makes the query string safe for logging and monitoring without exposing user data,
  /// while keeping enough structure to understand which query was executed.
  ///
  /// The translator categorizes each Gremlin step's arguments into four groups:
  ///
  /// 1. **Fully structural**: ALL arguments are identifiers (labels, keys, etc.) and are
  ///    rendered as-is. This applies to a known set of operators such as `hasLabel`,
  ///    `out`, `values`, `as`, `aggregate`, etc. Examples: `hasLabel("person")`,
  ///    `out("knows")`, `values("name")`, `as("a")`, `aggregate("x")`.
  ///
  /// 2. **Mixed — `has`**: all arguments except the last are structural (property key,
  ///    optionally preceded by a label), and the last argument is a value or predicate
  ///    that gets parameterized. Examples:
  ///    - `has("age", 29)` → `has("age", _args_0)` — key preserved, value hidden
  ///    - `has("person", "age", 29)` → `has("person", "age", _args_0)` — label + key preserved
  ///    - `has("age")` → `has("age")` — single-arg existence check, key preserved
  ///
  /// 3. **Mixed — `property`**: the property key is structural; the value and any
  ///    meta-property key/value pairs are parameterized. When a Cardinality enum precedes
  ///    the key, it is also rendered structurally. Examples:
  ///    - `property("name", "foo")` → `property("name", _args_0)` — key preserved
  ///    - `property("name", "marko", "since", 2020)` → `property("name", _args_0, _args_1,
  ///      _args_2)` — key preserved, value and meta-properties parameterized
  ///    - `property(Cardinality.single, "name", "marko")` →
  ///      `property(Cardinality.single, "name", _args_0)` — cardinality and key preserved
  ///
  /// 4. **Fully parameterized** (everything else): all arguments are treated as values and
  ///    replaced with placeholders. Non-string/non-primitive arguments (traversals, enums, P
  ///    predicates) are recursed into via `convertToScript` which handles them correctly —
  ///    traversals are rendered structurally, enums as constants, and P values are parameterized.
  ///    Examples: `limit(_args_0)`, `is(P.gt(_args_0))`, `choose(__.hasLabel("person"), ...)`.
  static class ValueAnonymizingTypeTranslator
      extends GroovyTranslator.DefaultTypeTranslator {

    /// Operators whose ALL arguments are structural (labels, property keys, step labels,
    /// or side effect keys). String arguments of these operators are rendered literally;
    /// non-string arguments (traversals, enums, etc.) are recursed into normally.
    private static final Set<String> STRUCTURAL_OPERATORS = Set.of(
        "hasLabel", "hasKey", "hasNot",
        "out", "in", "both", "outE", "inE", "bothE",
        "addV", "addE",
        "values", "valueMap", "elementMap", "properties", "propertyMap",
        "project", "select", "as", "by", "from", "to",
        "aggregate", "cap", "subgraph");

    ValueAnonymizingTypeTranslator() {
      // withParameters=true makes convertToScript() parameterize primitives and strings
      // by default. We selectively bypass this for structural arguments by calling
      // appendStructural() instead of convertToScript().
      super(true);
    }

    @Override
    protected Script produceScript(String traversalSource, Bytecode bytecode) {
      script.append(traversalSource);
      for (final var instruction : bytecode.getInstructions()) {
        final var op = instruction.getOperator();
        final var args = instruction.getArguments();

        if (GraphTraversalSource.Symbols.tx.equals(op)) {
          // tx() is special in TinkerPop: the bytecode stores the command (commit/rollback)
          // as an argument, but the Groovy syntax is tx().commit() not tx("commit").
          return script.append(".").append(op).append("().").append(args[0].toString())
              .append("()");
        }

        script.append(".").append(op).append("(");

        if (args.length > 0) {
          if (STRUCTURAL_OPERATORS.contains(op)) {
            // All arguments are identifiers — render them literally.
            appendAllStructural(args);
          } else if (GraphTraversal.Symbols.has.equals(op)) {
            // has(): leading args are structural (key, or label + key), and the last
            // arg is a value/predicate. Special case: has(key) with a single arg is a
            // pure existence check — the key is structural, no value to parameterize.
            if (args.length >= 2) {
              appendHasArgs(args);
            } else {
              appendAllStructural(args);
            }
          } else if (GraphTraversal.Symbols.property.equals(op)) {
            // property(): the property key is structural; the value and any
            // meta-property key/value pairs are all parameterized. When a Cardinality
            // enum precedes the key, it is also rendered structurally.
            appendPropertyArgs(args);
          } else {
            // Default: all arguments are parameterized. Non-primitive arguments
            // (Bytecode, Traversal, P, Enum) are handled by convertToScript() which
            // recurses into them — e.g., a nested traversal like __.out("knows") will
            // re-enter produceScript() and have its own arguments categorized.
            appendAllParameterized(args);
          }
        }
        script.append(")");
      }
      return script;
    }

    /// Renders all arguments as structural identifiers — strings are quoted literally,
    /// non-strings are recursed into via [#convertToScript].
    private void appendAllStructural(Object[] args) {
      for (var i = 0; i < args.length; i++) {
        if (i > 0) {
          script.append(",");
        }
        appendStructural(args[i]);
      }
    }

    /// Renders all arguments as parameterized values via [#convertToScript], which replaces
    /// primitives and strings with `_args_N` placeholders.
    private void appendAllParameterized(Object[] args) {
      for (var i = 0; i < args.length; i++) {
        if (i > 0) {
          script.append(",");
        }
        convertToScript(args[i]);
      }
    }

    /// Renders arguments for the `has()` step, where all arguments except the last are
    /// structural (labels/keys) and the last is a value or predicate.
    ///
    /// Examples:
    /// - `has("age", 29)` — "age" is structural, 29 is parameterized
    /// - `has("person", "name", "marko")` — "person" and "name" structural, "marko" parameterized
    /// - `has("age", P.gt(27))` — "age" is structural, P.gt(27) is recursed into and 27
    ///   inside the predicate is parameterized by [#convertToScript]
    private void appendHasArgs(Object[] args) {
      for (var i = 0; i < args.length; i++) {
        if (i < args.length - 1) {
          appendStructural(args[i]);
        } else {
          convertToScript(args[i]);
        }
        if (i < args.length - 1) {
          script.append(",");
        }
      }
    }

    /// Renders arguments for the `property()` step. The property key is structural;
    /// the value and any meta-property key/value pairs are parameterized. When a
    /// Cardinality enum precedes the key, it is also rendered structurally.
    ///
    /// Examples:
    /// - `property("name", "foo")` — "name" is structural, "foo" is parameterized
    /// - `property("name", "marko", "since", 2020)` — "name" is structural, "marko",
    ///   "since", and 2020 are all parameterized
    /// - `property(Cardinality.single, "name", "marko")` — Cardinality and "name" are
    ///   structural, "marko" is parameterized
    private void appendPropertyArgs(Object[] args) {
      // When the first argument is not a String, it is a Cardinality enum and the
      // property key follows as the second argument.
      var keyIndex = (args[0] instanceof String) ? 0 : 1;
      for (var i = 0; i <= keyIndex; i++) {
        if (i > 0) {
          script.append(",");
        }
        appendStructural(args[i]);
      }
      for (var i = keyIndex + 1; i < args.length; i++) {
        script.append(",");
        convertToScript(args[i]);
      }
    }

    /// Renders a single argument as a structural identifier. Strings are quoted literally
    /// (bypassing parameterization). Non-strings (enums, traversals, predicates) are passed
    /// to [#convertToScript], which handles them according to their type.
    private void appendStructural(Object arg) {
      if (arg instanceof String s) {
        script.append(getSyntax(s));
      } else {
        convertToScript(arg);
      }
    }
  }
}
