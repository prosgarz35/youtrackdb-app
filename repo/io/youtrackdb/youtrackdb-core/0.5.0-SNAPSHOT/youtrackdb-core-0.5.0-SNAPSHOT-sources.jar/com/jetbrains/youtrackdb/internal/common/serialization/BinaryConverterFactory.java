/*
 *
 *
 *  *
 *  *  Licensed under the Apache License, Version 2.0 (the "License");
 *  *  you may not use this file except in compliance with the License.
 *  *  You may obtain a copy of the License at
 *  *
 *  *       http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  *  Unless required by applicable law or agreed to in writing, software
 *  *  distributed under the License is distributed on an "AS IS" BASIS,
 *  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  *  See the License for the specific language governing permissions and
 *  *  limitations under the License.
 *  *
 *
 *
 */

package com.jetbrains.youtrackdb.internal.common.serialization;

import com.jetbrains.youtrackdb.api.config.GlobalConfiguration;

/**
 * Factory that provides the appropriate {@link BinaryConverter} implementation for the platform.
 *
 * @since 26.07.12
 */
public class BinaryConverterFactory {

  private static final boolean unsafeWasDetected;

  static {
    var unsafeDetected = false;

    try {
      var sunClass = Class.forName("sun.misc.Unsafe");
      unsafeDetected = sunClass != null;
    } catch (ClassNotFoundException ignore) {
      // Ignore
    }

    unsafeWasDetected = unsafeDetected;
  }

  public static BinaryConverter getConverter() {
    var useUnsafe = GlobalConfiguration.MEMORY_USE_UNSAFE.getValueAsBoolean();

    if (useUnsafe && unsafeWasDetected) {
      return UnsafeBinaryConverter.INSTANCE;
    }

    return SafeBinaryConverter.INSTANCE;
  }
}
