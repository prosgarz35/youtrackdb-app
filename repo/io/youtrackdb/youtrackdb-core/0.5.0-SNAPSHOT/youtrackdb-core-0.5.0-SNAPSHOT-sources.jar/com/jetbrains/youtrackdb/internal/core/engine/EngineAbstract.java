/*
 *
 *
 *  *
 *  *  Licensed under the Apache License, Version 2.0 (the "License");
 *  *  you may not use this file except in compliance with the License.
 *  *  You may obtain a copy of the License at
 *  *
 *  *       http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  *  Unless required by applicable law or agreed to in writing, software
 *  *  distributed under the License is distributed on an "AS IS" BASIS,
 *  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  *  See the License for the specific language governing permissions and
 *  *  limitations under the License.
 *  *
 *
 *
 */
package com.jetbrains.youtrackdb.internal.core.engine;

public abstract class EngineAbstract implements Engine {

  // Volatile to guarantee cross-thread visibility. While the factoryLifecycleLock
  // in YouTrackDBEnginesManager provides happens-before for init/close paths,
  // isRunning() is also called outside the lock (e.g. getEngineIfRunning,
  // getRunningEngine), and the volatile write in startup() acts as a StoreStore
  // fence ensuring that all fields initialized before super.startup() (such as
  // EngineLocalPaginated.readCache) are visible to any thread that observes
  // running==true.
  private volatile boolean running = false;

  @Override
  public void startup() {
    this.running = true;
  }

  @Override
  public void shutdown() {
    this.running = false;
  }

  @Override
  public boolean isRunning() {
    return running;
  }
}
