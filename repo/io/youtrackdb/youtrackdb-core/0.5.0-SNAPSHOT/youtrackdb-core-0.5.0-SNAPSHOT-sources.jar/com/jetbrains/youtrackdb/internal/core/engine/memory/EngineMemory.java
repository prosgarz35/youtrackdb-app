/*
 *
 *
 *  *
 *  *  Licensed under the Apache License, Version 2.0 (the "License");
 *  *  you may not use this file except in compliance with the License.
 *  *  You may obtain a copy of the License at
 *  *
 *  *       http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  *  Unless required by applicable law or agreed to in writing, software
 *  *  distributed under the License is distributed on an "AS IS" BASIS,
 *  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  *  See the License for the specific language governing permissions and
 *  *  limitations under the License.
 *  *
 *
 *
 */
package com.jetbrains.youtrackdb.internal.core.engine.memory;

import com.jetbrains.youtrackdb.internal.common.io.IOUtils;
import com.jetbrains.youtrackdb.internal.common.log.LogManager;
import com.jetbrains.youtrackdb.internal.core.db.YouTrackDBInternalEmbedded;
import com.jetbrains.youtrackdb.internal.core.engine.EngineAbstract;
import com.jetbrains.youtrackdb.internal.core.engine.MemoryAndLocalPaginatedEnginesInitializer;
import com.jetbrains.youtrackdb.internal.core.exception.BaseException;
import com.jetbrains.youtrackdb.internal.core.exception.DatabaseException;
import com.jetbrains.youtrackdb.internal.core.storage.Storage;
import com.jetbrains.youtrackdb.internal.core.storage.memory.DirectMemoryStorage;

public class EngineMemory extends EngineAbstract {

  public static final String NAME = "memory";

  public EngineMemory() {
  }

  @Override
  public Storage createStorage(
      String url,
      long maxWalSegSize,
      long doubleWriteLogMaxSegSize,
      int storageId,
      YouTrackDBInternalEmbedded context) {
    try {
      return new DirectMemoryStorage(url, url, storageId, context);
    } catch (Exception e) {
      final var message = "Error on opening in memory storage: " + url;
      LogManager.instance().error(this, message, e);

      throw BaseException.wrapException(new DatabaseException(url, message), e, url);
    }
  }

  @Override
  public String getName() {
    return NAME;
  }

  @Override
  public String getNameFromPath(String dbPath) {
    return IOUtils.getRelativePathIfAny(dbPath, null);
  }

  @Override
  public void startup() {
    MemoryAndLocalPaginatedEnginesInitializer.INSTANCE.initialize();
    super.startup();
  }
}
