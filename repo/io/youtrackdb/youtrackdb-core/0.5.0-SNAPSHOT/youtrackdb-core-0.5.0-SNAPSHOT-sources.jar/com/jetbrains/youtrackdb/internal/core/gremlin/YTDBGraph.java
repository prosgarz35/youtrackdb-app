package com.jetbrains.youtrackdb.internal.core.gremlin;

import com.jetbrains.youtrackdb.api.gremlin.YTDBGraphTraversal;
import com.jetbrains.youtrackdb.api.gremlin.YTDBGraphTraversalSource;
import com.jetbrains.youtrackdb.api.gremlin.embedded.YTDBVertex;
import com.jetbrains.youtrackdb.internal.core.gremlin.service.YTDBServices;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableFunction;
import org.apache.commons.lang3.function.FailableSupplier;
import org.apache.tinkerpop.gremlin.structure.Graph;
import org.apache.tinkerpop.gremlin.structure.service.ServiceRegistry;
import org.apache.tinkerpop.gremlin.structure.util.GraphFactoryClass;

@GraphFactoryClass(YTDBGraphFactory.class)
@Graph.OptIn(Graph.OptIn.SUITE_STRUCTURE_STANDARD)
@Graph.OptIn(Graph.OptIn.SUITE_PROCESS_STANDARD)
@Graph.OptIn("com.jetbrains.youtrackdb.internal.server.plugin.gremlin.process.YTDBProcessTestSuite")
public interface YTDBGraph extends Graph {

  @Override
  default ServiceRegistry getServiceRegistry() {
    return YTDBServices.REGISTRY;
  }

  @Override
  YTDBVertex addVertex(Object... keyValues);

  @Override
  YTDBVertex addVertex(String label);

  /// Performs backup of database content to the selected folder. This is a thread-safe operation
  /// and can be done in normal operational mode.
  ///
  /// During the first backup full content of the database will be copied into the folder, otherwise
  /// only changes after the last backup in the same folder will be copied.
  ///
  /// Unlike [#backup(Path)] method, this method can be used to perform backup to the abstract
  /// backup storage to the remote server, for example.
  ///
  /// As this method does not operate by concepts of the file system but instead accepts lambdas
  /// that provide access to the content of backup.
  ///
  /// @param ibuFilesSupplier        Lamba that provides the list of backup files already created.
  /// @param ibuInputStreamSupplier  Supplier of input streams for backup units. It may implement
  /// [BackupTailReadCapability] to return the last bytes of a named unit, up to the requested
  /// count, without reading more than that count from the unit. A shorter unit returns all its
  /// bytes. A failed tail read stops extension and removes no unit. Without this capability,
  /// extension reads complete units.
  /// @param ibuOutputStreamSupplier Lambda that provides the output stream for the backup file.
  /// The output stream may implement [BackupForceCapability]. It must make all written bytes and
  /// the file length durable before its force returns. It must also publish one write request
  /// inside one aligned 512-byte unit block completely or not at all. A stream without that
  /// guarantee must not implement the capability. Backup then records an absent barrier flag.
  ///
  /// @param ibuFileRemover          Lamba that removes the backup file from the backup storage.
  ///
  void backup(final Supplier<Iterator<String>> ibuFilesSupplier,
      Function<String, InputStream> ibuInputStreamSupplier,
      Function<String, OutputStream> ibuOutputStreamSupplier,
      final Consumer<String> ibuFileRemover);

  /// Performs backup of database content to the selected folder. This is a thread-safe operation
  /// and can be done in normal operational mode.
  ///
  /// During the first backup full content of the database will be copied into the directory,
  /// otherwise only changes after the last backup in the same folder will be copied.
  ///
  /// @param path Path to the backup folder.
  /// @return The name of the last backup file.
  String backup(Path path);

  /// Performs backup of database content to the selected folder.
  ///
  /// If the incremental backup is present in the folder, it will be overwritten.
  ///
  /// @param path Path to the backup folder.
  /// @return The name of the backup file.
  String fullBackup(Path path);

  @Override
  default YTDBGraphTraversalSource traversal() {
    return new YTDBGraphTraversalSource(this);
  }

  /// Start a new transaction if it is not yet started and executes passed in code in it.
  ///
  /// Uses any transaction already open. Commits any open transaction when the code returns
  /// successfully, or rolls it back when the code throws. Commit failures reach the caller.
  /// Unchecked commit failures propagate unchanged. Other commit exceptions are wrapped in
  /// [IllegalStateException] with the original cause. A commit exception can occur after changes
  /// have been saved.
  default <X extends Exception> void executeInTx(
      @Nonnull FailableConsumer<YTDBGraphTraversalSource, X> code) throws X {
    YTDBTransaction.executeInTX(code, traversal());
  }

  /// Start a new transaction if it is not yet started and executes passed in code in it and then
  /// returns the result of the code execution.
  ///
  /// Uses any transaction already open. Commits any open transaction when the code returns
  /// successfully, or rolls it back when the code throws. Commit failures reach the caller.
  /// Unchecked commit failures propagate unchanged. Other commit exceptions are wrapped in
  /// [IllegalStateException] with the original cause. A commit exception can occur after changes
  /// have been saved.
  default <X extends Exception, R> R computeInTx(
      @Nonnull FailableFunction<YTDBGraphTraversalSource, R, X> code) throws X {
    return YTDBTransaction.computeInTx(code, traversal());
  }

  /// Start a new transaction if it is not yet started and executes passed in code in it.
  ///
  /// Uses any transaction already open. Commits any open transaction when the code returns
  /// successfully, or rolls it back when the code throws. Commit failures reach the caller.
  /// Unchecked commit failures propagate unchanged. Other commit exceptions are wrapped in
  /// [IllegalStateException] with the original cause. A commit exception can occur after changes
  /// have been saved.
  ///
  /// Unlike {@link #executeInTx(FailableConsumer)} also iterates over the returned
  /// [YTDBGraphTraversal] triggering its execution.
  default <X extends Exception> void autoExecuteInTx(
      @Nonnull FailableFunction<YTDBGraphTraversalSource, YTDBGraphTraversal<?, ?>, X> code)
      throws X {
    YTDBTransaction.executeInTX(code, traversal());
  }

  /// Returns [UUID] generated during the creation of the database. Each DB instance his unique
  /// [UUID] identifier.
  ///
  /// It is used during generation of backups and also to identify the same replicas of the database
  /// on different hosts.
  UUID uuid();

  /// Suspends the current thread's transaction and session, runs the block, and restores them.
  /// The block can open its own independent transaction on a fresh session from the pool.
  ///
  /// If there is no active transaction on the current thread, the block still runs in its own
  /// isolated context; nothing needs to be suspended or restored.
  ///
  /// If the block leaves a transaction open (does not commit or rollback), it will be rolled back
  /// and the session will be closed automatically. A warning is logged in this case.
  ///
  /// Nesting is supported: calling {@code withSuspendedTransaction} inside the block suspends the
  /// inner transaction and creates another independent one. Each level saves and restores its own
  /// state via the call stack.
  <T, X extends Exception> T withSuspendedTransaction(
      @Nonnull FailableSupplier<T, X> block) throws X;

  /// Closes current graph instance and release acquired resources.
  @Override
  void close();
}
