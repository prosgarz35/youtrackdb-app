/*
 *
 *
 *  *
 *  *  Licensed under the Apache License, Version 2.0 (the "License");
 *  *  you may not use this file except in compliance with the License.
 *  *  You may obtain a copy of the License at
 *  *
 *  *       http://www.apache.org/licenses/LICENSE-2.0
 *  *
 *  *  Unless required by applicable law or agreed to in writing, software
 *  *  distributed under the License is distributed on an "AS IS" BASIS,
 *  *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  *  See the License for the specific language governing permissions and
 *  *  limitations under the License.
 *  *
 *
 *
 */
package com.jetbrains.youtrackdb.internal.common.concur.lock;

import com.jetbrains.youtrackdb.internal.common.exception.SystemException;

/**
 * Exception thrown when a thread is interrupted while waiting for a lock or resource.
 *
 * @since 3/6/14
 */
public class ThreadInterruptedException extends SystemException {

  public ThreadInterruptedException(ThreadInterruptedException exception) {
    super(exception);
  }

  public ThreadInterruptedException(String message) {
    super(message);
  }
}
