package com.jetbrains.youtrackdb.internal.common.profiler.metrics;

import javax.annotation.Nullable;

/**
 * A metric that holds a single value of type T.
 */
public interface Gauge<T> extends Metric<T> {

  void setValue(T value);

  Gauge<?> NOOP = new Gauge<>() {
    @Override
    public void setValue(Object value) {
      // do nothing
    }

    @Nullable
    @Override
    public Object getValue() {
      return null;
    }
  };

  static <T> Gauge<T> create() {
    return new Impl<>();
  }

  @SuppressWarnings("unchecked")
  static <T> Gauge<T> noop() {
    return (Gauge<T>) NOOP;
  }

  class Impl<T> implements Gauge<T> {

    private volatile T value;

    @Override
    public T getValue() {
      return value;
    }

    @Override
    public void setValue(T value) {
      this.value = value;
    }
  }
}
