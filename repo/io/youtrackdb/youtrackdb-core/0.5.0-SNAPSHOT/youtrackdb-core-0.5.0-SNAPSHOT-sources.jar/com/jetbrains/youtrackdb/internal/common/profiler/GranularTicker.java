package com.jetbrains.youtrackdb.internal.common.profiler;

import java.util.Objects;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.LongSupplier;

/// Default implementation of [Ticker] that updates its internal time at a certain granularity in a
/// separate thread.
///
/// ## Concurrency
///
/// A single scheduled task samples [System#nanoTime()] every `granularity` and publishes a
/// fresh [Snapshot] into the `volatile` reference [#snapshot]. Every *N*-th fire the same
/// task also samples [System#currentTimeMillis()] *before* [System#nanoTime()] and recomputes
/// the wall-clock offset (`nanoTimeDifference`) where `N = timestampRefreshRate / granularity`.
/// Sampling wall time first makes a pause between the reads underestimate the offset rather
/// than push the derived timestamp ahead of the sampled wall clock. The same order is used at
/// startup. Real-clock tests cannot reliably reproduce a pause between these two reads, so
/// their order is intentional. Readers do a single
/// volatile read of `snapshot` and derive both accessors from it — no reader-side CAS.
///
/// Monotonicity is enforced at the writer by [#nextSnapshot]: when building the next
/// snapshot the task compares the candidate against the previously published snapshot and
/// clamps
///
/// - `nanoTime` so it never regresses across publishes (insurance against cross-core clock
///   jitter on older hardware),
/// - the derived wall-clock millis so sub-millisecond drift between `System.nanoTime()` and
///   `System.currentTimeMillis()` at a recalibration fire cannot produce a backward jump in
///   [#approximateCurrentTimeMillis()].
///
/// Because the refresh task is the only writer, `snapshot = nextSnapshot(...)` never races
/// with itself and no further writer-vs-writer serialization is needed. Readers observe an
/// atomic, monotonic `(nanoTime, nanoTimeDifference)` pair via the volatile store on
/// `snapshot`.
///
/// ### Lifecycle freeze
///
/// [#stop()] must guarantee that no refresh publishes a newer snapshot after it returns —
/// callers rely on the approximate time staying frozen once the ticker is stopped.
/// Cancelling the [ScheduledFuture] with `cancel(false)` neither interrupts an
/// already-running refresh nor waits for it, and an in-flight refresh can be descheduled by
/// the OS between its early `stopped` check and the volatile publish. To close that window
/// the publish and the `stopped` flag are serialized on [#lifecycleLock]: `stop()` sets the
/// flag under the lock, and `refresh()` re-checks the flag and publishes under the same lock.
/// Once `stop()` returns, every subsequent refresh either has already published (before
/// `stop()` acquired the lock) or observes `stopped == true` under the lock and publishes
/// nothing. Readers never take this lock.
///
/// Callers such as `Stopwatch.timed()`, `YTDBQueryMetricsStep` and
/// `FrontendTransactionImpl.notifyMetricsListener` compute deltas across two reader
/// invocations and rely on non-negative durations, so monotonicity on both accessors is
/// load-bearing.
public class GranularTicker implements Ticker, AutoCloseable {

  /// Immutable view of the pair `(nanoTime, nanoTimeDifference)`. Held behind one volatile
  /// reference so readers observe both values consistently.
  record Snapshot(long nanoTime, long nanoTimeDifference) {
  }

  private static final Snapshot INITIAL_SNAPSHOT = new Snapshot(0L, 0L);

  private final long granularity;
  /// How many refresh ticks happen between wall-clock recalibrations. Computed once from
  /// `timestampRefreshRate / granularity`; floored at 1 so the refresh task still recalibrates
  /// when the two configuration values are equal (used heavily by tests).
  private final long recalibrationInterval;
  private volatile boolean started;
  private volatile boolean stopped;

  /// Serializes the snapshot publish in [#refresh()] against the `stopped` write in
  /// [#stop()] so the approximate time is guaranteed frozen once `stop()` returns. See the
  /// "Lifecycle freeze" section of the class Javadoc. Readers never acquire this lock.
  private final Object lifecycleLock = new Object();

  /// Combined `(nanoTime, nanoTimeDifference)` snapshot. `nanoTime` is the most recently
  /// sampled [System#nanoTime()]. `nanoTimeDifference` is the offset between
  /// [System#currentTimeMillis()] and `nanoTime / 1_000_000` — it lets us derive an
  /// approximate wall-clock timestamp from the cached `nanoTime` without an extra
  /// `currentTimeMillis()` call. The difference is refreshed periodically to account for clock
  /// drift.
  private volatile Snapshot snapshot = INITIAL_SNAPSHOT;

  /// Fire counter owned exclusively by the scheduled refresh task. `scheduleAtFixedRate`
  /// guarantees a single task does not execute concurrently with itself, so no
  /// synchronization is needed here.
  private long tickCount;

  private final ScheduledExecutorService executor;
  private final LongSupplier nanoClock;
  private final LongSupplier wallClock;
  private volatile ScheduledFuture<?> refreshFuture;

  public GranularTicker(long granularityNanos, long timestampRefreshRate,
      ScheduledExecutorService executor) {
    this(granularityNanos, timestampRefreshRate, executor, System::nanoTime,
        System::currentTimeMillis);
  }

  GranularTicker(long granularityNanos, long timestampRefreshRate,
      ScheduledExecutorService executor, LongSupplier nanoClock, LongSupplier wallClock) {
    this.executor = Objects.requireNonNull(executor, "ScheduledExecutorService must not be null");
    this.nanoClock = Objects.requireNonNull(nanoClock);
    this.wallClock = Objects.requireNonNull(wallClock);
    this.granularity = granularityNanos;
    final long safeGranularity = Math.max(1L, granularityNanos);
    this.recalibrationInterval = Math.max(1L, timestampRefreshRate / safeGranularity);
  }

  @Override
  public void start() {
    assert !started : "Ticker is already started";
    started = true;
    // Wall time first: a pause before sampling nanoTime makes the offset smaller, not larger.
    final long initialMillis = wallClock.getAsLong();
    final long initialNano = nanoClock.getAsLong();
    final long initialDiff = initialMillis - initialNano / 1_000_000;
    snapshot = new Snapshot(initialNano, initialDiff);

    refreshFuture = executor.scheduleAtFixedRate(
        this::refresh, granularity, granularity, TimeUnit.NANOSECONDS);
  }

  /// Single-writer refresh. Samples `System.nanoTime()` every fire and, every
  /// [#recalibrationInterval] fires, also samples `System.currentTimeMillis()` to recompute
  /// the wall-clock offset. Runs on the scheduled executor's thread.
  private void refresh() {
    if (stopped) {
      return;
    }
    tickCount++;
    final boolean recalibrate = tickCount % recalibrationInterval == 0;
    // Sample wall time first only when recalibrating. A pause before nanoTime then makes
    // the recalibrated offset late rather than early. Other fires reuse the previous offset.
    final long wallMillis = recalibrate ? wallClock.getAsLong() : 0L;
    final long freshNano = nanoClock.getAsLong();
    // Publish under the lifecycle lock and re-check stopped. stop() takes the same lock to
    // set the flag, so this refresh either published before stop() acquired the lock or, if
    // it was descheduled past stop() between the early check above and here, now sees
    // stopped == true and publishes nothing. Either way the time is frozen once stop()
    // returns. The top-of-method check stays as a fast path that skips nanoTime sampling.
    synchronized (lifecycleLock) {
      if (stopped) {
        return;
      }
      snapshot = nextSnapshot(snapshot, freshNano, wallMillis, recalibrate);
    }
  }

  /// Builds the next snapshot while enforcing monotonicity of both accessors. Package-private
  /// so unit tests can exercise the clamp without timing-dependent scheduler runs.
  ///
  /// - `nano` is clamped to `max(prev.nanoTime, freshNano)` so successive snapshots never
  ///   expose a regressing raw `nanoTime`.
  /// - On a recalibration fire the new offset is bumped up if needed so
  ///   `nano / 1_000_000 + newDiff >= prev.nanoTime / 1_000_000 + prev.nanoTimeDifference`,
  ///   absorbing the ±1 ms drift that can arise between `System.nanoTime()` and
  ///   `System.currentTimeMillis()`.
  static Snapshot nextSnapshot(Snapshot prev, long freshNano, long wallMillis,
      boolean recalibrate) {
    final long nano = Math.max(prev.nanoTime, freshNano);
    if (!recalibrate) {
      return new Snapshot(nano, prev.nanoTimeDifference);
    }
    long newDiff = wallMillis - nano / 1_000_000;
    final long prevMillis = prev.nanoTime / 1_000_000 + prev.nanoTimeDifference;
    final long candidateMillis = nano / 1_000_000 + newDiff;
    if (candidateMillis < prevMillis) {
      // Absorb the sub-ms drift between System.nanoTime() and System.currentTimeMillis() at
      // recalibration fires: inflate the offset so the derived wall-clock timestamp does not
      // regress against the previously published snapshot.
      newDiff += (prevMillis - candidateMillis);
    }
    return new Snapshot(nano, newDiff);
  }

  @Override
  public long approximateNanoTime() {
    return snapshot.nanoTime;
  }

  @Override
  public long approximateCurrentTimeMillis() {
    final var s = snapshot;
    return s.nanoTime / 1_000_000 + s.nanoTimeDifference;
  }

  @Override
  public long currentNanoTime() {
    return System.nanoTime();
  }

  @Override
  public long getTick() {
    return snapshot.nanoTime / granularity;
  }

  @Override
  public long getGranularity() {
    return granularity;
  }

  @Override
  public void stop() {
    // Set the flag under the lock so any refresh that has already entered its publish block
    // completes first; after this returns every later refresh observes stopped == true under
    // the lock and publishes nothing, freezing the approximate time.
    synchronized (lifecycleLock) {
      stopped = true;
    }
    var f = refreshFuture;
    if (f != null) {
      f.cancel(false);
    }
  }

  @Override
  public void close() {
    stop();
  }
}
